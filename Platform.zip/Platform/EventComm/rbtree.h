/**@file
 * Copyright (C) 2013, Sinovision Tech Ltd.
 * All rights reserved.
 *
 * @brief   This file defines the interface to read black tree operation
 *         the tree reused BSD header file
 *
 * @author  
 * @date 2013-3-30
 *
 */


#ifndef _RBTREE_H_
#define _RBTREE_H_



#include "tree.h"

#ifdef __cplusplus
extern "C" {
#endif


/**key type, could be  int or a char
 */
enum RB_KEY_TYPE
{
	KEY_INT = 0,
	KEY_STRING
};

struct TREE_NODE
{
	RB_ENTRY(TREE_NODE) entry;
	void* key;
	int key_type;
	void* item;
};


/**define the head of the tree
 */
RB_HEAD(TREE_HEAD, TREE_NODE);

typedef struct 
{
	struct TREE_HEAD head;
	int key_type;
}RB_TREE_T;

typedef struct TREE_NODE RB_NODE_T;


/**initialize the rb tree
 */
void rbtree_init(RB_TREE_T* tree, int key_type);

/**insert a node to the tree
 */
RB_NODE_T *rbtree_insert(RB_TREE_T* tree, void* key, void *item);


/**remove a node from the tree
 */
void rbtree_remove(RB_TREE_T* tree, RB_NODE_T* n);


/**search the tree with provided tree
 */
RB_NODE_T *rbtree_find(RB_TREE_T* tree, void* key);


/**get the first node  of the tree
 */
RB_NODE_T *rbtree_first(RB_TREE_T* tree);


/**get the next  node  of the tree
 */
RB_NODE_T *rbtree_next(RB_TREE_T* tree, RB_NODE_T *node);


#ifdef __cplusplus
}
#endif




#endif

