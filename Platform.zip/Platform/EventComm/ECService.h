/**@file 
 * Copyright (C) 2013, Sinovision Tech Ltd.
 * All rights reserved.
 *
 * @brief  this file defines the C++ interface of event comm service
 *
 * @author  
 * @date 2013-3-1
 *
 */
#ifndef _EC_SERVICE_H_
#define _EC_SERVICE_H_

#include "logger.h"
#include "ecl.h"
#include "rbtree.h"


class ECService
{
public:
	/** Construct a EC service.
	 * @param id The service id.
	 * @param priority The service priority.
	 * @param detach != 0 if the thread should run detached.
	 * @param stack The initial service stack.
	 * @param arg An opaque pointer to pass sevice specific data.
	 */
    ECService(SVCID  id,
                int priority,
                bool detach, 
                size_t stack, 
                os_thread_data_t arg = NULL);
      
	/** Start a Service
	 * @param noCreate Use the current (calling) thread instead of creating one.
	 * @return ECL_OK if the thread is started successfully.
	 */
    int start(bool noCreate = false);

	/** Start all registered threads.
	 */
    static void startAll();

	/** The event call back function type.
	 */
    typedef void (ECService::*EventHandler)(EVENT_HEADER_TYPE* header);
	
	/** Register an event call back function.
	 * This function will register the specified member function as a call back function
	 * for an event. 
	 * @param event The event code.
	 * @param handler The event handling function.
	 */
    void registerEvent(uint32_t event, EventHandler handler);

	/**
	  *register device to service's devs
	  *@param dev_name
	  *@param dev_id
	  *@return -1 is failed,0 is successful
	 */
	int registerDevice(char *dev_name, int dev_id);

	/**
	  *find fd by dev id .
	  *@param dev_id
	  *@return the fd we find,-1 we don't find it;
	 */
	int find_fd_by_id(int dev_id);

	/**
	  *remove device from service's devs
	  *@param dev_name
	  *@return -1 is failed,0 is successful
	 */
	int removeDevice(char *dev_name);

	/**
	  *register device to service's devs
	  *@param dev_id
	  *@return -1 is failed,0 is successful
	 */
	int removeDeviceByid(int dev_id);

	/** Send an event code to destination service.
	 */
	static int sendEvent(SVCID to, uint32_t code, bool noLog = false);

	/** Send a event with payload to destination service
	 */
	static int sendEvent(SVCID to, uint32_t code, void* event, size_t size, bool noLog = false);
	
	static int sendEventFrom(SVCID from, SVCID to, uint32_t code, void* event, size_t size, bool noLog = false);

	/** Send an event code to destination service's device.*/
	static int sendEventToDev(char *dev_name, uint32_t code);

	/** Send a event with payload to destination service's device*/
	static int sendEventToDev(char *dev_name, uint32_t code, void* event, size_t size);

	/** Send a event without payload to the service itself
	 */
	int sendSelfEvent(uint32_t code);

	/** Send a event without payload to the service itself
	 */
	int sendSelfEvent(uint32_t code, void* event, size_t size);


	/**
	*@bref start a timer
	*@code timer respond event code when timer expired
	*@tmo_ms timer expiration time
	*@option timer option
	*
	*@return zero is successful,other is failed
	*/
	static int timerStart(uint32_t code, uint32_t tmo_ms, uint32_t option = TIMER_OPT_ONCE);

	/**
	*@bref stop a timer
	*@ev_code  event code which timer respond to service
	*
	*@return zero is successful,other is failed
	*/
	static int timerStop(uint32_t ev_code);

	/**
	*@bref get a timer's status
	*@code timer respond event code when timer expired
	*
	*@return TIMER_STATUS
	*/
	static int timerStatus(uint32_t code);

	/**record log message
	@level  log level
	@fmt	log content
	*/
	static void logMsg(unsigned int level, const char *fmt, ...);

	/**
	*@bref connect to svc
	*@to target service id.
	*@enProbe is enable probe package
	*/
	static void connToSvc(SVCID to, int enProbe);
/*
    #define LOGMSG(level, x) SCLog::logm( opt,"%s:%d: ", \
        strrchr (__FILE__, '/') == 0 ? __FILE__: strrchr (__FILE__, '/') + 1, __LINE__); \
        SCLog::logm( opt, x)	
*/        
    /** get the self sevice id
	 */
	SVCID getID(){return id;}

protected:

    virtual ~ECService();

	RB_TREE_T evTree;
	
	typedef struct
	{
		uint32_t code;
		EventHandler handler;
	}EVENT_TYPE;
		
	/** Process an event
	* @param event event pointer for processing
	*/
    void processEvent(EVENT_HEADER_TYPE *event);

    /** Default handler of events
	* @param event event pointer for processing
	*/
    virtual void defaultHandler(EVENT_HEADER_TYPE *event);

	/** The pre-thread initialization function.
	 * This thread is not called in the thread's context.
	 * @return >= 0 on success.
	 */
	virtual int initialize(){return 0;};

	/** The thread initialization function.
	 * This thread is called in the thread's context.
	 * @return >= 0 on success.
	 */
	virtual int threadInitialize(){return 0;};

	 /** waiting until next event coming or timeout
	  * @param timeElapsed elapsed in ms.
	  * @param timeoutMs timeout value in milliseconds
	  * @return data pointer of received data
	  */
	void * receiveEvent(int*timeElapsed, int timeoutMs);
	 
	 /**get a new buffer from mem pool
	  * @param n the buffer size required 
	  * @return the pointer to data of the buffer
	  */ 
	 char * getBuffer(size_t n);
	 
	 /**  return a buffer to mem pool
	  * @param data the pointer to data of the buffer
	  */ 
	 void releaseBuffer(char *data);

	/**wait until expected event happened or 
	 * for test purpose only
	 * @param code the event code expecting
	 * @param ev event buffer pointer 
	 * @param timeoutMs timeout value in milliseconds
	 * @param status, 0 means succedded, -1 means error or timeout happened
	 */ 
	int waitEvent(unsigned int code, EVENT_HEADER_TYPE **ev, int timeoutMs);

	//send xml ver to scCtl.
	int  sendVerToCtl(SVCID to);

	void setFpgaVer(EV_SS_FPGA_REPORT_VER_TYPE *ev);

	char * setProcessName(char *name);

	void exitBin();

	 

private:

	/** Static entry of pre thread start operation
	* @param arg this pointer of the class
	*/
    static int preThread(os_thread_data_t arg);

	/** Static entry of initialize operation after thread start 
	* @param arg this pointer of the class
	*/
    static int threadInit(os_thread_data_t arg);

	/** Static entry of event processing
	* @param event event pointer for processing
	* @param arg this pointer of the class
	*/
	static void dispatchEvent(EVENT_HEADER_TYPE *event, os_thread_data_t arg);


	/**get the self service id
	 */
	SVCID id;
};

#endif

