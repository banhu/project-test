#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <libxml/parser.h>

#include "rbtree.h"
#include "sys_topology.h"


#define CONFIG_FILE		"/usr/sv/config/sysmap.xml"
//#define CONFIG_FILE		"/home/root/config.xml"

#define ROOT_ELEMENT	"config"
#define NODE_INFO_EL	"node_info"
#define PROC_INFO_EL	"proc_info"
#define SERVICE_EL		"service_info"
#define DEVICE_EL		"device"

#define NODE_INFO_PROP_ID	"id"
#define NODE_INFO_PROP_NAME	"name"
#define NODE_INFO_PROP_IP	"ip"

#define PROC_INFO_PROP_ID	"id"
#define PROC_INFO_PROP_NAME	"name"
#define PROC_INFO_PROP_DEBUGPORT	"debugport"

#define SERVICE_PROP_ID		"id"
#define SERVICE_PROP_NAME	"name"
#define SERVICE_PROP_PORT	"port"
#define SERVICE_PROP_PID	"pid"
#define SERVICE_PROP_NID	"nid"

#define DEVICE_PROP_SVCID	"svc_id"
#define DEVICE_PROP_DEVID	"dev_id"
#define DEVICE_PROP_DEVFILE	"device_file"

extern RB_TREE_T node_tree;
extern RB_TREE_T process_tree;
extern RB_TREE_T sv_tree;
extern RB_TREE_T dev_tree;

extern char* process_name_by_id(PROCESSID pid);
extern char* node_name_by_id(NODEID nid);
extern char* get_ip(NODEID nid);
extern DEFAULT_SERVICE_INFO_TYPE *get_def_service(char *name);
//extern PLATFORM_DEVICE_TYPE *get_def_device(char *dev_file_name);
extern PROC_INFO_TYPE *get_def_procInfo(char *name);
extern NODE_INFO_TYPE *get_def_nodeInfo(char *name);


void encrypt(char* infile,char* outfile, int len, char* pass)
{
    int i;
    int pass_len = strlen(pass);  //get the length of the pass
    for(i = 0; i<len; ++i)
    {
        outfile[i] = infile[i]^pass[i%pass_len];   // XOR the data
        if(outfile[i] == 0)                        // when the XOR value is 0, then can keep the value as the before
        {
            outfile[i] = infile[i];
        }
    }
}

void *xmlEncryptFile(char* file)
{
	xmlDocPtr doc;
    char* pass = "Sinovision";
    FILE* fp;
    int flen;
    if((fp = fopen(file,"r"))==NULL) //check the file if open success
    {
        printf("%s Open %s error\n", __FUNCTION__, file);
        return NULL;
    }
    fseek(fp, 0L, SEEK_END);    //goto the end of file
    flen = ftell(fp);           //get the length of file
    fseek(fp, 0L, SEEK_SET);    //goto the begain of file

    char *inbuf = (char*)malloc(flen * sizeof(char)); //request memory for file
    memset(inbuf, 0, flen);                           //init the memory
    fread(inbuf, flen, 1, fp);                        //get the file to the memory
    fclose(fp);
    if(strncmp(inbuf, "<", 1) == 0)                   //check the file if is encrypt,begain as "<" is common file
    {
        //doc =  xmlParseMemory(inbuf, flen);           //return the xmldocptr
    	doc =  xmlReadMemory(inbuf, flen, NULL, "UTF-8", XML_PARSE_NOBLANKS);           //return the xmldocptr
    }
    else
    {
        char *enbuf = (char *)malloc((flen)*sizeof(char)); // request memory for encrypt the file
        memset(enbuf, 0, flen);                           // init the memory
        encrypt(inbuf, enbuf, flen, pass);                //encrypt the memory
        //doc = xmlParseMemory(enbuf, flen);               //return the xmldocptr
        doc = xmlReadMemory(enbuf, flen, NULL, "UTF-8", XML_PARSE_NOBLANKS);               //return the xmldocptr
        // why encrypt memory than can be access the encrypt xml
        free(enbuf);                                      //free the inbuf
    }
    free(inbuf);                                      //free the inbuf
    return (void *)doc;
}



xmlChar* parser_proc_port(xmlNodePtr nodePtr,PROCESSID pid)
{
	xmlNodePtr curNode;
	xmlChar	*ret = NULL;
	xmlChar	*ret1 = NULL;

	if (NULL == nodePtr) {
		printf("%s node is NULL\n", __FUNCTION__);
		return NULL;
	}

	if (xmlStrcmp(nodePtr->name, (const xmlChar *)NODE_INFO_EL) != 0) {
		printf("%s node name(%s) is error, hope %s\n",
				__FUNCTION__, nodePtr->name, NODE_INFO_EL);
		return NULL;
	}

	ret = xmlGetProp(nodePtr, (const xmlChar *)NODE_INFO_PROP_NAME);

	curNode = nodePtr->xmlChildrenNode;


	while (NULL != curNode) {
		ret = xmlGetProp(curNode, (const xmlChar *)PROC_INFO_PROP_NAME);
		//printf("proc_name:%s   process_name_by_id(%d):%s\n", ret2,pid,process_name_by_id(pid));
		if(xmlStrcmp(ret, (const xmlChar *)process_name_by_id(pid)) == 0)
		{
			ret1 = xmlGetProp(curNode, (const xmlChar *)PROC_INFO_PROP_DEBUGPORT);
			if (ret1 != NULL)
				break;
				//return ret1;

		}
		curNode = curNode->next;
	}
	return ret1;
}

int process_port_by_id(PROCESSID pid)
{
	int port=0;
	xmlDocPtr xmlDoc;
	xmlNodePtr rootNode,curNode;
	xmlChar	*ret = NULL;

	//xmlDoc = xmlParseFile(CONFIG_FILE);
	//xmlDoc = xmlReadFile(CONFIG_FILE, "UTF-8", XML_PARSE_NOBLANKS);
	xmlDoc = (xmlDocPtr)xmlEncryptFile(CONFIG_FILE);

	if (NULL == xmlDoc) {
		printf("%s parse xml %s error\n", __FUNCTION__, CONFIG_FILE);
		return 0;
	}

	//make sure the rootNode
	rootNode = xmlDocGetRootElement(xmlDoc);
	if (NULL == rootNode) {
		printf("%s xml file %s root node is NULL\n", __FUNCTION__, CONFIG_FILE);
		xmlFreeDoc(xmlDoc);
		return 0;
	}
	//
	if (xmlStrcmp(rootNode->name, (const xmlChar *)ROOT_ELEMENT) != 0) {
		printf("%s root node(%s) is error, hope %s\n", __FUNCTION__, rootNode->name, ROOT_ELEMENT);
		xmlFreeDoc(xmlDoc);
		return 0;
	}

	curNode = rootNode;
	curNode = curNode->xmlChildrenNode;

	while (NULL != curNode) {

		if (xmlStrcmp(curNode->name, (const xmlChar *)NODE_INFO_EL) == 0) {

			ret = parser_proc_port(curNode,pid);
			if(NULL != ret){
				port = atoi((char *)ret);
				break;
			}
		}

		curNode = curNode->next;
	}
	//printf("port:%d\n",port);
	xmlFreeDoc(xmlDoc);
	return port;
}

/** delete by  huyf 2014-10-15
void parser_device(xmlNodePtr nodePtr, int svc_id)
{
	PLATFORM_DEVICE_TYPE *dev;
	xmlChar	*ret = NULL;

	if (NULL == nodePtr) {
		printf("%s node is NULL\n", __FUNCTION__);
		return;
	}
	
	if (xmlStrcmp(nodePtr->name, (const xmlChar *)DEVICE_EL) != 0) {
		printf("%s node name(%s) is error, hope %s\n", 
				__FUNCTION__, nodePtr->name, DEVICE_EL);	
		return;
	}


	ret = xmlGetProp(nodePtr, (const xmlChar *)DEVICE_PROP_DEVFILE);
	if (NULL != ret) {
		dev = get_def_device((char *)ret);
		if (NULL == dev) {
			printf("***********************************\n");
			printf("%s device (%s) is not in default\n", __FUNCTION__, (char *)ret);
			printf("***********************************\n");
			xmlFree(ret);
			return;
		}		
		xmlFree(ret);
		ret = NULL;
	}

	dev->svc_id = svc_id;
	
	rbtree_insert(&dev_tree, (void*)dev->dev_file_name, (void*)dev);
}
*/

void parser_service(xmlNodePtr nodePtr, int node_id, int proc_id)
{
	DEFAULT_SERVICE_INFO_TYPE *def_svc;
	//xmlNodePtr curNode;  //delete by huyf 2014-10-15
	SERVICE_TYPE *svc;
	struct sockaddr_in addr;
	xmlChar	*ret = NULL;
	int status = 0;
	char *ip = NULL;

	if (NULL == nodePtr) {
		printf("%s node is NULL\n", __FUNCTION__);
		return;
	}

	if (xmlStrcmp(nodePtr->name, (const xmlChar *)SERVICE_EL) != 0) {
		printf("%s node name(%s) is error, hope %s\n", 
				__FUNCTION__, nodePtr->name, SERVICE_EL);	
		return;
	}

	ret = xmlGetProp(nodePtr, (const xmlChar *)SERVICE_PROP_NAME);
	if (NULL != ret) {
		def_svc = get_def_service((char *)ret);
		if (NULL == def_svc) {
			printf("***********************************\n");
			printf("%s service (%s) is not in default\n", __FUNCTION__, (char *)ret);
			printf("***********************************\n");
			xmlFree(ret);
			return;
		}
		xmlFree(ret);
		ret = NULL;
	}
	
	svc = (SERVICE_TYPE *)malloc(sizeof(SERVICE_TYPE));
	if (NULL == svc) {
		printf("%s malloc SERVICE_TYPE is NULL\n", __FUNCTION__);
		return;
	}
	memset((void *)svc, 0x0, sizeof(SERVICE_TYPE));

	svc->id = def_svc->id;
	svc->name = def_svc->name;
	svc->pid = proc_id;
	svc->nid = node_id;
	svc->pname = process_name_by_id(svc->pid );
	svc->nname = node_name_by_id(svc->nid);

	
	// The service address.
	memset(&addr, 0, sizeof(addr));
	ip = get_ip(svc->nid);
	if (ip == NULL) {
		// Use localhost.
		ip = "127.0.0.1";
	}
	
	status = inet_aton(ip, &addr.sin_addr);
	if (!status) {
		printf("%s invalid address \n", __FUNCTION__);
	}
	svc->addr = addr;
	svc->addr.sin_family = AF_INET;

	ret = NULL;
	ret = xmlGetProp(nodePtr, (const xmlChar *)SERVICE_PROP_PORT);
	if (NULL != ret) {
		svc->addr.sin_port = htons(atoi((char *)ret));
		xmlFree(ret);
		ret = NULL;
	}

	rbtree_insert(&sv_tree, (void*)svc->id, (void*)svc);

	/** delete the insert to dev_tree, because now insert by hand. huyf delete 2014-10-15
	curNode = nodePtr->xmlChildrenNode;

	while (NULL != curNode) {
		
		if (xmlStrcmp(curNode->name, (const xmlChar *)DEVICE_EL) == 0) {
			parser_device(curNode, svc->id);	
		}
		
		curNode = curNode->next;
	}
	*/
}


void parser_proc_info(xmlNodePtr nodePtr, int node_id)
{
	xmlNodePtr curNode;
	PROC_INFO_TYPE *proc_info;
	xmlChar	*ret = NULL;

	if (NULL == nodePtr) {
		printf("%s node is NULL\n", __FUNCTION__);
		return;
	}
		
	if (xmlStrcmp(nodePtr->name, (const xmlChar *)PROC_INFO_EL) != 0) {
		printf("%s node name(%s) is error, hope %s\n", 
				__FUNCTION__, nodePtr->name, PROC_INFO_EL);	
		return;
	}
	
	ret = xmlGetProp(nodePtr, (const xmlChar *)PROC_INFO_PROP_NAME);
	if (NULL != ret) {
		proc_info = get_def_procInfo((char *)ret);
		if (NULL == proc_info) {
			printf("***********************************\n");
			printf("%s processer (%s) is not in default\n", __FUNCTION__, (char *)ret);
			printf("***********************************\n");
			xmlFree(ret);
			return;
		}
		xmlFree(ret);
		ret = NULL;
	}
	
	rbtree_insert(&process_tree, (void*)proc_info->id, proc_info);

	curNode = nodePtr->xmlChildrenNode;

	while (NULL != curNode) {
		
		if (xmlStrcmp(curNode->name, (const xmlChar *)SERVICE_EL) == 0) {
			parser_service(curNode, node_id, proc_info->id);
		}
		
		curNode = curNode->next;
	}
}

void parser_node_info(xmlNodePtr nodePtr)
{
	NODE_INFO_TYPE *node_info = NULL;
	xmlNodePtr curNode;
	xmlChar	*ret = NULL;

	if (NULL == nodePtr) {
		printf("%s node is NULL\n", __FUNCTION__);
		return;
	}

	if (xmlStrcmp(nodePtr->name, (const xmlChar *)NODE_INFO_EL) != 0) {
		printf("%s node name(%s) is error, hope %s\n", 
				__FUNCTION__, nodePtr->name, NODE_INFO_EL);	
		return;
	}

	
	ret = xmlGetProp(nodePtr, (const xmlChar *)NODE_INFO_PROP_NAME);
	if (NULL != ret) {
		node_info = get_def_nodeInfo((char *)ret);
		if (NULL == node_info) {
			printf("***********************************\n");
			printf("%s node info (%s) is not in default\n", __FUNCTION__, (char *)ret);
			printf("***********************************\n");
			xmlFree(ret);
			return;
		}
		xmlFree(ret);
		ret = NULL;
	}

	ret = xmlGetProp(nodePtr, (const xmlChar *)NODE_INFO_PROP_IP);
	if (NULL != ret) {
		//the ret is not free
		node_info->ip = (char *)ret;
	}
	
	rbtree_insert(&node_tree, (void*)node_info->id, node_info);
	

	curNode = nodePtr->xmlChildrenNode;

	while (NULL != curNode) {
		
		if (xmlStrcmp(curNode->name, (const xmlChar *)PROC_INFO_EL) == 0) {
			parser_proc_info(curNode, node_info->id);	
		}
	
		curNode = curNode->next;
	}
	
}

void parser_xmlFile()
{
	xmlDocPtr xmlDoc;
	xmlNodePtr rootNode,curNode;

	
	//xmlDoc = xmlParseFile(CONFIG_FILE);
	//xmlDoc = xmlReadFile(CONFIG_FILE, "UTF-8", XML_PARSE_NOBLANKS);
	xmlDoc = (xmlDocPtr)xmlEncryptFile(CONFIG_FILE);

	if (NULL == xmlDoc) {
		printf("%s parse xml %s error\n", __FUNCTION__, CONFIG_FILE);
		return ;
	}
	
	rootNode = xmlDocGetRootElement(xmlDoc);
	if (NULL == rootNode) {
		printf("%s xml file %s root node is NULL\n", __FUNCTION__, CONFIG_FILE);
		xmlFreeDoc(xmlDoc);
		return ;
	}
	
	if (xmlStrcmp(rootNode->name, (const xmlChar *)ROOT_ELEMENT) != 0) {
		printf("%s root node(%s) is error, hope %s\n", __FUNCTION__, rootNode->name, ROOT_ELEMENT);
		xmlFreeDoc(xmlDoc);
		return ;
	}
	
	curNode = rootNode;
	curNode = curNode->xmlChildrenNode;

	while (NULL != curNode) {
		
		if (xmlStrcmp(curNode->name, (const xmlChar *)NODE_INFO_EL) == 0) {
			parser_node_info(curNode);	
		}
		
		curNode = curNode->next;
	}
	
	xmlFreeDoc(xmlDoc);
}

