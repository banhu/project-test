/**@file
 * Copyright (C) 2013, Sinovision Tech Ltd.
 * All rights reserved.
 *
 * @brief   This file defines the interface to queue handling
 *         the queue is mutex protected for multi thread enviroment
 *
 * @author  
 * @date 2013-3-30
 *
 */
#ifndef _QUEUE_H_
#define _QUEUE_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "os_intf.h"


#define QUEUE_FLUSH_THRE	(200)

#define QUEUE_MAX  64
/**
* queue node struct
* single linked  list

typedef struct QNODE {
    struct QNODE *next;
    void *data;
} QNODE;
*/
typedef void* QNODE;

/**
* queue  struct
* contains the link of head and tail nodes
*/
typedef struct QUEUE {
    QNODE *base;
    int front;
    int rear;
    os_mutex_t mutex;    // queue's mutex.
    int size;    // number of memory block of queue
} QUEUE;


/**  
 * create a and initialize a queue
 * @return the pointer to the queue
 */
QUEUE *queue_new    (void);

/**  
 * release a queue and all the contents
 * @param q  the pointer to the queue
 */
void queue_free(QUEUE **q);


/**  
 * add an item to tail of the queue
 * @param q  the pointer to the queue
 * @param data  the pointer to the item
 */ 
void queue_add(QUEUE *q, void *data);


/**  
 * add an item to head of the queue
 * @param q  the pointer to the queue
 * @param data  the pointer to the item
 */ 
void queue_add_head(QUEUE *q, void *data);


/**  
 * get an item from the head of the queue
 * @param q  the pointer to the queue
 * @return the pointer to the item
 */
void *queue_get(QUEUE *q);

/**
 * flush the queue
 * @param q  the pointer to the queue
 * @return the pointer to the item
 */
void queue_flush(QUEUE *q);


/**  
 * query the size of the queue
 * @param q  the pointer to the queue
 * @return the pointer to the queue
 */
int queue_size(QUEUE *q);


#ifdef __cplusplus
}
#endif

#endif//_QUEUE_H_
