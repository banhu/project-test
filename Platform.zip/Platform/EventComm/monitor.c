/**@file 
 * Copyright (C) 2013, Sinovision Tech Ltd.
 * All rights reserved.
 *
 * @brief   Command Processor
 *
 * @author  
 * @date 2013-4-9
 *
 */
#include <stdio.h> 
#include <stdlib.h> 
#include <string.h>
#include <ctype.h>

#include "monitor.h"
#include "rbtree.h"
#include "sys_topology.h"
#include "buffer.h"


extern int	cmd_send_event(int argc, char * const argv[]);
extern int	cmd_display_conns(int argc, char * const argv[]);
extern int cmd_display_queue(int argc, char * const argv[]);
extern int cmd_timer(int argc, char * const argv[]);
extern int cmd_log(int argc, char * const argv[]);
extern int dump_to_terminal(int argc, char * const argv[]);
extern int dump_ver(int argc, char * const argv[]);
extern int cmd_event_test(int argc, char * const argv[]);
extern int cmd_conn_log_msg();
extern int cmd_printf_log(int log, int id);
extern int cmd_log_interval_ev();
//extern int cmd_is_mutex_unlock(int argc, char * const argv[]);
#define is_blank(c)	(c == ' ' || c == '\t')
static const char erase_seq[] = "\b \b";		/* erase sequence	*/
static const char   tab_seq[] = "        ";		/* used to expand TABs	*/

/**global command tree */
static RB_TREE_T command_tree;

int do_help(int argc, char * const argv[]);



/** find a command by name
 * @param cmd_name command'sname
 * @return pointer of struct cmd_t,NULL mean then command not find.
*/
static struct cmd_t *find_command(char *cmd_name)
{
	RB_NODE_T *result = NULL;


	if (NULL ==  cmd_name) {
		return NULL;
	}
		
	result = rbtree_find(&command_tree, (void*)cmd_name);
	if(result){
		return (struct cmd_t *)result->item;
	}
	return NULL;
}


/** insert a command 
 * @param cmd_name
 * @param cmd_fun
 * @param help
 * @return 0 is sucessful,-1 is error.
 */
int insert_command(char *cmd_name, CMD_FUN_T cmd_fun, char *help)
{
	struct cmd_t *cmd;

	if (NULL ==  cmd_name || NULL == cmd_fun ) {
		return -1;
	}
	
	if (NULL !=  find_command(cmd_name)) {
		printf("the cmd %s is register\n", cmd_name);
		return -1;
	}

	
	cmd = malloc(sizeof(struct cmd_t));
	memset(cmd, 0x0, sizeof(struct cmd_t));

	sprintf(cmd->name, "%s", cmd_name);
	if (NULL != help) {
		sprintf(cmd->help, "%s", help);
	}
	cmd->cmd_fun = cmd_fun;
	
	rbtree_insert(&command_tree, (void*)cmd->name, cmd);

	return 1;
}

/** delete a command 
 * @param cmd_name
 * @return 0 is sucessful,-1 is error.
 */
int delete_command(char *cmd_name)
{
	RB_NODE_T *result = NULL;

	
	if (NULL ==  cmd_name) {
		return -1;
	}

	
	result = rbtree_find(&command_tree, (void*)cmd_name);

	if (NULL ==  result) {
		printf("the cmd %s is not register\n", cmd_name);
		return -1;
	}

	free(result->item);
	
	rbtree_remove(&command_tree, result);
	
	return 0;
}



/** printf a command's help 
 * @param pointer of struct cmd_t
 */
static inline void  cmd_help(const struct cmd_t *cmd)
{
	if (NULL != cmd->help) {
		printf("%s - %s\n\n", cmd->name, cmd->help);
	} else {
		printf("%s - No additional help available.\n", cmd->name);
	}
}

/** precess a command 
 * @param cmd_name command name
 * @param argc comand's parameter number.
 * @param argv comand's parameter array.
 * @return 
 */
static int process_command(char *cmd_name, int argc, char * const argv[])
{
	int rc;
	struct cmd_t *cmd;

	/* Look up command */
	cmd = find_command(cmd_name);
	if (NULL == cmd) {
		printf("Unknown command '%s' - try 'help'\n", cmd_name);
		return CMD_RET_FAILURE;
	}

	/* If OK so far, then do the command */
	rc = cmd->cmd_fun(argc, argv);
	
	return rc;
}

/** parse a command line */
int parse_line(char *line, char *argv[])
{
	int nargs = 0;

	while (nargs < ARG_MAX) {

		/* skip any white space */
		while (is_blank(*line))
			++line;

		if (*line == '\0') {	/* end of line, no more args	*/
			argv[nargs] = NULL;
			return (nargs);
		}

		argv[nargs++] = line;	/* begin of argument string	*/

		/* find end of string */
		while (*line && !isblank(*line))
			++line;

		if (*line == '\0') {	/* end of line, no more args	*/
			argv[nargs] = NULL;
			return (nargs);
		}

		*line++ = '\0';		/* terminate current arg	 */
	}

	printf("** Too many args (max. %d) **\n", ARG_MAX);

	return -1;
}

/** parse command line and execute command
 * @param cmd_line  
 * @param len 	length of command
 * @return -1 is error, > 0 is successful
 */
//static int parse_run_command(const char *cmd_line, int len)
int parse_run_command(const char *cmd_line, int len)
{	
	char cmd_buf[MONITOR_LINE_MAX];	/* working copy of cmd		*/
	char *token;			/* start of token in cmdbuf	*/
	char *sep;				/* end of token (separator) in cmdbuf */
	char *str = cmd_buf;
	char *argv[ARG_MAX + 1]; /* NULL terminated	*/
	int argc, inquotes;
	int rc = 0;


	
	if (len <= 0 || NULL == cmd_line) {
		return -1;	/* empty command line */
	}
	
	if (len >= MONITOR_LINE_MAX) {
		puts("Command too long!\n");
		return -1;
	}
	
	strncpy(cmd_buf, cmd_line, len);
	cmd_buf[len] = '\0';
	
	/* Process separators */
	while (*str) {
	
		/*
		 * Find separator, or string end
		 * Allow simple escape of ';' by writing "\;"
		 */
		for (inquotes = 0, sep = str; *sep; sep++) {
			if ((*sep=='\'') &&
			    (*(sep-1) != '\\'))
				inquotes = !inquotes;

			if (!inquotes &&
			    (*sep == ';') &&	/* separator		*/
			    ( sep != str) &&	/* past string start */
			    (*(sep-1) != '\\'))	/* and NOT escaped	*/
				break;
		}
		

		/*
		 * Limit the token to data between separators
		 */
		token = str;
		if (*sep) {
			str = sep + 1;	/* start of command for next pass */
			*sep = '\0';
		} else {
			str = sep;	/* no more commands for next pass */
		}

		
		/* Extract arguments */
		if ((argc = parse_line(token, argv)) == 0) {
			rc = -1;	/* no command at all */
			continue;
		}
		
		if (process_command(argv[0], argc - 1, argv + 1))
			rc = -1;
		
	}
	
	return rc;
}

/**delect a char in buffer*/
static char * delete_char (char *buffer, char *p, int *colp, int *np, int plen)
{
	char *s;

	if (*np == 0) {
		return (p);
	}

	if (*(--p) == '\t') {			/* will retype the whole line	*/
		while (*colp > plen) {
			puts(erase_seq);
			(*colp)--;
		}
		for (s = buffer; s < p; ++s) {
			if (*s == '\t') {
				puts(tab_seq + ((*colp) & 07));
				*colp += 8 - ((*colp) & 07);
			} else {
				++(*colp);
				putchar(*s);
			}
		}
	} else {
		puts(erase_seq);
		(*colp)--;
	}
	(*np)--;
	return (p);
}

/** read console'input char
 * @param prefix 
 * @param buffer save input's char.
 * @return read length
 */
int readline_into_buffer(const char *const prefix, char *buffer)
{
	char *p = buffer;		
	char * p_buf = p;		/*save buffer's head*/
	int	n = 0;				/* buffer index		*/
	int	plen = 0;			/* prefix length	*/
	int	col;				/* output column cnt	*/
	char	c;

	/* print prefix */
	if (NULL != prefix) {
		plen = strlen(prefix);
		printf("%s", prefix);
	}
	
	col = plen;

	for (;;) {

		c = getchar();
		/* Special character handling */
		switch (c) {
		case '\r':			/* Enter*/
		case '\n':
			*p = '\0';
			puts("\r\n");
			return (p - p_buf);

		case '\0':			/* nul	*/
        case '?':			/* nul	*/
			continue;

		case 0x03:				/* ^C - break		*/
			p_buf[0] = '\0';	/* discard input */
			return (-1);

		case 0x15:				/* ^U - erase line	*/
			while (col > plen) {
				puts(erase_seq);
				--col;
			}
			p = p_buf;
			n = 0;
			continue;

		case 0x17:				/* ^W - erase word	*/
			p = delete_char(p_buf, p, &col, &n, plen);
			while ((n > 0) && (*p != ' ')) {
				p = delete_char(p_buf, p, &col, &n, plen);
			}
			continue;

		case 0x08:				/* ^H  - backspace	*/
		case 0x7F:				/* DEL - backspace	*/
			p = delete_char(p_buf, p, &col, &n, plen);
			continue;

		default:
           if (0 == isascii((int)c)) {
                continue;
            }
			/* Must be a normal character then*/
			if (n < MONITOR_LINE_MAX) {
				if (c == '\t') {	/* expand TABs */
					puts(tab_seq + (col & 07));
					col += 8 - (col & 07);
				} else {
					++col;		/* echo input */
					//putchar(c);
				}
				*p++ = c;
				++n;
			} else {			/* Buffer full*/
				putchar('\a');
			}
		} //switch (c)
	}//for (;;)
}

/** 
* command help 
*/
int do_help(int argc, char * const argv[])
{
	struct cmd_t *cmd;
	RB_NODE_T *result = NULL;
	int i;
	
	// show list of commands 
	if (argc == 0) {	
		// print short help
		result = rbtree_first(&command_tree);
		if (NULL != result) {
			do{
				cmd = (struct cmd_t *)result->item;
				if(NULL != cmd){
					if (NULL != cmd->help ){
						printf("%-*s- %s\n", CMD_WIDTH, cmd->name, cmd->help);
					} else {
						printf("%-*s- %s\n", CMD_WIDTH, cmd->name, "no help message\n");
					}
				}
				//next command
				result = rbtree_next(&command_tree, result);
				
			} while (NULL != result);
		} else {
			printf("no command is register\n");	
		}
		return 0;
	}
	
	/* command help (long version)*/
	for (i = 0; i < argc; ++i) {
		if ((cmd = find_command(argv[i])) != NULL) {
			cmd_help(cmd);
		} else {
			printf ("Unknown command '%s' - try 'help'"
				" without arguments for list of all"
				" known commands\n\n", argv[i]);
			return -1;
		}
	}
	return 0;
}


/**
* command help
*/
int cmd_openlog(int argc, char * const argv[])
{

	if ( (argc == 1) && (0 == strcmp(argv[0], "conn")) ){
		cmd_conn_log_msg();
	} else if( (argc == 1) && (0 == strcmp(argv[0], "interval"))){
		cmd_log_interval_ev();
	} else {
		printf("%s: 1\n", __FUNCTION__);
		printf("Usage: \n");
		printf("openlog [conn/interval]  \n");
		printf("e.g. openlog conn \n");
		printf("     openlog interval\n");
	}
	return 0;
}
int cmd_printflog(int argc, char * const argv[])
{
	if ( (argc == 1)  ){
		int id =strtol(argv[0],NULL,10);
		cmd_printf_log(1, id);
	} else if(argc == 0){
		cmd_printf_log(0, 0);
	}else{
		printf("%s: 1\n", __FUNCTION__);
		printf("Usage: \n");
		printf("printflog [service id]  \n");
		printf("e.g. OPEN : printflog 230 \n");
		printf("     CLOSE: printflog \n");
	}
	return 0;
}

int cmd_modify_ip_port(int argc, char * const argv[])
{
	if ( argc == 3){
		int appId =strtol(argv[0],NULL,10);
		int port =strtol(argv[2],NULL,10);
		return set_service_ip_port(appId, argv[1],  port);
	}else {
		printf("%s: 3\n", __FUNCTION__);
		printf("Usage: \n");
		printf("md_ipport [serviceID] [ip] [port] \n");
		printf("e.g. md_ipport serviceID ip port\n");
	}
	return 0;
}

int cmd_exit_subsys(int argc, char * const argv[])
{
	exit(0);
	return 0;
}

/**register all platform level commands
 */
void plat_cmd_init()
{
	insert_command("help", do_help, "print command description/usage");
	insert_command("lgs", disp_all_services, "list known global services");
	insert_command("send", cmd_send_event, "send event code to a service ,send -h from to code ");
	insert_command("dbuf", disp_buffer_info, "display buffer pool info");	
	insert_command("tbuf", buffer_test, "auto run test buffer poll code");		
	insert_command("conn", cmd_display_conns, "display alive connection");
	insert_command("queue", cmd_display_queue, "display first event from queue of esinfo");
	insert_command("timer", cmd_timer, "display or delete alive timer");
	insert_command("log", cmd_log, "enable disable dump log message");
	insert_command("ver", dump_ver, "enable disable dump log message");
	insert_command("ld0", dump_to_terminal, "dump log to terminal, equal to 'log dump 0' ");
	insert_command("et", cmd_event_test, "send times event for test, et -h from to length times ");
	insert_command("openlog", cmd_openlog, "open the connect_manager's log_msg or set if log interval event ");
	insert_command("printflog", cmd_printflog, "open the ev_service.c's es_info->dispatch printf ");
	insert_command("md_ipport", cmd_modify_ip_port, "modify service ip & port ");
	insert_command("exit", cmd_exit_subsys, "exit sub system by exec() funcs, not abort() funcs ");

	//insert_command("mulock", cmd_is_mutex_unlock, "open/close the mutex unlock");

}

/** init the commands
 * this should be called after all service created and started
 */
void monitor_init()
{
	rbtree_init(&command_tree, KEY_STRING);
	plat_cmd_init();
}

/** start the command line loop
 * this should be called after all service created and started
 */
void monitor_run()
{

	char cmd_line[MONITOR_LINE_MAX + 1];
	int len;
	

	for (;;) {
		memset(cmd_line, 0x0, MONITOR_LINE_MAX + 1);
		len = readline_into_buffer(PREFIX, cmd_line);
		if (len == -1) {
			puts("<INTERRUPT>\n");
		} else {
			if (0 == strncmp(cmd_line, "exit", 4)) {
				return;
			}
			parse_run_command(cmd_line, len);
		}
	}
}




