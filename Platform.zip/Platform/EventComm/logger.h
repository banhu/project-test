/**@file
 * Copyright (C) 2013, Sinovision Tech Ltd.
 * All rights reserved.
 *
 * @brief   This file defines the interface to LOG 
 *
 * @author  
 * @date 2013-7-19
 *
 */
#ifndef _LOGGER_H_
#define _LOGGER_H_

#include <stdint.h>
#include <stdarg.h>

#include "ev_service.h"


enum log_level_t{
	LOG_EVENT = 0,
	LOG_LEVEL_ERR,
	LOG_LEVEL_WARNING,
	LOG_LEVEL_NOTICE,
	LOG_LEVEL_INFO,
	LOG_LEVEL_DEBUG,
	LOG_LEVEL_MAX,
};

enum log_opt_t{
	LOG_OPT_CONS = 0,
	LOG_OPT_FILE,
	LOG_OPT_SVC,
	LOG_OPT_MAX,
};


/**record log message
@level  log level
@fmt	log content
*/
void log_msg(unsigned int level, const char *fmt, ...);

void log_raw(unsigned int level, const char *fmt, va_list arg);

/** init logger*/
void logger_init(void);

/**exit logger*/
void logger_exit(void);

/**log event add to log event queue
@event which event to log
*/
void log_event(void *event);


void init_evet_meta_tree();

/**display the event header
 */
void disp_ev_header(const EVENT_HEADER_TYPE *event);

void process_ev_log_dump(EV_LOG_DUMP_TYPE *event);
#endif // _LOGGER_H_
