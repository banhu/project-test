/**@file
 * Copyright (C) 2013, Sinovision Tech Ltd.
 * All rights reserved.
 *
 * @brief   This file impelment the event service interface
 *
 * @author
 * @date 2013-4-7
 *
 */


#include <assert.h>
#include <errno.h>
#include <unistd.h>
#include <signal.h>
#include "timer.h"
#include "ev_service.h"
#include "sys_topology.h"
#include "malloc.h"
#include "rbtree.h"
#include "monitor.h"
#include "logger.h"


static os_thread_key_t key;             ///< The key for thread specific data.
os_mutex_t es_mutex;             ///< The thread list protection mutex.
ESINFO_T *services;            //< The global service list.
DEVINFO_T *devices = NULL;			//gloable devices
os_mutex_t dev_mutex;		//devices protection mutex
extern os_mutex_t conn_mutex;		//connection protection mutex


extern RB_TREE_T dev_tree;

static int printf_log = 0;
static SVCID evMsgId = 0;

int cmd_printf_log(int log, int id)
{
	evMsgId = id;
	printf_log = log;
	printf("printf log is: %s \n then catch SVCID is: %d\n",(printf_log==1) ? "Open":"Close", evMsgId);
	return 0;
}

#define PRINTFLOG_BY_ID(rid, sid, fmt, ...) \
    if (1 == printf_log && (rid == evMsgId || sid == evMsgId)) \
        printf(fmt, __VA_ARGS__)


/** action when thread exit
*/
static void on_exit(void *data)
{
    ESINFO_T *es_info = (ESINFO_T *)data;       // Get the service specific data.

	destory_conn_by_svcid(es_info->sid);
    // remove the es_info from the service list
	os_mutex_lock(es_mutex);
    ESINFO_T *prev_es, *cur_es;
    for (prev_es= NULL, cur_es = services; cur_es; cur_es = cur_es->next) {
        if (cur_es == es_info) {
            if (prev_es) {
                prev_es->next = cur_es->next;
            } else {
                services = cur_es->next;
            }
            break;
        }
		prev_es = cur_es;
    }

	destroy_svc_timer(es_info);
	remove_device_bysvc(es_info);

	// clear the queue and release buffer
	while(queue_size(es_info->queue) != 0){
		void* temp = queue_get(es_info->queue);
		if (NULL != temp) {
			buffer_release(temp);
		}
	}

	queue_free(&es_info->queue);
	es_info->queue = NULL;

	os_mutex_unlock(es_mutex);

    buffer_release((void*)es_info);
	es_info = NULL;

}

/** init function, called once when process starts
*/
static void init(void)
{
	// init the memory pool
	buffer_init();

	os_recursive_mutex_init(es_mutex);
	os_recursive_mutex_init(dev_mutex);
    os_recursive_mutex_init(conn_mutex);
	os_thread_key_create(&key, on_exit);
	//parse the config file to initialize global service, process, ip, and port information
	init_sys_topo();

	// init the debug monitor command trees
	monitor_init();

	timer_init();

	logger_init();

    init_evet_meta_tree();
}

/** Create new event service information.
 */
static ESINFO_T *new_esinfo(const char *name)
{
    ESINFO_T *es_info = (ESINFO_T *)buffer_get(sizeof(ESINFO_T));
    assert(es_info != NULL && "Can't allocate service specific data");
    es_info->name = name;
    os_thread_initvar(es_info->id);
	FD_ZERO(&es_info->wset);
	FD_ZERO(&es_info->rset);
    es_info->maxFd = 0;
    os_sem_init(es_info->sem, 0);
    es_info->queue = queue_new();
    return es_info;
}


/** initialize the socket and create io processing thread
 */
static void init_sockset(ESINFO_T *es_info)
{

	//SERVICE_TYPE *svc = lookup_service(es_info->sid);
	//assert(svc != NULL && "cannot find the service info");

	//int port = ntohs(svc->addr.sin_port);

	signal(SIGPIPE, SIG_IGN);
	//create the socket handling thread
    int priority = es_info->priority;
    if (priority != 0) {
        priority--;
    }

    /* Create self pipe to wakeup the select call*/
    int res = pipe(es_info->pipe_fd);
    assert(res != -1 && "pipe creation failed");

    os_thread_create(0, // No create
                     &es_info->soc_id,
                     priority, // priority
                     10240, // stack
                     socket_handler,
                     es_info,
                     es_info->detach);    // detach

  //  tcp_listen(es_info, port,65000); //huyf 2014-10-22 move to socket_handler

}

/**
 *add default device which belong to the service
 *@param es_info
 *@return -1 is failed 0 is success
 */
static int init_device(ESINFO_T *es_info)
{
	RB_NODE_T *result = NULL;
	PLATFORM_DEVICE_TYPE *dev_tmp;
	DEVINFO_T *dev_info;

	assert((NULL != es_info) && "parameter es_info == NULL ");

	//first device
	result = rbtree_first(&dev_tree);
	while(NULL != result) {

		dev_tmp = (PLATFORM_DEVICE_TYPE *)result->item;

		os_mutex_lock(dev_mutex);

		//search device
		for (dev_info = devices; NULL != dev_info; dev_info = devices->next) {
			if ((es_info->sid == dev_tmp->svc_id) &&
				(0 == strcmp(dev_info->dev_name, dev_tmp->dev_file_name))) {
				// This device is already registered.
				break;
			}
		}
		//device belong to this service, add device
		if ((dev_info == NULL) && (es_info->sid == dev_tmp->svc_id)) {
			dev_info = open_device(dev_tmp->dev_file_name, dev_tmp->dev_id, es_info);
			if (NULL == dev_info) {
				printf("%s open device %s error\n", __FUNCTION__, dev_tmp->dev_file_name);
				os_mutex_unlock(dev_mutex);
				//next device
				result = rbtree_next(&dev_tree, result);
				continue;
			}
			dev_info->next = devices;
			devices = dev_info;
		}

		os_mutex_unlock(dev_mutex);

		//next device
		result = rbtree_next(&dev_tree, result);
	}

	return 0;
}

/** initialize the event service main thread related information
 */
static os_thread_once_t once = os_thread_once_init;     ///< Initialize once.
void* create_service(SVCID id, int priority, int detach, size_t stack,
                         int (*initialize)(os_thread_data_t),
                         int (*threadinitialize)(os_thread_data_t),
                         void (*dispatch)(EVENT_HEADER_TYPE*, void *),
                         os_thread_data_t data)
{
    // init the thread specified data
	os_thread_once(&once, init);		// Set up the service handler.

	os_mutex_lock(es_mutex);

	/*check if current service is a known service in system topology definition
	 */
	 char *name;
	name = validate_service(id);
	if(name == NULL){
		//if the app id was not predefined, need to add it when service init
		return NULL;
	}

	ESINFO_T *es_info = NULL;
	for (es_info = services; es_info; es_info = es_info->next) {
		if (es_info->sid == id) {
			// This service is already registered.
			break;
		}
	}
	if (es_info == NULL) {
		es_info = new_esinfo(name);
		es_info->next = services;
		services = es_info;
	}
	es_info->sid = id;
	es_info->priority = priority;
	es_info->stack = stack;
	es_info->prethread = initialize;
	es_info->threadinitialize = threadinitialize;
	es_info->dispatch = dispatch;
	es_info->arg = data;
	es_info->detach = detach;
	es_info->is_log = 1;
	rbtree_init(&(es_info->timer_tree), KEY_INT);
	os_mutex_unlock(es_mutex);

	//init service's device.must befor init_socket().
	init_device(es_info);

	//init socket listen and create a thread to handle read/write
	init_sockset(es_info);



	return es_info;
}



/** process the received data, call external dispatcher to process the event
 */
static void* process_message(void *arg)
{
//	printf(" \n process message operation entered! \n");

	ESINFO_T *es_info = (ESINFO_T*)os_thread_getspecific(key);

	EVENT_HEADER_TYPE *event = queue_get(es_info->queue);
	if(event == NULL)
		return NULL;

	event->received = get_epoch_time_nano();

    switch(event->code)
    {
    case EV_ECL_CONNECT: process_conn_event((EV_ECL_CONNECT_TYPE *)event);return NULL;
    case EV_LOG_DUMP: process_ev_log_dump((EV_LOG_DUMP_TYPE *)event);break;
    case EV_EVENT_TEST:process_event_test((EV_EVENT_TEST_TYPE *)event);break;
    case EV_SS_DEV_REPORT_VER:process_ver_event((EV_SS_DEV_REPORT_VER_TYPE *)event);break;
    case EV_SV_REQUEST_STATUS:process_event_sv_request((EV_SV_REQUEST_STATUS_TYPE *)event);break;
    default:
    {
    if(es_info->dispatch)
    {
        PRINTFLOG_BY_ID(event->sid, event->rid, "%s-->Line: %d,from %d to %d, event->code:%d ( 0x%x ) ---------start---------\n",__FUNCTION__, __LINE__, event->sid, event->rid, event->code, event->code);
		es_info->dispatch(event,arg);
		PRINTFLOG_BY_ID(event->sid, event->rid, "%s-->Line: %d,from %d to %d, event->code:%d ( 0x%x )  ----------end----------\n",__FUNCTION__, __LINE__, event->sid, event->rid, event->code, event->code);
    }
    }
    }
	event->complete = get_epoch_time_nano();
	log_event((void*)event);

	return NULL;
}


/** The thread entry
 */
static void *thread_entry(void *arg)
{
    ESINFO_T *es_info = (ESINFO_T *)arg;

    //os_mutex_lock(es_mutex);
    os_thread_setspecific(key, es_info);
    //es_info->id = os_thread_self();  //huyf 2014-10-21 delete  for valgrind DRD
    //printf("es_info->id:%s,%d,%d\n",__FUNCTION__,__LINE__,(int)os_thread_self());
    //printf("es_info->id:%s,%d,%d\n",__FUNCTION__,__LINE__,(int)es_info->id);
    //fflush(stdout);

    es_info->tid = syscall(SYS_gettid);

    //os_mutex_unlock(es_mutex);

	// Call the thread init function.
    if (es_info->threadinitialize){
        // Call the thread initialization function.
        es_info->threadinitialize(es_info->arg);
	}
	//printf("%s svc(%d)'s process thread start successful\n", __FUNCTION__, es_info->sid);
	for(;;){
        int status;
        do {
			// pending on a semaphore for ever
            status = os_sem_wait(es_info->sem);
            // Check for a timer expiration.
        } while (status < 0 && errno == EINTR);
		// enter event loop
		process_message(es_info->arg);
	}
	return NULL;

}


/** start all service in the process
 */
void start_services(void)
{
    os_mutex_lock(es_mutex);
    ESINFO_T *es_info;
	signal(SIGPIPE, SIG_IGN);
    for (es_info = services; es_info; es_info = es_info->next) {
        if (os_thread_get(es_info->id)) {
            // Already started.
            continue;
        }
        // Call the pre-thread initialization function.
        int status = 0;
        if (es_info->prethread) {
            status = es_info->prethread(es_info->arg);
        }
        // start the thread
        if (status >= 0) {
			//printf("%s create svc(%d)'s process thread \n", __FUNCTION__, es_info->sid);
            status = os_thread_create(0,
                                  &es_info->id,
                                  es_info->priority,
                                  es_info->stack,
                                  thread_entry,
                                  es_info,
                                  es_info->detach);
        }
    }
    os_mutex_unlock(es_mutex);
}

/** stop all service in the process
 */
void stop_services(void)
{
    os_mutex_lock(es_mutex);
    ESINFO_T *es_info;
	for (es_info = services; es_info; es_info = es_info->next) {
		if (!os_thread_get(es_info->id)) {
		    // Not Running.
		    continue;
		}
		os_thread_cancel(es_info->id);
    }
    os_mutex_unlock(es_mutex);
}

/* Start a service.
 * This function starts the named service.
 * huyf This funtion is not in use
 */
int start_service(SVCID id, int noCreate)
{
    os_mutex_lock(es_mutex);
    ESINFO_T *es_info;
	signal(SIGPIPE, SIG_IGN);
    for (es_info = services; es_info; es_info = es_info->next) {
        if (es_info->sid == id) {
            break;
        }
    }
	// if service did not find in the service list, then return
	if (es_info == NULL || os_thread_get(es_info->id)) {
	    os_mutex_unlock(es_mutex);
	    return (int)es_info;
	}

    // Call the pre-thread initialization function.
    int status = 0;
    if (es_info->prethread) {
        status = es_info->prethread(es_info->arg);
    }
    os_mutex_unlock(es_mutex);

    if (status >= 0) {
        status = os_thread_create(noCreate,
                                  &es_info->id,
                                  es_info->priority,
                                  es_info->stack,
                                  thread_entry,
                                  es_info,
                                  es_info->detach);
    }
    return status < 0 ? (int)NULL : (int)es_info;
}

/** Stop a service.
 * @param name name of service to stop.
 * @return 0 = success.
 * huyf This funtion is not in use
 */
int stop_service(SVCID id)
{
    os_mutex_lock(es_mutex);
    ESINFO_T *es_info;
    for (es_info = services; es_info; es_info = es_info->next) {
        if (es_info->sid == id) {
            break;
        }
    }

    if (es_info == NULL || (os_thread_get(es_info->id) == 0) ) {
        os_mutex_unlock(es_mutex);
        return -1;
    }

    int status = os_thread_cancel(es_info->id);

    os_thread_initvar(es_info->id);

    os_mutex_unlock(es_mutex);
    return  status;
}

/** Kill a service.
 * @param name name of service to kill.
 * @return 0 = success.
 */
int kill_service(SVCID id)
{
    int status = 0;
    os_mutex_lock(es_mutex);
    void * retval;
    ESINFO_T *es_info;
    os_thread_t pid;
    os_thread_t soc_id;
    for (es_info = services; es_info; es_info = es_info->next) {
        if (es_info->sid == id) {
            break;
        }
    }
    // service not found or has been killed already
    if (es_info == NULL || os_thread_get(es_info->id) == 0) {
        os_mutex_unlock(es_mutex);
        return -1;
    }
    pid= es_info->id;
    soc_id = es_info->soc_id;
    // close local pipe
    close(es_info->pipe_fd[0]);
    close(es_info->pipe_fd[1]);
    // cancel the socket handling thread
	if (status == 0 && os_thread_get(soc_id)) {
	    status = os_thread_cancel(soc_id);
        if(!es_info->detach){
            os_mutex_unlock(es_mutex);
            os_thread_join(soc_id,&retval);
            os_mutex_lock(es_mutex);
        }
 	    os_thread_initvar(soc_id);
	}
    // cancel the thread
    if (os_thread_get(pid)) {
        status = os_thread_cancel(pid);
        if(!es_info->detach){
            os_mutex_unlock(es_mutex);
            os_thread_join(pid,&retval);
            os_mutex_lock(es_mutex);
        }
        os_thread_initvar(id);
    }

    os_mutex_unlock(es_mutex);
    return status;
}

/** find service in process
 */
ESINFO_T* find_service_inp(int id)
{
    ESINFO_T *es_info;
    ESINFO_T *result = NULL;
    for (es_info = services; es_info; es_info = es_info->next) {
        if (es_info->sid == id) {
            // This service is already registered.
        	result = es_info;
            break;
        }
    }
    return result;
}

/** get the event  service info for runing service
 */
ESINFO_T* get_es_info()
{
	ESINFO_T *es_info = (ESINFO_T*)os_thread_getspecific(key);
	return es_info;
}



void display_services()
{
    ESINFO_T *es_info;
	printf("\nIn current process:\n");
	printf("service# \t service name  \n");
    for (es_info = services; es_info; es_info = es_info->next) {
        int count;
        os_sem_count(es_info->sem, count);
		printf("    %d\t %16s %d %d queue size = %d, sem count =  %d\n", \
            es_info->sid, es_info->name, (int)es_info->tid, (int)es_info->soc_tid,  \
            queue_size(es_info->queue), count);
    }
}


/**waiting for event within certain time
 * intend for test only
 * NOTE: the memory buffer will not be released after event process
 */
void* receive_message(int*time_elapsed, int timeout_ms)
{
    int status;
	void *data = NULL;
    ESINFO_T *es_info = get_es_info();
	uint64_t cur_time = get_epoch_time_nano();
	uint64_t abs_time = cur_time +timeout_ms*1e6;
	struct timespec ts;
	ts.tv_sec = abs_time/1000000000LL;
	ts.tv_nsec = abs_time%1000000000LL;
	status = os_sem_timedwait(es_info->sem, &ts);
	if(status == 0){
		// no error happened
		data  = queue_get(es_info->queue);
		//disp_ev_header(data);
		}
	*time_elapsed = (get_epoch_time_nano()-cur_time )/1000000;
    return data;
}


/**waiting for event within certain time
 * intend for test only
 * NOTE: the memory buffer will not be released after event process
 */
void* wait_message(unsigned int code,int*time_elapsed, int timeout_ms)
{
    int status;
    EVENT_HEADER_TYPE * hdr = NULL;
    void *temp = NULL;
	void *data = NULL;
    int i=0;
    ESINFO_T *es_info = get_es_info();
	uint64_t cur_time = get_epoch_time_nano();
	uint64_t abs_time = cur_time +timeout_ms*1e6;
	struct timespec ts;
	ts.tv_sec = abs_time/1000000000LL;
	ts.tv_nsec = abs_time%1000000000LL;

    if(queue_size(es_info->queue) > 0)
    {
        for(i=0;i<queue_size(es_info->queue);i++){
    		temp  = queue_get(es_info->queue);
            hdr = ( EVENT_HEADER_TYPE *)temp;
            assert(hdr != NULL && "the data pointer from queue cannot be null");
            if(hdr->code == code)
               data = temp;
            else
               queue_add(es_info->queue, temp) ;

        }
        if(NULL != data)
            return data;
     }


	status = os_sem_timedwait(es_info->sem, &ts);
	if(status == 0){
  		// no error happened
        for(i=0;i<queue_size(es_info->queue);i++){
    		temp  = queue_get(es_info->queue);
            hdr = ( EVENT_HEADER_TYPE *)temp;
            assert(hdr != NULL && "the data pointer from queue cannot be null");
            if(hdr->code == code)
               data = temp;
            else
               queue_add(es_info->queue, temp) ;

        }
		//disp_ev_header(data);
		}
	*time_elapsed = (get_epoch_time_nano()-cur_time )/1000000;
    return data;
}


SVCID self_id()
{
    ESINFO_T *es_info = (ESINFO_T*)os_thread_getspecific(key);

    assert((NULL != es_info) && "the service info is NULL");

    return es_info->sid;
}


int main_thread_suspend()
{
    return join_timer_thread();
}
