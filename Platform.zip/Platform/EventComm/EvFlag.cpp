/**@file 
 * Copyright (C) 2013, Sinovision Tech Ltd.
 * All rights reserved.
 *
 * @brief  this file implements the interface of event flag
 *
 * @author  
 * @date 2013-5-14
 *
 */
 
#include <assert.h>
#include <time.h>

#include "EvFlag.h"
#include "ev_service.h"


using namespace ECL;

EvFlag::EvFlag()
{
	currentFlag = 0;
	subscribeList = NULL;
	os_sem_init(sem,1);
}

EvFlag::~EvFlag()
{
	os_sem_destroy(sem);
	while( NULL != subscribeList)
	{
		FLAG_WAIT_TYPE * next = subscribeList->next;
		delete subscribeList;
		subscribeList = next;
	}
}

int EvFlag::clear(uint32_t flag)
{
    os_sem_wait(sem);
    currentFlag = currentFlag & (~flag);
    os_sem_post(sem);
    return 0;
}

uint32_t EvFlag::inquiry()
{
   return currentFlag;
}

int EvFlag::post(uint32_t flag)
{
    int status = 0;
    os_sem_wait(sem);
    /**update current flags
	*/
    currentFlag = currentFlag | flag;

    /**check if any suspend need to be wakeup
	*/	
	FLAG_WAIT_TYPE *list = subscribeList;
	while( NULL != list)
    {
		if (true == list->inUse)
		{
		    if (((list->pendType == FLAG_AND) &&
			 ((currentFlag & list->waitFlags) == list->waitFlags)) ||
			    ((list->pendType == FLAG_OR) &&
			     ((currentFlag & list->waitFlags) != 0)))
		    {
				list->inUse = false;
                ECService::sendEvent(list->id,list->evCode);
		    }
		}
		list = list->next;
    }
    os_sem_post(sem);
    return status;
}


int EvFlag::subscribe(uint32_t waitFlags, FLAG_PEND_TYPE type, uint32_t code)
{
    SVCID  id = ECL::self_id();
    int status = 0;
    os_sem_wait(sem);
	/*if the flags have been set, return immediately*/
    if (((type == FLAG_AND) &&
	 ((currentFlag & waitFlags) == waitFlags)) ||
	    ((type == FLAG_OR) &&
	     ((currentFlag & waitFlags) != 0)))
    {
		ECService::sendEvent(id,code);
	    os_sem_post(sem);
		return 0;
    }
	/*get a not used item in suspend list or create a new one*/
    FLAG_WAIT_TYPE *subscribeItem = subscribeList;
	FLAG_WAIT_TYPE *last = subscribeList;
    while ((subscribeItem != NULL) && (subscribeItem->inUse == true))
    {    	
		last = subscribeItem;
		subscribeItem = subscribeItem->next;
    }
    if (subscribeItem == NULL)
    {
		subscribeItem = new FLAG_WAIT_TYPE;
 		assert(subscribeItem != NULL && "allocate flag suspend list memory failed"); 
		if(last != NULL)
			last->next = subscribeItem;
		memset(subscribeItem, 0, sizeof(FLAG_WAIT_TYPE));
		subscribeItem->next = NULL;
		if(subscribeList == NULL)
			subscribeList = subscribeItem;
    }
	subscribeItem->inUse = true;
	subscribeItem->waitFlags = waitFlags;
	subscribeItem->pendType = type;
    subscribeItem->evCode = code;
    subscribeItem->id = id;
    os_sem_post(sem);
    
	return status;
}


void EvFlag::unSubscribe(uint32_t waitFlags)
{
    SVCID  id = ECL::self_id();
	FLAG_WAIT_TYPE *list = subscribeList;

    os_sem_wait(sem);
	while( NULL != list)
    {
		if (true == list->inUse)
		{
		    if( (list->id == id) && (list->waitFlags == waitFlags) ){
                list->inUse = false;
		    }
		}
		list = list->next;
    }   
    os_sem_post(sem);    
}




 
