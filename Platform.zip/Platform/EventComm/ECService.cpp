/**@file 
 * Copyright (C) 2013, Sinovision Tech Ltd.
 * All rights reserved.
 *
 * @brief  this file implements the C++ interface of event comm service
 *
 * @author  
 * @date 2013-3-1
 *
 */

#include <stdio.h>
#include "malloc.h"

#include "ECService.h"
//#include "systemService.h"

/** Construct a EC service.
 */
ECService::ECService(SVCID id, int priority, bool detach, size_t stack,os_thread_data_t arg)
:id(id) 
{
	// register the service
	ECL::create_service(id,\
	                       priority,\
	                       detach, \
	                       stack, \
	                       preThread,\
	                       threadInit,\
	                       dispatchEvent,\
	                       (os_thread_data_t)this);
	// initialize the event rb tree
	rbtree_init(&evTree, KEY_INT);
}

/** Delete a EC service.
 */
ECService::~ECService()
{
    ECL::stop_service(getID());
    ECL::kill_service(getID());
    RB_NODE_T *result;
    for(result = rbtree_first(&evTree);  \
            result!= NULL;  \
            result = rbtree_next(&evTree,result)){
        ECL::buffer_release((char*)result->item);
        rbtree_remove(&evTree,result);
    }
}

/** Start a Service
 * @param noCreate Use the current (calling) thread instead of creating one.
 * @return ECL_OK if the thread is started successfully.
 */
int ECService::start(bool noCreate)
{
	return 0;
}


/** Start all registered threads.
 */
void ECService::startAll()
{ 
	ECL::start_services();
}

/** Register an event call back function.
 * @param event The event code.
 * @param handler The event handling function.
 */
void ECService::registerEvent(uint32_t event, EventHandler handler)
{
	EVENT_TYPE* ev = (EVENT_TYPE*)ECL::buffer_get(sizeof(EVENT_TYPE));
	ev->code = event;
	ev->handler = handler;
	if(NULL == rbtree_insert(&evTree, (void*)event, (void*)ev) )
	{
		// error happened
	}
}

/**
  *remove device from service's devs
  *@param dev_name
  *@param dev_id
  *@return -1 is failed,0 is successful
 */
int ECService::registerDevice(char *dev_name, int dev_id)
{
	return ECL::register_device(dev_name, dev_id);
}

/**
  *find fd by dev id .
  *@param dev_id
  *@return the fd we find,-1 we don't find it;
 */
int ECService::find_fd_by_id( int dev_id)
{
	return ECL::find_fd_by_id(dev_id);
}


/**
  *register device to service's devs
  *@param dev_name
  *@return -1 is failed,0 is successful
 */
int ECService::removeDevice(char *dev_name)
{
	return ECL::remove_device(dev_name);
}

/**
  *register device to service's devs
  *@param dev_id
  *@return -1 is failed,0 is successful
 */
int ECService::removeDeviceByid(int dev_id)
{
	return ECL::remove_device_byid(dev_id);
}

/** Send a event with payload to destination service
 */
int ECService::sendEvent(SVCID to, uint32_t code, void* event, size_t size, bool noLog)
{
	((EVENT_HEADER_TYPE*)event)->code = code;
    //((EVENT_HEADER_TYPE*)event)->not_log = noLog;
	return ECL::send_event(to, (EVENT_HEADER_TYPE*)event, size, noLog);
}


/** Send a event with payload to destination service
 */
int ECService::sendEventFrom(SVCID from, SVCID to, uint32_t code, void* event, size_t size, bool noLog)
{
	((EVENT_HEADER_TYPE*)event)->code = code;
    //((EVENT_HEADER_TYPE*)event)->not_log = noLog;
	return ECL::send_event_from(from, to, (EVENT_HEADER_TYPE*)event, size, noLog);
}

/** Send an event code to destination service.
 */
int ECService::sendEvent(SVCID to, uint32_t code, bool noLog)
{
    EVENT_HEADER_TYPE header;
	return sendEvent(to, code, (char*)&header, sizeof(EVENT_HEADER_TYPE), noLog);
}

/** Send a event with payload to destination service
 */
int ECService::sendEventToDev(char *dev_name, uint32_t code, void* event, size_t size)
{
	((EVENT_HEADER_TYPE*)event)->code = code;
	return ECL::send_event_todev(dev_name, (EVENT_HEADER_TYPE*)event, size, 0);
}

/** Send an event code to destination service.
 */
int ECService::sendEventToDev(char *dev_name, uint32_t code)
{
    EVENT_HEADER_TYPE header;
	return sendEventToDev(dev_name, code, (char*)&header, sizeof(EVENT_HEADER_TYPE));
}

/** Send a event without payload to the service itself
 */
int ECService::sendSelfEvent(uint32_t code)
{
    EVENT_HEADER_TYPE header;
	return sendSelfEvent(code,(void*)&header, sizeof(header));
}

/** Send a event without payload to the service itself
 */
int ECService::sendSelfEvent(uint32_t code, void* event, size_t size)
{
	((EVENT_HEADER_TYPE*)event)->code = code;
	return ECL::send_event_from(getID(), getID(), (EVENT_HEADER_TYPE*)event, size, 0);

}



/** Default handler of events
* @param event event pointer for processing
*/
void ECService::defaultHandler(EVENT_HEADER_TYPE *event)
{
	//printf(" \n default event handler \n");
}

/** Process an event
* @param event event pointer for processing
*/
void ECService::processEvent(EVENT_HEADER_TYPE *event)
{
	RB_NODE_T *result = NULL;
	result = rbtree_find(&evTree, (void*)event->code);
	if(result){
		// find event registered
		EVENT_TYPE* ev = (EVENT_TYPE*)result->item;
		EventHandler handler = ev->handler;
		(this->*handler)(event);
	}
	else{
		// no matched event found, use default event handler
		defaultHandler(event);
 	}
}

/** Static entry of pre thread start operation
* @param arg this pointer of the class
*/
int ECService::preThread(os_thread_data_t arg)
{
    ECService* ptr = (ECService*) arg;
    return ptr->initialize();
}

/** Static entry of initialize operation after thread start 
* @param arg this pointer of the class
*/
int ECService::threadInit(os_thread_data_t arg)
{
	ECService* ptr = (ECService*) arg;
    return ptr->threadInitialize();
}

/** Static entry of event processing
* @param event event pointer for processing
* @param arg this pointer of the class
*/
void ECService::dispatchEvent(EVENT_HEADER_TYPE *event, void *context)
{
	ECService* this_ptr = (ECService*) context;
	this_ptr->processEvent(event);	
}

/** The thread initialization function.
 * @param data pointer of received data
 * @param timeoutMs timeout value in milliseconds
 * @return time elapsed in ms.
 */
void* ECService::receiveEvent(int*timeElapsed, int timeoutMs)
{
	return ECL::receive_message(timeElapsed, timeoutMs);
}


/**get a new buffer from mem pool
 * @param n the buffer size required 
 * @return the pointer to data of the buffer
 */ 
char * ECService::getBuffer(size_t n)
{
	return ECL::buffer_get(n);
}

/**  return a buffer to mem pool
 * @param data the pointer to data of the buffer
 */ 
void ECService::releaseBuffer(char *data)
{
	ECL::buffer_release(data);
}



/**wait until expected event happened or 
 * for test purpose only
 * @param code the event code expecting
 * @param ev event buffer pointer 
 * @param timeoutMs timeout value in milliseconds
 * @param status, 0 means succedded, -1 means error or timeout happened
 */ 
int ECService::waitEvent(unsigned int code, EVENT_HEADER_TYPE **ev, int timeoutMs)
{
	int status = -1;
	EVENT_HEADER_TYPE *data = NULL; 	
	int timeLeft= timeoutMs;
	int timePassed= 0;
	// wait until expecting event happened, or timeout happened
	while(timeLeft> 0){
		data =  (EVENT_HEADER_TYPE *)ECL::wait_message(code, &timePassed,timeoutMs);
		timeLeft -= timePassed;
		if(data!=NULL){
			if(data->code == code){
				*ev = data;
				status = 0;
				break;
			}
		}
	}
	return status;
}


/**
*@bref start a timer
*@code timer respond event code when timer expired
*@tmo_ms timer expiration time
*@option timer option
*
*@return zero is successful,other is failed
*/
int ECService::timerStart(uint32_t code, uint32_t tmo_ms, uint32_t option)
{
	if (TIMER_STATUS_NONEXITENT != timerStatus(code))
	{
		timerStop(code);
	}
	return ECL::ec_timer_start(code, tmo_ms, option);
}

/**
*@bref stop a timer
*@ev_code  event code which timer respond to service
*
*@return zero is successful,other is failed
*/
int ECService::timerStop(uint32_t ev_code)
{
	if (TIMER_STATUS_NONEXITENT != timerStatus(ev_code))
	{
		return ECL::ex_timer_stop(ev_code);
	}
	else
		return 0;

}

/**
*@bref get a timer's status
*@code timer respond event code when timer expired
*
*@return TIMER_STATUS
*/
int ECService::timerStatus(uint32_t code)
{
	return ECL::ec_timer_status(code);
}


/**record log message
@level  log level
@fmt	log content
*/
void ECService::logMsg(unsigned int level, const char *fmt, ...) //huyf same as log_msg
{
    va_list arg;
    va_start(arg, fmt);    
    ECL::log_raw(level, fmt, arg);    
    va_end(arg);
}

/**
*@bref connect to svc
*@to target service id.
*@enProbe is enable probe package
*@huyf  just use in ConnManagerTest.
*/
void ECService::connToSvc(SVCID to, int enProbe)
{
	ECL::connection_to_svc(to, enProbe);
}

int  ECService::sendVerToCtl(SVCID to)
{
	return  ECL::send_ver_to_ctl(to);
}

void ECService::setFpgaVer(EV_SS_FPGA_REPORT_VER_TYPE *ev)
{
	return  ECL::set_fpga_ver(ev);
}

char * ECService::setProcessName(char *name)
{
	return  ECL::set_process_name(name);
}


