/**@file
 * Copyright (C) 2013, Sinovision Tech Ltd.
 * All rights reserved.
 *
 * @brief   This file defines the interface to queue handling
 *         the queue is mutex protected for multi thread enviroment
 *
 * @author  
 * @date 2013-3-30
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <errno.h>
#include <err.h>

#include "queue.h"
#include "buffer.h"


/**  
 * create a and initialize a queue
 * @return the pointer to the queue
 */
QUEUE *queue_new(void) 
{
    QUEUE *q = malloc(sizeof(QUEUE));  //malloc the space for queue
    assert(q != NULL && "malloc(sizeof(QUEUE)) ERROR:queue cannot be NULL");

    q->base= (QNODE *)malloc(QUEUE_MAX * sizeof(QNODE));  //malloc the space for node
    assert( q->base != NULL && "malloc(QUEUE_MAX * sizeof(QUEUE)) ERROR:queue base cannot be NULL");

	os_recursive_mutex_init(q->mutex);

	//if (os_mutex_init(q->mutex) != 0) {                 //queue mutex
	//	perror("queue_new: mutex_init");
	//	return NULL;
	//}
    // initialize queue
    //q->items = 0;
    q->front = q->rear = 0;                       //queue is null
    q->size = QUEUE_MAX;                          //default queue size
    return q;
}

/**  
 * release a queue and all the contents
 * @param q  the pointer to the queue
 */
void queue_free(QUEUE **pq) {
	QUEUE *q = *pq;
	if (!q)
		return;

	if (q->base)                  //free the node
		free(q->base);
	os_mutex_destroy(q->mutex);   //free the mutex
	q->front = q->rear = 0;       //set queue is null
	//q->size = 0;
	free(q);                      //free the queue
}

/**  
 * add an item to tail of the queue
 * @param q  the pointer to the queue
 * @param data  the pointer to the item
 */
void queue_add(QUEUE *q, void *data) {
	if (!q)
		return;
	// TODO: remove those malloc, maybe create a node array when queue initialize

	os_mutex_lock(q->mutex);
	if((q->rear+1)%(q->size)==q->front)         //when add node from rear, check the queue if is full
	{
		q->size *=2;
		QNODE *p = (QNODE *)realloc(q->base,q->size * sizeof(QNODE));  //realloc the space for node
		if (!p)
		{
			q->size/=2;
			os_mutex_unlock(q->mutex);
			printf("%s-->realloc error return NULL\n", __FUNCTION__);
			return;
		}
		else              //when realloc not ok, set default
		{
			q->base = p;  //when realloc OK, set the point to q->base
			if (q->front > q->rear)         //when the front > rear should be move the front to end data to the new space
			{
				int i;
				for(i = q->front; i < q->size/2; i++)    //q->base data from  q->from to the end
				{
					q->base[q->size/2 + i] = q->base[i];  //move to new end
				}
				q->front +=  q->size/2;                  //set the new front
			}
		}
		//printf("q->size:%d   %s, %d\n",q->size, __FUNCTION__,__LINE__);
		//fflush(stdout);
	}
	q->base[q->rear] = data;                  //add the node
	q->rear = (q->rear + 1)%q->size;        //set the rear+1

	os_mutex_unlock(q->mutex);
}

/**  
 * add an item to head of the queue
 * @param q  the pointer to the queue
 * @param data  the pointer to the item
 */
void queue_add_head(QUEUE *q, void *data) {
	if (!q)
		return;

	os_mutex_lock(q->mutex);
	if((q->front-1 +q->size)%q->size== q->rear)      //when add node from head, check the queue if is full
	{
		q->size*=2;
		QNODE *p = (QNODE *)realloc(q->base,q->size * sizeof(QNODE));  //realloc the space for node
		if (!p)
		{
			q->size/=2;
			os_mutex_unlock(q->mutex);
			printf("%s-->realloc error return NULL\n", __FUNCTION__);
			return;
		}
		else              //when realloc not ok, set default
		{
			q->base = p;  //when realloc OK, set the point to q->base
			if (q->front > q->rear)         //when the front > rear should be move the front to end data to the new space
			{
				int i;
				for(i = q->front; i < q->size/2; i++)    //q->base data from  q->from to the end
				{
					q->base[q->size/2 + i] = q->base[i];  //move to new end
				}
				q->front +=  q->size/2;                  //set the new front
			}
		}
		//printf("q->size:%d   %s, %d\n",q->size, __FUNCTION__,__LINE__);
		//fflush(stdout);
	}

	q->front = (q->front-1 + q->size)%(q->size);       //set the front before,because the old front is had a data now
	q->base[q->front] = data;                            //add the node to the front
	os_mutex_unlock(q->mutex);
}


/**  
 * get an item from the head of the queue
 * @param q  the pointer to the queue
 * @return the pointer to the item
 */
void *queue_get(QUEUE *q) {
	if (!q)
		return NULL;
	else
		os_mutex_lock(q->mutex);
	if (q->front == q->rear){ // Can happen in free
		q->front = q->rear = 0;       //set queue is null
	    os_mutex_unlock(q->mutex);
		return NULL;
	}
	void *data = q->base[q->front];            //get the front data
	q->front =(q->front + 1)%(q->size);        //set the front + 1
	os_mutex_unlock(q->mutex);

    return data;
}

/**  
 * query the size of the queue
 * @param q  the pointer to the queue
 * @return the pointer to the queue
 */
int queue_size(QUEUE *q)
{
	int size;
    if(q)
    {
    	os_mutex_lock(q->mutex);
		size =  (q->rear - q->front +q->size)%(q->size);       //get the size of queue
		os_mutex_unlock(q->mutex);
		return size;
    }
	else
		return (int)NULL;
}

void queue_flush(QUEUE *q)
{
	void *buf = NULL;

	os_mutex_lock(q->mutex);
	while((buf = queue_get(q)) != NULL)
	{
		buffer_release(buf);
	}
	os_mutex_unlock(q->mutex);


}


