/**@file 
 * Copyright (C) 2013, Sinovision Tech Ltd.
 * All rights reserved.
 *
 * @brief   LOGGER
 *
 * @author  
 * @date 2013-7-19
 *
 */
#include <stdio.h> 
#include <stdlib.h> 
#include <string.h>
#include <signal.h>
#include <time.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <stdint.h>
#include <assert.h>


#include "ev_comm.h"
#include "ev_service.h"
#include "buffer.h"
#include "monitor.h"
#include "logger.h"
#include "event_meta.h"


#define LOGGER_QUEUE_MAX	(2000)
#define LOGGER_LEVEL_DEF	(5)

#define	LOG_MAX_FILE_LEN	(255)
#define LOG_FILE_PATH		"/var/log/"
#define	LOG_MAX_LINE_LEN	(512)
#define LOG_EVNET_SIZE		(3000)//(1536)

extern ESINFO_T *services;

static int queue_index = 1;
static int is_log_init = 0;
static int log_level = LOGGER_LEVEL_DEF;
static int is_log_event = 1;
static int is_log_conn_event = 0;
static int is_log_platform = 1;
static struct QUEUE *log_ev_q;

static RB_TREE_T evMetaTree;

//huyf delete 2014-10-15
//extern uint64_t get_epoch_time_nano();


/**display the time in readable mode
 */

void display_time(uint64_t t)
{
    char buf[26];
	time_t sec = t / 1e9;
	uint32_t  nsec = t % 1000000000l;
	char* str = ctime(&sec);
	if(NULL == str){
		printf(" ctime call failed \n");
	}
	strcpy(buf, str);
	buf[24] = ' '; // remove the new line at the end of the string
	printf("%s%06u", buf, nsec);
}


/**display the event header
 */
void disp_ev_header(const EVENT_HEADER_TYPE *event)
{
	ESINFO_T *es_info = get_es_info();
	printf("\n\nevent logged by service  %s\n", es_info->name);
	printf("event code is 0x%8x \n", event->code);
	char * name = get_service_name(event->sid);
    printf("        %s", name ? name: "(NULL)");
	name = get_service_name(event->rid);
    printf("===>%s\n", name? name: "(NULL)");
    printf("    length %d  checksum %d \n", event->length, event->checksum);

    printf("    sent     at\t");
    display_time(event->sent);
	printf("\n");

	if (event->received) {
        printf("    received at ");
        display_time(event->received);
        printf("    elapse: %lld usec\n", (event->received - event->sent)/1000);
    } else {
        printf("not received\n");
    }

	if (event->complete) {
        printf("    complete at ");
        display_time(event->complete);
        printf("    elapse: %lld usec\n", (event->complete - event->received)/1000);
    } else {
        printf("not executed\n");
    }

}

/**display the event payload, in hex mode and ascii mode
 */
//void disp_ev_payload(const EVENT_HEADER_TYPE *event)
//{

//}


/**
 *convert the time to a readable string
 */ 
static int convert_time(uint64_t t, char *buf, unsigned int size)
{
	time_t sec;
	uint32_t  nsec = 0;
	char *str = NULL;
	int ret = 0, len = 0;
	
	
	assert((NULL != buf) && " buf is NULL \n");
	assert((size > 0) && " length is invalid \n");
	
	sec = t / 1e9;
	nsec = t % 1000000000l;
	str = ctime(&sec);
	
	if(NULL == str){
		printf("%s ctime call failed \n", __FUNCTION__);
		return -1;
	}
	
	len = strlen(str);
	if (len > size) {
		printf("%s buffer lenth is not enough\n", __FUNCTION__);
		return -1;
	}
	
	buf[0] = '<';
	strncpy(buf + 1, str, len);
	
	//remove the new line at the end of the string
	buf[len] = ' '; 
	
	len = len + 1;
	
	ret = snprintf(buf + len, size - len, "%06u>", nsec);
	if (ret < 0) {
		printf("%s snprintf error\n", __FUNCTION__);
		return -1;
	}
	
	return ret + len;
}

static inline int get_file_name(char *buf, int len)
{
	time_t now; 
    struct tm *timenow;
	int ret,buf_idx;

	assert((NULL != buf) && " buf is NULL \n");
	assert((len >= 9 +4 + 19) && " length is invalid \n");

	buf_idx =0;
	ret = snprintf(buf + buf_idx, len - buf_idx, "%s", LOG_FILE_PATH);
	if (ret < 0) {
		printf("%s snprintf error\n", __FUNCTION__);
		return -1;
	}
	buf_idx += ret;
	
	ret = snprintf(buf + buf_idx, len - buf_idx, "%s", "log_");
	if (ret < 0) {
		printf("%s snprintf error\n", __FUNCTION__);
		return -1;
	}
	buf_idx += ret;
	
	time(&now);
    timenow = localtime(&now);
    ret = strftime(buf + buf_idx, len - buf_idx, "%Y-%m-%d-%H:%M:%S", timenow); 
	if (ret < 0) {
		printf("%s strftime error\n", __FUNCTION__);
		return -1;
	}
	buf_idx += ret;

	return buf_idx;
}

/**
*/
static inline int dump_event_payload_hex(EVENT_HEADER_TYPE *event, char *log_buf, int len)
{
	int blen = 0, count = 0, ret = 0;
	int log_idx = 0;
	char *buf = NULL; 
	
	ret = snprintf(log_buf + log_idx, 
					   len - log_idx,  
					   "event 0x%08x 's paylod:\n",
					   event->code);
	if (ret < 0) {
		printf("%s sprintf error\n", __FUNCTION__);
		return ret;
	}
	log_idx += ret;
	
	blen = event->length - sizeof(EVENT_HEADER_TYPE);
	buf = (char *)event + sizeof(EVENT_HEADER_TYPE);
	count = 0;
	do {
		if (count % 32 == 0) {
			
			ret = 0;
			ret = snprintf(log_buf + log_idx, 
						   len - log_idx,  
						   "\n%08x: ",
						   count);		
			if (ret < 0) {
				printf("%s sprintf error\n", __FUNCTION__);
				return ret;
			}
			log_idx += ret;		
		}
		
		ret = 0;
		ret = snprintf(log_buf + log_idx, 
					   len - log_idx,  
					   "%02x ",
					   (unsigned char)buf[count]);
		if (ret < 0) {
			printf("%s sprintf error\n", __FUNCTION__);
			return ret;
		}
		log_idx += ret;	
	} while (++count < blen);
	
	
	ret = snprintf(log_buf + log_idx, 
				   len - log_idx,  
				   "\n\n");	
	if (ret < 0) {
		printf("%s sprintf error\n", __FUNCTION__);
		return ret;
	}
	log_idx += ret;	

	return log_idx;
}

static inline int dump_event_struct(STRUCT_META_TYPE *structMeta,
									 char *event, int evtBaseoffset, int index,
									 char *log_buf, int len)
{
	int ret = 0, log_idx = 0;
	
	assert((NULL != structMeta) && " STRUCT_META_TYPE is NULL \n");
	assert((len > 0) && " buffer length is error \n");
	assert((NULL != log_buf) && " buffer is NULL \n");
	assert((NULL != event) && " event is NULL \n");
	assert((evtBaseoffset > 0) && " event offset is error \n");

	
	switch(structMeta->type) {
		case VAR_TYPE_INT8:
			ret = snprintf(log_buf + log_idx,
					len - log_idx,  
					"%d",
					((int8_t *)(event + evtBaseoffset))[index]);
			break;
		case VAR_TYPE_INT16:
			ret = snprintf(log_buf + log_idx,
					len - log_idx,  
					"%d",
					((int16_t *)(event + evtBaseoffset))[index]);
			break;
		case VAR_TYPE_INT32:
			ret = snprintf(log_buf + log_idx,
					len - log_idx,  
					"%d", 
					((int32_t *)(event + evtBaseoffset))[index]);
			break;
		case VAR_TYPE_UINT8:
			ret = snprintf(log_buf + log_idx,
					len - log_idx,  
					"%u",
					((uint8_t *)(event + evtBaseoffset))[index]);
			break;
		case VAR_TYPE_UINT16:
			ret = snprintf(log_buf + log_idx,
					len - log_idx,  
					"%u",
					((uint16_t *)(event + evtBaseoffset))[index]);
			break;
		case VAR_TYPE_UINT32:
			ret = snprintf(log_buf + log_idx,
					len - log_idx,  
					"%u", 
					((uint32_t *)(event + evtBaseoffset))[index]);
			break;
		case VAR_TYPE_INT64:
			ret = snprintf(log_buf + log_idx,
					len - log_idx,  
					"%lld",
					((int64_t *)(event + evtBaseoffset))[index]);
			break;
		case VAR_TYPE_UINT64:
			ret = snprintf(log_buf + log_idx,
					len - log_idx,  
					"%llu",
					((uint64_t *)(event + evtBaseoffset))[index]);
			break;
		case VAR_TYPE_FLOAT:
			ret = snprintf(log_buf + log_idx,
					len - log_idx,  
					"%f",
					((float *)(event + evtBaseoffset))[index]);
			break;
		case VAR_TYPE_DOUBLE:
			ret = snprintf(log_buf + log_idx,
					len - log_idx,  
					"%lf", 
					((double *)(event + evtBaseoffset))[index]);
			break;
		case VAR_TYPE_STRING:

			break;
		default:
			printf("unsport STRUCT_META_TYPE->type %d\n", structMeta->type);
			ret = 0;
	}
	if (ret < 0) {
		printf("%s sprintf error\n", __FUNCTION__);
		return ret;
	}
	log_idx = log_idx + ret;

	return log_idx;
}
/**
*/
static inline int dump_event_payload(EVENT_HEADER_TYPE *event, 
									 EVENT_META_TYPE *eventMeta, 
									 char *log_buf, int len)
{
	STRUCT_META_TYPE *structMeta = NULL;
	int count = 0, ret = 0;
	int log_idx = 0;
	char *buf = NULL; 
	

	assert((NULL != event) && " event is NULL \n");
	assert((NULL != eventMeta) && " event meta type is NULL \n");
	assert((len > 0) && " buffer length is error \n");
	assert((NULL != log_buf) && " buffer is NULL \n");
	
	ret = snprintf(log_buf + log_idx, 
					   len - log_idx,  
					   "event 0x%08x %s 's paylod:\n",
					   event->code, eventMeta->name);
	if (ret < 0) {
		printf("%s sprintf error\n", __FUNCTION__);
		return ret;
	}
	log_idx += ret;
	if (log_idx >= len)
		return log_idx;
	
	structMeta = (STRUCT_META_TYPE *)eventMeta->meta;
	if (NULL == structMeta) {
		printf("%s EVENT_META_TYPE->meta is NULL\n", __FUNCTION__);
		return 0;
	}

	buf = (char *)event;
	
	for ( ; NULL != structMeta && structMeta->offset != -1 && NULL != structMeta->name;
			structMeta = structMeta + 1) {

		if (0 == strcmp("reserved", structMeta->name) ||
			0 == strcmp("spare", structMeta->name)) {
			continue;
		}
		
		//space
		if (0 == structMeta->depth) {
			ret = snprintf(log_buf + log_idx, len - log_idx, "	");
		} else if(1 == structMeta->depth) {
			ret = snprintf(log_buf + log_idx, len - log_idx, "		");	
		} else if (2 == structMeta->depth) {
			ret = snprintf(log_buf + log_idx, len - log_idx, "			");	
		} else if (3 == structMeta->depth) {
			ret = snprintf(log_buf + log_idx, len - log_idx, "				");	
		} else {
			ret = snprintf(log_buf + log_idx, len - log_idx, "					");	
		}
		if (ret > 0)
		{
			log_idx += ret;
			if (log_idx >= len)
				return log_idx;
		}
		
		if (0 == structMeta->type) {
			ret = snprintf(log_buf + log_idx,
					len - log_idx,  
					"%s:\n",
					structMeta->name);
		} else {
			ret = snprintf(log_buf + log_idx,
					len - log_idx,  
					"%s = ",
					structMeta->name);
		}
		if (ret < 0) {
			printf("%s sprintf error\n", __FUNCTION__);
			continue;
		}
		log_idx += ret;	
		if (log_idx >= len)
			return log_idx;

		if (VAR_TYPE_STRING == structMeta->type) {
			ret = snprintf(log_buf + log_idx,
				len - log_idx,  
				"%s \n",
				(char *)(buf + structMeta->offset));
			if (ret < 0) {
				printf("%s sprintf error\n", __FUNCTION__);
				continue;
			}
			log_idx += ret;	
			if (log_idx >= len)
				return log_idx;
			continue;
		}
		
		count = structMeta->size;
		if(0 ==  count) {
			continue;
		//print type
		} else if (1 == count) {
			ret = dump_event_struct(structMeta, buf, 
				structMeta->offset, 0, log_buf + log_idx, len - log_idx);
			if (ret > 0) {
				log_idx += ret;
				if (log_idx >= len)
					return log_idx;
			}

			ret = snprintf(log_buf + log_idx,
					len - log_idx,  
					" \n");
			if (ret > 0) {
				log_idx += ret;
				if (log_idx >= len)
					return log_idx;
			}
			
		//print array
		} else if (count > 1) {
			ret = snprintf(log_buf + log_idx,
					len - log_idx,  
					"[");
			if (ret > 0) {
				log_idx += ret;
				if (log_idx >= len)
					return log_idx;
			}
			
			for (int i = 0; i < count; i++) {
				ret = dump_event_struct(structMeta, buf, 
					structMeta->offset, i, log_buf + log_idx, len - log_idx);
				if (ret > 0) {
					log_idx += ret;
					if (log_idx >= len)
						return log_idx;
				}
				
				ret = snprintf(log_buf + log_idx,
					len - log_idx,  
					",");
				if (ret > 0) {
					log_idx += ret;
					if (log_idx >= len)
						return log_idx;
				}
			}
			
			ret = snprintf(log_buf + log_idx,
					len - log_idx,  
					"] \n");
			if (ret > 0) {
				log_idx += ret;
				if (log_idx >= len)
					return log_idx;
			}
		}
	
	}//for

	return log_idx;
}

static inline int dump_add_index(char *log_buf, int len)
{
	int ret = 0;
	ret = snprintf(log_buf, len,  "\nlog index:%d",  queue_index);
	if (ret > 0) {
		queue_index++;
	}
	return ret;
}
/**dump evnet
**/
static inline int dump_event(EVENT_HEADER_TYPE *event, char *log_buf, int len)
{
	char *rname = NULL, *sname = NULL, *tname = NULL;
	int ret, log_idx;
    EVENT_META_TYPE* meta = NULL;
    RB_NODE_T *result = NULL;

	assert((NULL != event) && " event is NULL \n");
	assert((len > 0) && " buffer length is error \n");
	assert((NULL != log_buf) && " buffer is NULL \n");


	memset(log_buf, 0x0, len);

	//write event code
	log_idx = 0;
	ret = 0;
    
    result = rbtree_find(&evMetaTree, (void*)event->code);
    if(result) {
        meta = (EVENT_META_TYPE*)result->item;
    	ret = snprintf(log_buf + log_idx, 
    				   len - log_idx,  
    				   "\nevent: 0x%08x %s\n",
    				   event->code, meta->name);
    } else {
    	ret = snprintf(log_buf + log_idx, 
    				   len - log_idx,  
    				   "\nevent code is 0x%08x \n",
    				   event->code);
    }
	if (ret < 0) {
		printf("%s sprintf error\n", __FUNCTION__);
		return ret;
	}

	log_idx += ret;

	//sender reciver lenth checksum
	ret = 0;
	tname = get_service_name(event->sid);
	sname = (tname == NULL ? "(NULL)" : tname);
	tname = get_service_name(event->rid);
	rname = (tname == NULL ? "(NULL)" : tname);
	
	ret = snprintf(log_buf + log_idx, 
				   len - log_idx,  
				   "	%s ==> %s lenth %d checksum %d \n",
				   sname,
				   rname,
				   event->length,
				   event->checksum);
	
	if (ret < 0) {
		printf("%s sprintf error\n", __FUNCTION__);
		return ret;
	}
	log_idx += ret;

	//send time
	ret = 0;
	ret = snprintf(log_buf + log_idx, 
				   len - log_idx,  
				   "	sent at     ");
	if (ret < 0) {
		printf("%s sprintf error\n", __FUNCTION__);
		return ret;
	}
	log_idx += ret;	
	
	ret = convert_time(event->sent, 
					log_buf + log_idx , 
					len - log_idx);
	if (ret < 0) {
		printf("%s sprintf error\n", __FUNCTION__);
		return ret;
	}
	log_idx += ret;
	
	ret = snprintf(log_buf + log_idx, len - log_idx,  "\n");
	if (ret < 0) {
		printf("%s sprintf error\n", __FUNCTION__);
		return ret;
	}
	log_idx += ret;
	


	//receive time
	ret = 0;

	if (event->received > 0) {
		
		ret = snprintf(log_buf + log_idx, 
					   len - log_idx,  
					   "	receive at  ");
		if (ret < 0) {
			printf("%s sprintf error\n", __FUNCTION__);
			return ret;
		}
		log_idx += ret;
		
		ret = convert_time(event->received, 
						log_buf + log_idx, 
						len - log_idx);
		if (ret < 0) {
			printf("%s sprintf error\n", __FUNCTION__);
			return ret;
		}
		log_idx += ret;

		
		ret = snprintf(log_buf + log_idx, 
					len - log_idx,  
					" elapse: %lld usec\n",
					(event->received - event->sent) / 1000);
		if (ret < 0) {
			printf("%s sprintf error\n", __FUNCTION__);
			return ret;
		}
		log_idx += ret;
	} else {
		ret = snprintf(log_buf + log_idx, len - log_idx, "	not received \n");
		if (ret < 0) {
			printf("%s sprintf error\n", __FUNCTION__);
			return ret;
		}
		log_idx += ret;
	}
	
	//complete time
	ret = 0;

	if (event->complete > 0) {
		ret = snprintf(log_buf + log_idx, 
					   len - log_idx,  
					   "	complete at ");
		if (ret < 0) {
			printf("%s sprintf error\n", __FUNCTION__);
			return ret;
		}
		log_idx += ret;

		
		ret = convert_time(event->complete, 
						log_buf + log_idx, 
						len - log_idx);
		if (ret < 0) {
			printf("%s sprintf error\n", __FUNCTION__);
			return ret;
		}
		log_idx += ret;

		ret = snprintf(log_buf + log_idx, 
					len - log_idx,  
					" elapse: %lld usec \n",
					(event->complete - event->received) / 1000);
		if (ret < 0) {
			printf("%s sprintf error\n", __FUNCTION__);
			return ret;
		}
		log_idx += ret;
	} else {
		ret = snprintf(log_buf + log_idx, len - log_idx, "	not completed \n");
		if (ret < 0) {
			printf("%s sprintf error\n", __FUNCTION__);
			return ret;
		}
		log_idx += ret;
	}
	

	ret = 0;
	//write event head payload
	if (event->length > sizeof(EVENT_HEADER_TYPE)) {
		if (NULL == meta || meta->size == sizeof(EVENT_HEADER_TYPE)) {
			ret = dump_event_payload_hex(event, log_buf + log_idx, len - log_idx);
		} else {
			ret = dump_event_payload(event, meta, log_buf + log_idx, LOG_EVNET_SIZE - log_idx);
		}
		if (ret <= 0) {
			return ret;
		}
		log_idx += ret;	
		
	} else {
		ret = snprintf(log_buf + log_idx, 
					   len - log_idx,  
					   "event 0x%08x not have paylod.\n\n",
					   event->code);
		if (ret < 0) {
			printf("%s sprintf error\n", __FUNCTION__);
			return ret;
		}
		log_idx += ret;	
	}
	
	return log_idx;	
}


/**dump queue's evnet log 
@queue which store the event
@fd file descrip witch to write event log**/
static inline void dump_ev_log_q(QUEUE *queue, int fd)
{
	EVENT_HEADER_TYPE *event;
	int len,buf_len,buf_idx,ret,count;
	char *buf;
	
	assert((fd > 0) && " fd to write event log error \n");	
	assert((NULL != queue) && " event queue is NULL \n");	

	if (queue_size(queue) <= 0) {
		write(fd, "not have log\n", 13);
		return;
	}

	buf_len = LOG_EVNET_SIZE * queue_size(queue);
	buf = (char *)buffer_get(buf_len);
	if (buf == NULL) {
		printf("%s get buffer error buf_len is %d(int) %u(size_t unsgined)\n LOG_EVNET_SIZE =%d queue_size %d",\
				__FUNCTION__,buf_len,(size_t)buf_len,LOG_EVNET_SIZE,queue_size(queue));
		return;
	}
	buf_idx = 0;
	queue_index = 1;
	while ((queue_size(queue) > 0) && (buf_idx < buf_len)) {
		
		event = (EVENT_HEADER_TYPE *)queue_get(queue);
		
		if (NULL == event) {
			continue;
		}
		ret = dump_add_index(buf + buf_idx, buf_len - buf_idx);
		if (ret > 0) {
			buf_idx += ret;
		}
		if (EV_FW_LOGGER == event->code) {
			
			len = sizeof(EVENT_HEADER_TYPE);
			memcpy(buf + buf_idx, (void *)event + len, event->length - len);
			buf_idx += event->length - len;
			
		} else {
			ret = dump_event(event, buf + buf_idx, buf_len - buf_idx);
			if (ret > 0) {
				buf_idx += ret;
			}
			
		}

		buffer_release((void*)event);
	}

	len = 0;
    count = 0;
    while ((count++ < 100) && (len < buf_idx)) {
        ret = write(fd, (buf + len), (buf_idx - len));
        if (ret < 0) {
            
        } else {
            len += ret;
        }
    }
    if (len < buf_idx) {
        printf("%s write log to %d error, act %d hope %d\n", 
            __FUNCTION__, fd, len, buf_idx);
    }

	buffer_release(buf);

}

/**dump log*/
static inline void dump_log_to_file(void)
{
	char file_name[LOG_MAX_FILE_LEN];
	int file_d;
	int ret;


	ret = get_file_name(file_name, 255);
	if (ret < 0) {
		printf("%s get file name error\n", __FUNCTION__);
		return;
	}
	
	file_d  = open(file_name, O_RDWR | O_NONBLOCK | O_CREAT);
	if (file_d < 0) {
		printf("%s open file(%s) error\n", __FUNCTION__, file_name);
		return;
	}

	dump_ev_log_q(log_ev_q, file_d);
	
	close(file_d);

	printf("write log message to file %s success\n", file_name);
	return;	
}

/**dump log*/
static inline void dump_log_to_cons(void)
{
	dump_ev_log_q(log_ev_q, STDOUT_FILENO);
	
	return;	
}

/**dump log*/
static inline void dump_log_to_svc(QUEUE *queue, int from, int to)
{
	EVENT_HEADER_TYPE *event;
	int len = 0;
	int buf_len = 0;
	int buf_idx = 0;
	int ret = 0;
	int head_len = 0;
	int event_cnt = 0;
	char *buf;
	
	assert((NULL != queue) && " event queue is NULL \n");	
	
	head_len = sizeof(EVENT_HEADER_TYPE);

	if(queue_size(queue)  == 0)
		return;
	//while (queue_size(queue) > 0) {

	event_cnt = queue_size(queue) > 10 ? 10 : queue_size(queue);
	buf_len = head_len + LOG_EVNET_SIZE * event_cnt + 1;
	buf = (char *)buffer_get(buf_len);
	if (buf == NULL) {
		printf("%s get buffer error\n", __FUNCTION__);
		return;
	}
	memset((void *)buf, 0x0 , buf_len);

	buf_idx = head_len;

	while ((event_cnt-- > 0) && (buf_idx < buf_len)) {

		event = (EVENT_HEADER_TYPE *)queue_get(queue);
		len = sizeof(EVENT_HEADER_TYPE);
		
		if (NULL == event) {
			continue;
		}
		
		if ((buf_len - buf_idx) < (event->length - len)) {
			queue_add_head(queue, (void *)event);
			break;
		}
		ret = dump_add_index(buf + buf_idx, buf_len - buf_idx);
		if (ret > 0) {
			buf_idx += ret;
		}
		if (EV_FW_LOGGER == event->code) {
			len = sizeof(EVENT_HEADER_TYPE);
			memcpy(buf + buf_idx, (void *)event + len, event->length - len);
			buf_idx += event->length - len;
			
		} else {
			ret = dump_event(event, buf + buf_idx, buf_len - buf_idx);
			if (ret > 0) {
				buf_idx += ret;
			}
		}
				
		buffer_release((void*)event);
	}

	buf[buf_idx + 1]='\0';
	event = (EVENT_HEADER_TYPE *)buf;
	event->code = EV_FW_LOGGER;

	send_event_from((SVCID)from, (SVCID)to, event, buf_idx + 1, 0);

	buffer_release(buf);

	if(queue_size(queue)  == 0)
		return;
    EV_LOG_DUMP_TYPE ev;
    ev.header.code = EV_LOG_DUMP;
    ev.target = to;
    send_event_from((SVCID)from, from, (EVENT_HEADER_TYPE *)&ev, sizeof(ev), 1);

	//}

}

/***/
static inline void set_log_level(enum log_level_t level)
{
	if (level >= LOG_LEVEL_MAX ) {
		printf("%s unsupport level\n", __FUNCTION__);
		return ;
	}
			
	if (0 == level) {
		is_log_event = !is_log_event;
		printf("event log is %s \n",
			is_log_event == 1 ? "enable" : "disable");
		return;
	}	

	log_level = level;

	printf("log level is %d \n", log_level);
}

/***/
static inline void switch_svc_log(int svc_id, int is_en)
{
	ESINFO_T *es_info = NULL;

	if (0 == svc_id) {
		is_log_platform = is_en > 0 ? 1 : 0;
		return;
	}
	
	for (es_info = services; es_info; es_info = es_info->next) {
		if (es_info->sid == svc_id) {
			es_info->is_log = is_en > 0 ? 1 : 0;
			printf("service %s (id = %d) is %s log \n", es_info->name,
				es_info->sid, es_info->is_log == 1 ? "enable" : "disable");
			return;
		}
	}	
}

static inline void add_to_evq(void *event)
{
	assert((NULL != event) && " evnet is NULL \n");

	if (NULL == log_ev_q) {
		buffer_release((void*)event);
		return;
	}

	if (queue_size(log_ev_q) >= LOGGER_QUEUE_MAX) {
		buffer_release(queue_get(log_ev_q));
	}
	
	queue_add(log_ev_q, event);
	
	return;
	
}

/**log event add to log event queue
@event which event to log
*/
void log_event(void *event)
{
	assert((NULL != event) && " evnet is NULL \n");

	if (0 == is_log_event) {
		buffer_release((void*)event);
		return;
	}
	if (1 == ((EVENT_HEADER_TYPE *)event)->not_log) {
		buffer_release((void*)event);
		return;	
	}

	if (((EVENT_HEADER_TYPE *)event)->code == EV_FW_LOGGER /*||((EVENT_HEADER_TYPE *)event)->code == EV_LOG_DUMP*/)
	{
		buffer_release((void*)event);
		return;
	}

    if ((0 == is_log_conn_event) &&
        ((EVENT_HEADER_TYPE *)event)->code == EV_ECL_CONNECT) {
        buffer_release((void*)event);
		return;
    }
	
	add_to_evq(event);
	
}


/**record log message
@level  log level
@fmt	log content
*/
void log_raw(unsigned int level, const char *fmt, va_list arg)
{
	ESINFO_T *es_info;
	EVENT_HEADER_TYPE *event;
	char tmp_log[LOG_MAX_LINE_LEN];
	const char *svc_name;
	uint64_t now;
	int log_idx, ret, head_len;

	//logger is not init
	if (0 == is_log_init || NULL == log_ev_q) {
		return;
	}

	
	if(level > log_level) {
		//printf("%s level(%d) is more then system level(%d)\n",
		//	__FUNCTION__, level, log_level);
		return;
	}
	
	es_info = get_es_info();
	if (NULL == es_info) {
		if (0 == is_log_platform) { return; }
		svc_name = "platform";
	} else {
		if (0 == es_info->is_log) { return; }
		svc_name = es_info->name;
	}

	memset(tmp_log, 0x0, LOG_MAX_LINE_LEN);
	
	//record time information
   	log_idx = 0;
	now = get_epoch_time_nano();
	ret = convert_time(now, tmp_log + log_idx, LOG_MAX_LINE_LEN - log_idx);
	if (ret < 0) {
		printf("%s sprintf error\n", __FUNCTION__);
		return;
	}
	log_idx += ret;

	//record log level
	ret = snprintf(tmp_log + log_idx, 
				   LOG_MAX_LINE_LEN - log_idx,  
				   " <%d> ", level);
	if (ret < 0) {
		printf("%s sprintf error\n", __FUNCTION__);
		return;
	}
	log_idx += ret;

	//record service id
	ret = snprintf(tmp_log + log_idx, 
				   LOG_MAX_LINE_LEN - log_idx,  
				   "<%s> ", svc_name);
	if (ret < 0) {
		printf("%s sprintf error\n", __FUNCTION__);
		return;
	}
	log_idx += ret;
	
	
	ret = vsnprintf(tmp_log + log_idx, 
					LOG_MAX_LINE_LEN - log_idx, 
					fmt, arg);
	log_idx += ret;

	head_len = sizeof(EVENT_HEADER_TYPE);
	event = (EVENT_HEADER_TYPE *)buffer_get(log_idx + head_len);
	memset((void *)event, 0 , log_idx + head_len);
	
	event->code = EV_FW_LOGGER;
	event->length = log_idx + head_len;
	
	memcpy((void *)event + head_len, tmp_log, log_idx);

	add_to_evq((void *)event);

	return;
}



void log_msg(unsigned int level, const char *fmt, ...)
{
    va_list arg;
    va_start(arg, fmt);    
    log_raw(level, fmt, arg);    
    va_end(arg);
}

/** init logger*/
void logger_init(void)
{	
	log_ev_q = queue_new();
	if (NULL == log_ev_q) {
		printf("%s new log event queue error\n", __FUNCTION__);
		return;
	}

	is_log_init = 1;
}

/***/
static inline void free_ev_queue(QUEUE *queue)
{
	void *event;
	
	if (NULL != queue) {
		while (queue_size(queue) > 0) {
			event = queue_get(queue);
			if (NULL == event) {
				continue;
			}
			buffer_release((void*)event);
		}
		
		queue_free(&queue);
	}
}

/**exit logger*/
void logger_exit(void)
{
	if (NULL != log_ev_q) {
		free_ev_queue(log_ev_q);
	}
	is_log_init = 0;
}


/**command log*/
int cmd_log(int argc, char * const argv[])
{
	int level, opt, svc_id, from, to;
	
	if ((argc < 2) || (argc > 4)) {
		printf("Usage: \n");
		printf("log [en/dis] [svc_id | conn] (0 is platform)\n");
		printf("log [dump] [opt] [fromsvc] [tosvc] (opt is %d console, %d file, %d svc)\n",
			LOG_OPT_CONS, LOG_OPT_FILE, LOG_OPT_SVC);
		printf("log [level] [level] (0 en or dis event log, level(1 - %d))  \n", LOG_LEVEL_MAX - 1);
		return -1;
	}

	if (0 == strcmp(argv[0], "level")) {
		
		level = atoi(argv[1]);
		set_log_level(level);
		

	} else if (0 == strcmp(argv[0], "dump")) {
		opt = atoi(argv[1]);
		switch(opt) {
			case LOG_OPT_CONS:
				dump_log_to_cons();
				break;
			case LOG_OPT_FILE:
				dump_log_to_file();
				break;
			case LOG_OPT_SVC:
				if (argc < 4) { 
					printf("pleae input from svcid and to svcid\n");
					break;
				}
				from = atoi(argv[2]);
				to = atoi(argv[3]);
				dump_log_to_svc(log_ev_q, from, to);
				break;
			default:
				printf("%s is unsupport option\n", __FUNCTION__);
			
		}
	} else if (0 == strcmp(argv[0], "en")) {
	    if (0 == strcmp(argv[1], "conn")) {
            is_log_conn_event = 1;
        } else {
    		svc_id = atoi(argv[1]);
    		switch_svc_log(svc_id, 1);
        }
	} else if (0 == strcmp(argv[0], "dis")) {
	     if (0 == strcmp(argv[1], "conn")) {
            is_log_conn_event = 0;
        } else {
		    svc_id = atoi(argv[1]);
		    switch_svc_log(svc_id, 0);
        }
	} else {
		printf("unsuport command args please use help\n");
	}
	
	return 0;
}




int dump_to_terminal(int argc, char * const argv[])
{
    dump_log_to_cons();
    return 0;
}



void init_evet_meta_tree()
{
    int idx=0;

    if(NULL == event_meta_info)
        return;
    
    rbtree_init(&evMetaTree, KEY_INT);

    for(idx=0;idx<meta_info_size;idx++)
    {
         rbtree_insert(&evMetaTree, (void*)event_meta_info[idx].code, (void*)&event_meta_info[idx]);
    }
    
   
}


/***/
void process_ev_log_dump(EV_LOG_DUMP_TYPE *event)
{
	SVCID sid; 
	SVCID rid; 

	if (NULL == event) {
		printf("%s invaid parameter event = NULL\n", __FUNCTION__);
		return;
	} 
	sid = event->header.rid;
	rid = event->target;
	queue_index = 1;
	dump_log_to_svc(log_ev_q, sid, rid);
    
}

