

#include <stdio.h>
#include <malloc.h>
#include <errno.h>
#include <string.h>
#include <arpa/inet.h>
#include <unistd.h>

#include "rbtree.h"
#include "sys_topology.h"
#include "ev_service.h"


#define    USE_CONFIGXML    1

#define HOST_NAME_LEN    50
#define PROC_NAME_LEN     50

static char* host_name;            ///< The name of the current host.
static char* process_name;         ///< The name of the current process.



static NODE_INFO_TYPE node_default[] = 
{
//    {NODE_ID_OC,"oc", "172.20.20.2"},
    {NODE_ID_OC,"oc", "127.0.0.1"},
    {NODE_ID_SCU,"scu", "127.0.0.1"},
    {NODE_ID_RCU,"rcu", "127.0.0.1"},    
//    {NODE_ID_SCU,"scu", "192.168.66.2"},
//    {NODE_ID_RCU,"rcu", "192.168.68.2"},
    {NODE_ID_DISP1,"disp1", "192.168.66.3"},
    {NODE_ID_DISP2,"disp2", "192.168.66.4"},
    {NODE_ID_CTBOX,"ctbox", "192.168.66.5"}
};

static PROC_INFO_TYPE process_default[] = 
{
    {PROC_ID_SCANMGR,"scanmgr"},
    {PROC_ID_ALARM_CENTER,"alarmcenter"},
    {PROC_ID_STATUS_MGR,"statusmgr"},
    {PROC_ID_STATISTIC_MGR,"statisticMgr"}, 
    {PROC_ID_PET_INTF,"petIntf"},
    {PROC_ID_COMP_MGR,"compMgr"},
   
    {PROC_ID_SC,"sc"},
    {PROC_ID_AX,"axial"},
    {PROC_ID_TBL,"table"},
    {PROC_ID_GUIF,"guif"},
    {PROC_ID_AUDIO,"audio"},
    {PROC_ID_TILT_ELEV,"tl_el"},
    {PROC_ID_DAS ,"das"},
    {PROC_ID_GEN,"gen"},
    {PROC_ID_COLL,"coll"},
    {PROC_ID_DET_THERMAL, "DetThermal"},
    {PROC_ID_DISP,"disp"},    
    {PROC_ID_CTBOX,"ctbox"},

	{PROC_ID_TOOLS,"tools"},
    {PROC_ID_SCU_BOARD_SERVICE, "scuBoardService"},
    {PROC_ID_RCU_BOARD_SERVICE, "rcuBoardService"},
    {PROC_ID_DISP1_BOARD_SERVICE, "disp1BoardService"},
    {PROC_ID_DISP2_BOARD_SERVICE, "disp2BoardService"},
    {PROC_ID_CTBOX_BOARD_SERVICE, "ctboxBoardService"},
    
    
    {PROC_TEST1,"platTest"},
    {PROC_TEST2,"test"},
    {PROC_ID_CTBDISP,"ctbdisp"},
    {PROC_ID_CTBAUDIO,"ctbaudio"},
    {PROC_ID_DISP1,"gdisp1"},
    {PROC_ID_GANTAUDIO,"gaudio"},
    {PROC_ID_DISP2,"gdisp2"},
    {PROC_ID_DISP1_PANEL,"GantryPanel1"},
    {PROC_ID_DISP2_PANEL,"GantryPanel2"},
};

static DEFAULT_SERVICE_INFO_TYPE service_default[] = 
{
    {SVC_ID_OC_SCANMGR,        "scanmgr",     30000, PROC_ID_SCANMGR,     NODE_ID_OC},
    {SVC_ID_OC_ALARM_CENTER,   "almcenter",   33000, PROC_ID_ALARM_CENTER,     NODE_ID_OC},
    {SVC_ID_OC_STATUS_MGR,     "statusmgr",   36000, PROC_ID_STATUS_MGR,     NODE_ID_OC},
    {SVC_ID_OC_STATISTIC_MGR,"statisticMgr",   39000, PROC_ID_STATISTIC_MGR,     NODE_ID_OC},
    {SVC_ID_PET_SCANMGR, "petscm",   42000, PROC_ID_PET_INTF,     NODE_ID_OC},
	{SVC_ID_OC_SEASONING_MGR, "seasoningMgr",	 45000, PROC_ID_COMP_MGR,	  NODE_ID_OC},
	{SVC_ID_OC_ALIGNMENT_MGR, "alignmentMgr",	 45001, PROC_ID_COMP_MGR,	  NODE_ID_OC},
	{SVC_ID_OC_AX_DIAGNOSE_MGR, "axDiagMgr",	 45002, PROC_ID_COMP_MGR,	  NODE_ID_OC},
	{SVC_ID_OC_COLL_DIAGNOSE_MGR, "collDiagMgr", 45003, PROC_ID_COMP_MGR,	  NODE_ID_OC},
	{SVC_ID_OC_CRADLE_DIAGNOSE_MGR, "cradleDiagMgr", 45004, PROC_ID_COMP_MGR,	  NODE_ID_OC},
	{SVC_ID_OC_ELEV_DIAGNOSE_MGR, "elevDiagMgr", 45005, PROC_ID_COMP_MGR,	  NODE_ID_OC},
	{SVC_ID_SC,            "sc",         60050, PROC_ID_SC,         NODE_ID_SCU},
    {SVC_ID_SC_OC_COMM,    "oc_comm",     60051, PROC_ID_SC,         NODE_ID_SCU},
    {SVC_ID_SC_SEQUENCE, "sc_sequence",    60052, PROC_ID_SC,        NODE_ID_SCU},
    {SVC_ID_SC_DAS_CTRL,    "das_ctrl", 60053, PROC_ID_SC,         NODE_ID_SCU},
    {SVC_ID_SC_AX_CTRL,    "ax_ctrl",     60054, PROC_ID_SC,         NODE_ID_SCU},
    {SVC_ID_SC_CRADLE_CTRL,    "crdl_ctrl", 60055, PROC_ID_SC,         NODE_ID_SCU},
    {SVC_ID_SC_GEN_CTRL,    "gen_ctrl", 60056, PROC_ID_SC,         NODE_ID_SCU},
    {SVC_ID_SC_COLL_CTRL,    "coll_ctrl",60057, PROC_ID_SC,         NODE_ID_SCU},
    {SVC_ID_SC_HW_CTRL,    "sc_hw_ctrl",60058, PROC_ID_SC,        NODE_ID_SCU},
    {SVC_ID_SC_PANEL_CTRL,"sc_panel_ctrl",60059, PROC_ID_SC,    NODE_ID_SCU},
    {SVC_ID_SC_TILT_CTRL,"sc_tilt_ctrl",60060, PROC_ID_SC,    NODE_ID_SCU},
    {SVC_ID_SC_ELEV_CTRL,"sc_elev_ctrl",60061, PROC_ID_SC,    NODE_ID_SCU},
    {SVC_ID_SC_DISP_CTL,    "sc_disp_ctrl",60062, PROC_ID_SC,        NODE_ID_SCU},
    {SVC_ID_SC_ERR_SVC,   "sc_err_svc",60063, PROC_ID_SC,       NODE_ID_SCU},
    {SVC_ID_PET_CTRL,"sc_pet_ctrl",	60064, PROC_ID_SC,    NODE_ID_SCU},
    {SVC_ID_SC_AUDIO,"sc_audio_ctrl",	60065, PROC_ID_SC,    NODE_ID_SCU},
    {SVC_ID_SC_ECG,"sc_ecg_ctrl",	60066, PROC_ID_SC,    NODE_ID_SCU},
    {SVC_ID_AXIAL,        "axial",     60080, PROC_ID_AX,         NODE_ID_SCU},
	{SVC_ID_AXIAL_DRV,		  "axial_drive", 60081, PROC_ID_AX,		  NODE_ID_SCU},
    {SVC_ID_CRADLE,        "cradle",     60085, PROC_ID_TBL,         NODE_ID_SCU},
    {SVC_ID_GANTRY_UIF,    "guif",     60090, PROC_ID_GUIF,     NODE_ID_SCU},
    {SVC_ID_TILT_ELEV_CTRL,    "tl_ev",     60095, PROC_ID_TILT_ELEV,NODE_ID_SCU},
    {SVC_ID_TILT_MGR,    "tl_mgr",     60096, PROC_ID_TILT_ELEV,NODE_ID_SCU},
    {SVC_ID_ELEV_MGR,    "ev_mgr",     60097, PROC_ID_TILT_ELEV,NODE_ID_SCU},
    {SVC_ID_SCU_BOARD_SERVICE, "scu_board_service", 60105, PROC_ID_SCU_BOARD_SERVICE, NODE_ID_SCU},
    /* service for board service tasks [Add][liufei][2015.02.06] */
    {SVC_ID_SCU_BS_TASK_BOARD,		"scu_bs_task_board",	60106,	PROC_ID_SCU_BOARD_SERVICE,	NODE_ID_SCU},
    {SVC_ID_SCU_BS_TASK_HARDWARE,	"scu_bs_task_hardware",	60107,	PROC_ID_SCU_BOARD_SERVICE,	NODE_ID_SCU},
    {SVC_ID_SCU_BS_TASK_NETWORK,	"scu_bs_task_network",	60108,	PROC_ID_SCU_BOARD_SERVICE,	NODE_ID_SCU},
    {SVC_ID_SCU_BS_TASK_PROCESS,	"scu_bs_task_process",	60109,	PROC_ID_SCU_BOARD_SERVICE,	NODE_ID_SCU},

    {SVC_ID_TOOLS, 		  "tools", 60110, 	PROC_ID_TOOLS, 		NODE_ID_SCU},
    {SVC_ID_SCU_BOARD_TEST, "scu_board_test", 60111, PROC_ID_SCU_BOARD_SERVICE, NODE_ID_SCU},
    
    
    {SVC_ID_DAS,        "das",         60200, PROC_ID_DAS,         NODE_ID_RCU},
    {SVC_ID_GEN_MNG,        "genMgr",         60300, PROC_ID_GEN,NODE_ID_RCU},
    {SVC_ID_GEN_STARTER,"genStarter", 60305, PROC_ID_GEN,NODE_ID_RCU},
    {SVC_ID_GEN_FLAM,        "genFila",         60310, PROC_ID_GEN,NODE_ID_RCU},
    {SVC_ID_COLL,          "coll",        60400, PROC_ID_COLL,     NODE_ID_RCU},
    {SVC_ID_RCU_BOARD_SERVICE, "rcu_board_service", 60405, PROC_ID_RCU_BOARD_SERVICE, NODE_ID_RCU},
    /* service for board service tasks [Add][liufei][2015.02.06] */
    {SVC_ID_RCU_BS_TASK_BOARD,		"rcu_bs_task_board",	60406,	PROC_ID_RCU_BOARD_SERVICE,	NODE_ID_RCU},
    {SVC_ID_RCU_BS_TASK_HARDWARE,	"rcu_bs_task_hardware",	60407,	PROC_ID_RCU_BOARD_SERVICE,	NODE_ID_RCU},
    {SVC_ID_RCU_BS_TASK_NETWORK,	"rcu_bs_task_network",	60408,	PROC_ID_RCU_BOARD_SERVICE,	NODE_ID_RCU},
    {SVC_ID_RCU_BS_TASK_PROCESS,	"rcu_bs_task_process",	60409,	PROC_ID_RCU_BOARD_SERVICE,	NODE_ID_RCU},

    {SVC_ID_DET_THERMAL,   "DetThermal",        60410, PROC_ID_DET_THERMAL,     NODE_ID_RCU},
    {SVC_ID_RCU_BOARD_TEST, "rcu_board_test", 60411, PROC_ID_RCU_BOARD_SERVICE, NODE_ID_RCU},


    {SVC_ID_GANTRY_PANEL1,"g_panel1",60500, PROC_ID_DISP1_PANEL,     NODE_ID_DISP1},
    {SVC_ID_GANTRY_DISP1, "g_disp1", 60505, PROC_ID_DISP1,     NODE_ID_DISP1},
    {SVC_ID_AUDIO_GANTRY,  "g_audio",60506, PROC_ID_GANTAUDIO, NODE_ID_DISP1},
    {SVC_ID_DISP1_BOARD_SERVICE, "disp1_board_service", 60507, PROC_ID_DISP1_BOARD_SERVICE, NODE_ID_DISP1},
    /* service for board service tasks [Add][liufei][2015.02.06] */
    {SVC_ID_DISP1_BS_TASK_BOARD,	"disp1_bs_task_board",		60508,	PROC_ID_DISP1_BOARD_SERVICE,	NODE_ID_DISP1},
    {SVC_ID_DISP1_BS_TASK_HARDWARE,	"disp1_bs_task_hardware",	60509,	PROC_ID_DISP1_BOARD_SERVICE,	NODE_ID_DISP1},
    {SVC_ID_DISP1_BS_TASK_NETWORK,	"disp1_bs_task_network",	60510,	PROC_ID_DISP1_BOARD_SERVICE,	NODE_ID_DISP1},
    {SVC_ID_DISP1_BS_TASK_PROCESS,	"disp1_bs_task_process",	60511,	PROC_ID_DISP1_BOARD_SERVICE,	NODE_ID_DISP1},
    {SVC_ID_DISP1_BOARD_TEST, "disp1_board_test", 60512, PROC_ID_DISP1_BOARD_SERVICE, NODE_ID_DISP1},


    {SVC_ID_GANTRY_PANEL2,"g_panel2",60600, PROC_ID_DISP2_PANEL,     NODE_ID_DISP2},
    {SVC_ID_GANTRY_DISP2, "g_disp2", 60605, PROC_ID_DISP2,     NODE_ID_DISP2},
    {SVC_ID_DISP2_BOARD_SERVICE, "disp2_board_service", 60606, PROC_ID_DISP2_BOARD_SERVICE, NODE_ID_DISP2},
    /* service for board service tasks [Add][liufei][2015.02.06] */
    {SVC_ID_DISP2_BS_TASK_BOARD,	"disp2_bs_task_board",		60607,	PROC_ID_DISP2_BOARD_SERVICE,	NODE_ID_DISP2},
    {SVC_ID_DISP2_BS_TASK_HARDWARE, "disp2_bs_task_hardware",	60608,	PROC_ID_DISP2_BOARD_SERVICE,	NODE_ID_DISP2},
    {SVC_ID_DISP2_BS_TASK_NETWORK,	"disp2_bs_task_network",	60609,	PROC_ID_DISP2_BOARD_SERVICE,	NODE_ID_DISP2},
    {SVC_ID_DISP2_BS_TASK_PROCESS,	"disp2_bs_task_process",	60610,	PROC_ID_DISP2_BOARD_SERVICE,	NODE_ID_DISP2},
    {SVC_ID_DISP2_BOARD_TEST, "disp2_board_test", 60611, PROC_ID_DISP2_BOARD_SERVICE, NODE_ID_DISP2},


    {SVC_ID_CTBOX_BTN,      "ctb_btn", 60700, PROC_ID_SCB,         NODE_ID_CTBOX},
    {SVC_ID_CTBOX_DISP,      "ctb_disp",60705, PROC_ID_SCB,         NODE_ID_CTBOX},
    {SVC_ID_AUDIO_CTBOX,     "ctb_audio",60706, PROC_ID_SCB,     NODE_ID_CTBOX},
    {SVC_ID_CTBOX_BOARD_SERVICE, "ctbox_board_service", 60707, PROC_ID_CTBOX_BOARD_SERVICE, NODE_ID_CTBOX},
    /* service for board service tasks [Add][liufei][2015.02.06] */
    {SVC_ID_CTBOX_BS_TASK_BOARD,	"ctbox_bs_task_board",		60708,	PROC_ID_CTBOX_BOARD_SERVICE,	NODE_ID_CTBOX},
    {SVC_ID_CTBOX_BS_TASK_HARDWARE, "ctbox_bs_task_hardware",	60709,	PROC_ID_CTBOX_BOARD_SERVICE,	NODE_ID_CTBOX},
    {SVC_ID_CTBOX_BS_TASK_NETWORK,	"ctbox_bs_task_network",	60710,	PROC_ID_CTBOX_BOARD_SERVICE,	NODE_ID_CTBOX},
    {SVC_ID_CTBOX_BS_TASK_PROCESS,	"ctbox_bs_task_process",	60711,	PROC_ID_CTBOX_BOARD_SERVICE,	NODE_ID_CTBOX},
    {SVC_ID_CTBOX_BOARD_TEST, "ctbox_board_test", 60712, PROC_ID_CTBOX_BOARD_SERVICE, NODE_ID_CTBOX},

    
    {SVC_ID_TEST1,        "test1",     61000, PROC_TEST1,         NODE_ID_OC},
    {SVC_ID_TEST2,        "test2",     61001, PROC_TEST1,         NODE_ID_OC},
    {SVC_ID_TEST3,        "test3",     61002, PROC_TEST1,         NODE_ID_OC},
    {SVC_ID_TEST4,        "test4",     61003, PROC_TEST1,         NODE_ID_OC},
    {SVC_ID_TEST5,        "test5",     61004, PROC_TEST1,         NODE_ID_OC},
    {SVC_ID_TEST6,        "test6",     61005, PROC_TEST1,         NODE_ID_OC},
    {SVC_ID_TEST7,        "test7",     61006, PROC_TEST1,         NODE_ID_OC},
    {SVC_ID_TEST8,        "test8",     61007, PROC_TEST1,         NODE_ID_OC}
	
};
#if 0
static PLATFORM_DEVICE_TYPE device_default[] = {
    {SVC_ID_TEST8, SVC_ID_DEV_MEM, MEMDEV},
    {SVC_ID_TEST8, SVC_ID_DEV_FPGATEST, FPGATESTDEV},
};
#endif
RB_TREE_T node_tree;
RB_TREE_T process_tree;
RB_TREE_T sv_tree;
RB_TREE_T dev_tree;

char* get_ip(NODEID nid)
{
    RB_NODE_T *result = NULL;
    result = rbtree_find(&node_tree, (void*)nid);
    if(result){
        NODE_INFO_TYPE *node= (    NODE_INFO_TYPE*)result->item;
        return node->ip;
    }
    return NULL;
}

char* process_name_by_id(PROCESSID pid)
{
    RB_NODE_T *result = NULL;
    result = rbtree_find(&process_tree, (void*)pid);
    if(result){
        PROC_INFO_TYPE *p= (PROC_INFO_TYPE*)result->item;
        return p->name;
    }
    return NULL;
}

char* node_name_by_id(NODEID nid)
{
    RB_NODE_T *result = NULL;
    result = rbtree_find(&node_tree, (void*)nid);
    if(result){
        NODE_INFO_TYPE *node= (    NODE_INFO_TYPE*)result->item;
        return node->name;
    }
    return NULL;
}

NODE_INFO_TYPE *get_def_nodeInfo(char *name)
{
    int i = 0, size = 0;

    if (NULL == name) {
        return NULL;
    }
    
    size = sizeof(node_default) / sizeof(NODE_INFO_TYPE);
    for(i = 0; i < size; i++) {
        if (strcmp(node_default[i].name, name) == 0) {
            return &node_default[i];
        }
    }
    return NULL;
}

PROC_INFO_TYPE *get_def_procInfo(char *name)
{
    int i = 0, size = 0;

    if (NULL == name) {
        return NULL;
    }
    
    size = sizeof(process_default)/sizeof(PROC_INFO_TYPE);
    for(i = 0; i < size; i++) {
        
        if (strcmp(process_default[i].name, name) == 0) {
            return &process_default[i];
        }
    }
    
    return NULL;
}
#if 0
PLATFORM_DEVICE_TYPE *get_def_device(char *dev_file_name)
{
    int i = 0, size = 0;

    if (NULL == dev_file_name) {
        return NULL;
    }
    
    size = sizeof(device_default) / sizeof(PLATFORM_DEVICE_TYPE);
    for(i = 0; i < size; i++) {
        
        if (strcmp(device_default[i].dev_file_name, dev_file_name) == 0) {
            return &device_default[i];
        }
    }
    
    return NULL;
}
#endif

SVCID get_service_id_by_name(char *name)
{
    int i = 0, size = 0;

    if (NULL == name) {
        return SVC_ID_UNKNOWN;
    }

    size = sizeof(service_default)/sizeof(DEFAULT_SERVICE_INFO_TYPE);
    for(i = 0; i < size; i++) {
        if (strcmp(service_default[i].name, name) == 0) {
            return service_default[i].id;
        }
    }
	return SVC_ID_UNKNOWN;
}

DEFAULT_SERVICE_INFO_TYPE *get_def_service(char *name)
{
    int i = 0, size = 0;

    if (NULL == name) {
        return NULL;
    }
    
    size = sizeof(service_default)/sizeof(DEFAULT_SERVICE_INFO_TYPE);
    for(i = 0; i < size; i++) {
        if (strcmp(service_default[i].name, name) == 0) {
            return &service_default[i];
        }
    }
    
    return NULL;
}

#if 0
void init_default_topo()
{
    rbtree_init(&node_tree, KEY_INT);
    rbtree_init(&process_tree,KEY_INT);
    rbtree_init(&sv_tree, KEY_INT);
    int i;
    int size = sizeof(node_default)/sizeof(NODE_INFO_TYPE);
    for(i=0;i<size;i++)
    {
        rbtree_insert(&node_tree,(void*)node_default[i].id,(void*)&node_default[i]);
    }

    size = sizeof(process_default)/sizeof(PROC_INFO_TYPE);
    for(i=0;i<size;i++)
    {
        rbtree_insert(&process_tree,(void*)process_default[i].id,(void*)&process_default[i]);
    }

    rbtree_init(&dev_tree, KEY_STRING);
    size = sizeof(device_default) / sizeof(PLATFORM_DEVICE_TYPE);
    //printf("%s device_default size = %d \n", __FUNCTION__, size);
    for(i = 0; i < size; i++)
    {
        //printf("%s %s %d \n", __FUNCTION__, device_default[i].dev_file_name, device_default[i].dev_id);
        rbtree_insert(&dev_tree,(void*)device_default[i].dev_file_name,(void*)&device_default[i]);
    }

    size = sizeof(service_default)/sizeof(DEFAULT_SERVICE_INFO_TYPE);
    for(i=0;i<size;i++)
    {
        SERVICE_TYPE *svc = malloc(sizeof(SERVICE_TYPE));
        svc->id = service_default[i].id;
        svc->name = service_default[i].name;
        svc->pid = service_default[i].pid;
        svc->nid = service_default[i].nid;    
        svc->pname = process_name_by_id(svc->pid );
        svc->nname = node_name_by_id(svc->nid);
        
        struct sockaddr_in addr;                    // The service address.
        char * ip = get_ip(svc->nid);
        int status = 0;
        memset(&addr, 0, sizeof(addr));
        if (ip == NULL) {
            // Use localhost.
            ip = "127.0.0.1";
        }
        status = inet_aton(ip, &addr.sin_addr);
        if(!status){
            printf("invalid address \n");
        }
        svc->addr = addr;
        svc->addr.sin_port = htons(service_default[i].port);
        svc->addr.sin_family = AF_INET;        
        rbtree_insert(&sv_tree,(void*)svc->id,(void*)svc);
    }
}
#endif

extern void parser_xmlFile();

void init_default_topo_xml()
{


    rbtree_init(&node_tree, KEY_INT);
    rbtree_init(&process_tree, KEY_INT);
    rbtree_init(&sv_tree, KEY_INT);
    rbtree_init(&dev_tree, KEY_STRING);
    
    parser_xmlFile();

    /**test
    RB_NODE_T *result = rbtree_first(&dev_tree);
    PLATFORM_DEVICE_TYPE *dev_tmp;
    NODE_INFO_TYPE *node_tmp;
    PROC_INFO_TYPE *proc_tmp;
    SERVICE_TYPE *sv_tmp;
    
    result = rbtree_first(&node_tree);
    while(NULL != result) {
        node_tmp = (NODE_INFO_TYPE *)result->item;
        printf("%d %s %s\n", node_tmp->id, node_tmp->name, node_tmp->ip);
        result = rbtree_next(&node_tree, result);
    }

    result = rbtree_first(&process_tree);
    while(NULL != result) {
        proc_tmp = (PROC_INFO_TYPE *)result->item;
        printf("%d %s\n", proc_tmp->id, proc_tmp->name);
        result = rbtree_next(&process_tree, result);
    }

    result = rbtree_first(&sv_tree);
    while(NULL != result) {
        sv_tmp = (SERVICE_TYPE *)result->item;
        printf("%d  %s ", sv_tmp->id,  sv_tmp->name);
        printf("%d %s ", sv_tmp->pid,  sv_tmp->pname);
        printf("%d %s ", sv_tmp->nid,  sv_tmp->nname);
        printf("%s:%d \n", inet_ntoa(sv_tmp->addr.sin_addr), ntohs(sv_tmp->addr.sin_port));
        result = rbtree_next(&sv_tree, result);
    }
    
    result = rbtree_first(&dev_tree);
    while(NULL != result) {
        dev_tmp = (PLATFORM_DEVICE_TYPE *)result->item;
        printf("%d %d %s\n", dev_tmp->svc_id, dev_tmp->dev_id, dev_tmp->dev_file_name);
        result = rbtree_next(&dev_tree, result);
    }
    */
}

static char* get_hostname()
{
    char *name = (char *)buffer_get(HOST_NAME_LEN);
    if(host_name == NULL){
        gethostname(name, HOST_NAME_LEN);
        host_name = name;
    }
    return host_name;
}


char* set_process_name(char *name)
{
    const char *p = strrchr(name, '/'); 
    if (p == NULL) {
        p = name;
    } else {
        ++p;
    }
    const char *q = strrchr(p, '.');
    int len;
    if (q) {
        // Strip off the extension.
        len = q - p;
    } else {
        len = strlen(p) + 1;
    }
    char*new_name = malloc(len);
    strcpy(new_name, p);
    process_name= new_name;
    return new_name;
    
}

extern char *program_invocation_name, *program_invocation_short_name;
char* get_process_name()
{
    if(process_name == NULL){
        return set_process_name(program_invocation_name);
    }else{
        return process_name;
    }
}


SERVICE_TYPE* lookup_service(int appId)
{
    RB_NODE_T *result = NULL;
    result = rbtree_find(&sv_tree, (void*)appId);
    if(result){
        SERVICE_TYPE *svc= (SERVICE_TYPE*)result->item;
        return svc;
    }
    return NULL;
}

int set_service_ip_port(int appId, char* ip, int port)
{
    int status = 0;
    RB_NODE_T *result = NULL;
    result = rbtree_find(&sv_tree, (void*)appId);
    if(result){
        SERVICE_TYPE *svc= (SERVICE_TYPE*)result->item;
        if (ip == NULL) {
            // Use localhost.
            ip = "127.0.0.1";
        }
        status = inet_aton(ip, &(svc->addr).sin_addr);
        if(!status){
            printf("invalid address \n");
        }
        svc->addr.sin_port = htons(port);
        return 0;
    }
    return -1;
}

char* get_service_name(SVCID id)
{
    SERVICE_TYPE *svc = NULL;

    if ((id < SVC_ID_DEV_END) && (id > SVC_ID_DEV_BASE)) {
        return get_devname_by_id(id);
    }
    
    svc =  lookup_service(id);
    if(svc == NULL)
        return NULL;
    else
        return svc->name;
}


char* validate_service(int svcId)
{
    RB_NODE_T* result = NULL;


    result = rbtree_find(&sv_tree, (void*)svcId);
    if (NULL == result) {
        return NULL;
    }
    
    SERVICE_TYPE *svc = (SERVICE_TYPE *)result->item;
    if(svc != NULL){
        // the service id have been registed, check process name and host name
        char * p = get_process_name();
        if(0 != strcmp(p,svc->pname)){
            //printf("for service %s, pre defined process is %s, while actual process is %s \n", svc->name, svc->pname, p);
            svc->pname = p;
        }
        char *q = get_hostname();
        if(0 != strcmp(q,svc->nname)){
            //printf("for service %s, pre defined node is %s, while actual node is %s \n", svc->name, svc->nname, q);
            svc->pname = q;
        }
        return svc->name;
    }
    return NULL;
    
}





void init_sys_topo()
{
#ifdef USE_CONFIGXML
    init_default_topo_xml();
#endif
#if 0
    init_default_topo();
#endif
    

    
}

/**
 *if the service id was  not predefined, a temp service info could also be registered
 *we will add the service info to the sv_tree so it become visible to other service
 */
// TODO: implement below function
/*
void register_serviice_info(SVCID id)
{
    // TODO: can we remove these name parameters?
    int status = 0;
    if(id>SVC_ID_COUNT){

        printf("the APP ID is larger than the max number allowed! \n");
        return;
    }
    
    if(gServiceMap[id] != NULL)
    {
        printf("the APP ID %d have been registered \n", id);
        return;
    }

    SERVICE_TYPE *svc = malloc(sizeof(SERVICE_TYPE));

    svc->service.id = id;
    svc->service.name = name;
    svc->process.id = subsysId;
    svc->node.id = nodeId;

    struct sockaddr_in addr;                    // The service address.
    memset(&addr, 0, sizeof(addr));
    if (*ip== '\0') {
        // Use localhost.
        ip = "127.0.0.1";
    }
    status = inet_aton(ip, &addr.sin_addr);
    if(!status){
        printf("invalid address \n");
    }

    svc->addr = addr;
    svc->addr.sin_port = htons(port);
    svc->addr.sin_family = AF_INET;
        
    svc->service.name = malloc(strlen(name) + 1);
    strcpy( svc->service.name, name );

    svc->process.name = malloc(strlen(subsysName) + 1);
    strcpy( svc->process.name, subsysName );
    
    svc->node.name = malloc(strlen(nodeName) + 1);
    strcpy( svc->node.name, nodeName );

    gServiceMap[id] = svc;
    
}*/


// TODO: parse a config file to get the ip address and process information 

/** future feature, the ip address and process on each host can be defined by a config file.
 | this will make debug and test more flexible
 |
 |config file should be in below format
 |  node oc 
 |  ip : 192.168.168.1
 |  process: fwmgr;scanmgr
 |  node scu 
 |  ip:192.168.168.2
 |  process : sc axial table guif
*/




int    disp_all_services(int argc, char * const argv[])
{
    RB_NODE_T *result = NULL;
    SERVICE_TYPE *svc = NULL;
    printf("service# \t service name \t ip address \t port \t process# \tprocess name \tnode#  \tnode name \n");
    for(result = rbtree_first(&sv_tree);  \
            result!= NULL;  \
            result = rbtree_next(&sv_tree,result)){
        svc = (SERVICE_TYPE *)result->item;
        printf("    %d\t %16s\t %s \t %d ", svc->id, svc->name, inet_ntoa(svc->addr.sin_addr), ntohs(svc->addr.sin_port));

        printf("    %d\t\t %10s\t %d\t %s \n", svc->pid, svc->pname, svc->nid, svc->nname);
    }

    display_services();
    return 0;
}



