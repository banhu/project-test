/**@file 
 * Copyright (C) 2013, Sinovision Tech Ltd.
 * All rights reserved.
 *
 * @brief   exec
 *
 * @author  
 * @date 2014-4-8
 *
 */
#include <stdio.h> 
#include <stdlib.h> 
#include <string.h>
#include <signal.h>
#include <unistd.h>
#include <sys/wait.h>
#include <errno.h>
#include "ev_comm.h"
#include "EvFpgaConf.h"


#define	SHELL_MAX_CMD_LEN		(128)
#define MAX_LINE_LEN			(256)

extern char **environ;

/***/
static int getFileName(char *filePath, char *fileName, int fileNameLen)
{
	int len = 0, i = 0;
	int startInd = -1, endInd = -1;
	
	if ((NULL == filePath) || (strlen(filePath) <= 0) || 
		(NULL == fileName)) {
		printf("%s parameter filePath error", __FUNCTION__);
		return -1;
	}
	
	memset(fileName, 0x0, fileNameLen);
	
	len = strlen(filePath);
	for (i = len - 1; i >= 0; i--) {
		if (filePath[i] == '/') {
			startInd = i + 1;
			break;
		}
	}

	if (-1 == startInd) {
		startInd = 0;
	}

	for (i = startInd; i < len; i++) {
		if (filePath[i] == '.') {
			endInd = i;
		}
	}
	
	if (-1 == endInd) {
		endInd = len;
	}

	len = endInd - startInd;
	len = (len > fileNameLen) ?  fileNameLen : len;
	strncpy(fileName, filePath + startInd, len);
	
	return 0;
}

/**
*@bref execute a bin
*@binFile  Binary executable file
*
*@return zero is successful,other is failed
*/
int execBin(char *binFile)
{
	pid_t		pid;

	if ((NULL == binFile) || (strlen(binFile) <= 0)) {
		printf("%s parameter binFile error\n", __FUNCTION__);
		return -1;
	}

	// signal(SIGCHLD, SIG_IGN);
	
	if((pid = fork()) < 0) {
		printf("%s fork error", __FUNCTION__);
		return -1;
	} else if (pid == 0) {
		
		if(execle(binFile, binFile,
				  (char *)0, environ) <0 ) {
			printf("%s execle %s error\n", __FUNCTION__, binFile);
			exit(0);
		}
		
		exit(0);
	}
	
	return 0;
}

/**
*@bref execute a bin
*@binFile  Binary executable file
*@arg  arg(0),arg[1]..., must end with NULL
*@envp environment
*
*@return zero is successful,other is failed
*/
int execBinEx(const char *binFile, const char *arg, ...)
{
	pid_t pid;

	if ((NULL == binFile) || (strlen(binFile) <= 0)) {
		printf("%s parameter binFile error\n", __FUNCTION__);
		return -1;
	}

	signal(SIGCHLD, SIG_IGN);
	
	if ((pid = fork()) < 0) {
		printf("%s fork error", __FUNCTION__);
		return -1;
	} else if (pid == 0) {
		/* no arguments */
		if (arg == NULL) {
			if (execle(binFile, binFile, NULL, environ) < 0) {
				perror(binFile);
				printf("%s execle %s error\n", __FUNCTION__, binFile);
				exit(0);
			}
		}
		/* with arguments */
		else {
			va_list args;
			va_start(args, arg);
			
			if (execle(binFile, binFile, arg, args, NULL, environ) < 0) {
				perror(binFile);
				printf("%s execle %s error\n", __FUNCTION__, binFile);
				exit(0);
			}
			
			va_end(args);
		}
		exit(0);
	}
	
	return 0;
}

/**
*@bref execute a shell
*@shellCmd  shell command or shell file
*
*@return zero is successful,other is failed
*/
int execShell(char *shellCmd)
{
	int ret = -1;

	if ((NULL == shellCmd) || (strlen(shellCmd) <= 0)) {
		printf("%s parameter shellCmd error \n", __FUNCTION__);
		return -1;
	} 

	signal(SIGCHLD, SIG_DFL);
	
	ret = system(shellCmd);
	if (0 != ret) {
		printf("%s system(%s) error %d\n", __FUNCTION__, shellCmd, errno);	
	}
	
	signal(SIGCHLD, SIG_IGN);

	return ret;
}

/**
*@bref kill bin 
*@binFile  Binary executable file
*
*@return zero is successful,other is failed
*/
int killBin(char *binFile)
{
	char shellCmd[SHELL_MAX_CMD_LEN];
	int ret = -1;

	if ((NULL == binFile) || (strlen(binFile) <= 0)) {
		printf("%s parameter binFile error", __FUNCTION__);
		return -1;
	}
	
	
	memset(shellCmd, 0x0, SHELL_MAX_CMD_LEN);
	sprintf(shellCmd, "ps | grep %s | grep -v 'grep' | awk '{print $1}' | xargs kill -s 9", binFile);

	signal(SIGCHLD, SIG_IGN);

	ret = system(shellCmd);
	if ((0 != ret) && (errno != ECHILD)) {
		printf("%s system(%s) error %d\n", __FUNCTION__, shellCmd, errno);	
	}
	if (errno == ECHILD) {
		ret = 0;
	}

	

	return ret;
}

/**
*@bref is module installed 
*@moduleFile  modle file
*
*@return zero is module installed,other is not
*/
int isModuleIns(char *moduleFile)
{
	char shellCmd[SHELL_MAX_CMD_LEN];
	char moduleName[SHELL_MAX_CMD_LEN];
	char line[MAX_LINE_LEN];
	FILE  *fout;
	int ret = -1;

	if ((NULL == moduleFile) || (strlen(moduleFile) <= 0)) {
		printf("%s parameter moduleFile error", __FUNCTION__);
		return -1;
	}

	getFileName(moduleFile, moduleName, SHELL_MAX_CMD_LEN);
	//sprintf(shellCmd, "lsmod | grep %s ", moduleName);
	sprintf(shellCmd, "lsmod | grep '^%s\b'", moduleName);
	
	if ((fout = popen(shellCmd, "r")) == NULL) {
		printf("%s popen(%s) error", __FUNCTION__, shellCmd);
		return -1;
	}

	while (fgets(line, MAX_LINE_LEN, fout) != NULL ) {
		if (strstr(line, moduleName) != NULL) {
			ret = 0;
			break;
		}
	}

	pclose(fout);
	
	return ret;
}

/**
*@bref is bin executed 
*@binFile  Binary executable file
*
*@return zero is bin executed,other is not
*/
int isBinRun(char *binFile)
{
	char shellCmd[SHELL_MAX_CMD_LEN];
	char binName[SHELL_MAX_CMD_LEN];
	char	line[MAX_LINE_LEN];
	FILE  *fout;
	int ret = -1;

	if ((NULL == binFile) || (strlen(binFile) <= 0)) {
		printf("%s parameter binFile error", __FUNCTION__);
		return -1;
	}

	getFileName(binFile, binName, SHELL_MAX_CMD_LEN);
	sprintf(shellCmd, "ps | grep %s | grep -v 'grep'", binName);
	
	if ((fout = popen(shellCmd, "r")) == NULL) {
		printf("%s popen(%s) error", __FUNCTION__, shellCmd);
		return -1;
	}

	while (fgets(line, MAX_LINE_LEN, fout) != NULL ){
		if (strstr(line, binName) != NULL) {
			ret = 0;
			break;
		}
	}

	pclose(fout);
	
	return ret;
}

/**
*@bref insmod a module
*@moduleFile  modle file
*
*@return zero is successful,other is failed
*/
int insModule(char *moduleFile)
{
	char shellCmd[SHELL_MAX_CMD_LEN];

	if ((NULL == moduleFile) || (strlen(moduleFile) <= 0)) {
		printf("%s parameter moduleFile error", __FUNCTION__);
		return -1;
	}

	memset(shellCmd, 0x0, SHELL_MAX_CMD_LEN);
	strcpy(shellCmd, "insmod ");
	strcpy(shellCmd + 7, moduleFile);

	return execShell(shellCmd);
	
}

/**
*@bref rmmod a module
*@moduleFile  module file
*
*@return zero is successful,other is failed
*/
int rmModule(char *moduleFile)
{
	char shellCmd[SHELL_MAX_CMD_LEN];

	if ((NULL == moduleFile) || (strlen(moduleFile) <= 0)) {
		printf("%s parameter moduleFile error", __FUNCTION__);
		return -1;
	}

	memset(shellCmd, 0x0, SHELL_MAX_CMD_LEN);
	strcpy(shellCmd, "rmmod ");
	strcpy(shellCmd + 6, moduleFile);

	return execShell(shellCmd);
}



static int boardSvcId = 0;

/***/
void  handler_sig(int signo)
{
	EVENT_HEADER_TYPE event;
	
	event.code = EV_FPGA_CONF_STOP_PROGRAM;
	event.sid = boardSvcId;
	event.rid = boardSvcId;
	send_event_from(boardSvcId, boardSvcId, &event, sizeof(event), 0);

	//sleep(6);
	//exit(0);
}

/***/
void handerStopSig(int svc_id)
{
	boardSvcId = svc_id;
	signal(SIGQUIT, handler_sig);
	signal(SIGINT, handler_sig);
	
} 


