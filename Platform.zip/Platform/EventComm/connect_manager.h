/**@file
 * Copyright (C) 2013, Sinovision Tech Ltd.
 * All rights reserved.
 *
 * @brief  
 *
 * @author  
 * @date 2013-8-19
 *
 */
#ifndef _CONNECT_MANAGER_H_
#define _CONNECT_MANAGER_H_

#include <stdint.h>

struct ESINFO;


// connect status
enum CONNECT_STATUS
{
	CONN_STATUS_CLOSED = 0,
		
	//server status
	CONN_STATUS_REACHABLE,
	CONN_STATUS_ACCEPT,
	CONN_STATUS_WAIT_PROBE,
	//client status
	CONN_STATUS_INITCONNECT ,
	CONN_STATUS_INCOMPLETE,
	CONN_STATUS_CONNECTED,
	CONN_STATUS_PROBE,
	//
	CONN_STATUS_DEAD
};


enum RECEIVE_STATE
{
	R_IDLE = 0,
	R_HEADER,
	R_PAYLOAD
};

enum CONNECT_EV_TYPE
{
	CONN_TYPE_TIMER_EXPIRED = (1 << 0),
	CONN_TYPE_TIMER_DELAY   = (1 << 1),
	CONN_TYPE_PROBE		    = (1 << 2),
	CONN_TYPE_PROBE_RES	    = (1 << 3)
};

/**
 * information for connection
 */
typedef struct CONNECTION
{
    struct CONNECTION* next;
	struct CONNECTION* prev;
	int fd;	
	SVCID from;
	SVCID to;
	int is_accept_conn; //is server accept connection
	int conn_status; //connect status
	int connect_count; //try to connect count
	int complete_probe_count; //probe count when in CONN_STATUS_INCOMPLETE status
	int connected_probe_count; //probe count when in CONN_STATUS_CONNECTED status
	int probe_stat_probe_count; //probe count when in CONN_STATUS_PROBE status
	int accept_probe_count; //probe count when in CONN_STATUS_ACCEPT status
	int reach_probe_count; //probe count when in CONN_STATUS_ACCEPT status
	int wait_probe_count; //probe count when in CONN_STATUS_WAIT_PROBE status
	int en_connected_probe; //enable connected probe
	int rstate;   // receiving state
	int rbytes;   // received bytes
	void* rbuf;   // receive buffer address
	QUEUE *queue;  // queue
	int sbytes;   // sent bytes
	struct ev_timer_t *ev_timer; //connect timer
}CONN_T;

/**
*@bref destory connection by connection's fd
*
*@param fd of the connection
*/
void destory_conn_by_fd(int fd);

/** create new connection info 
*
*@param es_info current service specific info
*@param from target service id
*@param to target service id
*@param fd connection's 
*@return pointer to the new connection info
*/
struct CONNECTION* create_connection(struct ESINFO *es_info, SVCID from, SVCID to, int fd);


/** 
 *@bref establish the connection
 *
 *@param conn connection
 *@return zero is successful
 */
int establish_connection(struct CONNECTION *conn);

/**find the connection info according to from and to service id
 * @param from send connect service id
 * @param id target service id
 * @return CONNECTION
 */
struct CONNECTION *find_connection_bysvc(SVCID from, SVCID to);

/** find the connection info according to from and to service info
 * @param es_info current service specific info
 * @param id target service id
 * @return  connection
 */
struct CONNECTION * find_connection(struct ESINFO *es_info, SVCID to);

/**
*@bref process connect event
*@evnet connection event
*/
void process_conn_event(EV_ECL_CONNECT_TYPE *event);

/** get the connecetion info pointer
 * @param fd of the connection
 * @return pointer to the connection info
 */
struct CONNECTION* get_connection(int fd);

/**
*@bref start connect timer to check timer expired.
*@param conn connection
*/
void start_expired_check_timer(struct CONNECTION *conn);

/**close connection by connection's fd
*
*@param fd of the connection
*/
void close_conn_by_fd(int fd);

/* 
*@bref destory service's all connection 
*@param id of service
*/
void destory_conn_by_svcid(SVCID id);


#endif // _CONNECT_MANAGER_H_
