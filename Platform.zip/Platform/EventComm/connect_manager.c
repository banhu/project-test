/**@file  connection mamager
 * Copyright (C) 2013, Sinovision Tech Ltd.
 * All rights reserved.
 *
 * @brief   posix timer
 *
 * @author  
 * @date 2013-8-14
 *
 */
#include <stdio.h> 
#include <stdlib.h> 
#include <string.h>
#include <signal.h>
#include <time.h>
#include <errno.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <fcntl.h>
#include <sys/ioctl.h>

#include "rbtree.h"
#include "sys_topology.h"
#include "buffer.h"
#include "monitor.h"
#include "timer.h"
#include "connect_manager.h"
#include "logger.h"
extern ESINFO_T *services;

#define MAX_CONNECT_COUNT				(6000)
#define MAX_COMPLETE_PROBE_COUNT		(6000)
#define MAX_PROBE_STAT_PROBE_COUNT		(30)
#define MAX_TIMEOUT_COUNT	        	(6)
#define MAX_WAIT_PROBE_COUNT			(MAX_PROBE_STAT_PROBE_COUNT)
#define MAX_ACCEPT_PROBE_COUNT			(MAX_COMPLETE_PROBE_COUNT)

#define	CONNECT_AGAIN_TIME				(1000 * 2)//ms
#define	CONNECT_RETRY_TIME				(1000)  //ms
#define	COMPLETE_PROBE_TIME				(CONNECT_RETRY_TIME)
#define	CONNECTED_PROBE_TIME			(1000 * 2) 
#define	PROBE_STAT_PROBE_TIME			(1000 * 2) 
#define	ACCEPT_PROBE_TIME				(COMPLETE_PROBE_TIME + 200)
#define	REACHABLE_PROBE_TIME			(CONNECTED_PROBE_TIME + 200)
#define	WAIT_PROBE_TIME					(PROBE_STAT_PROBE_TIME + 200) 

//#define _CONNECT_QUIET

struct CONNECTION *connections;
os_mutex_t conn_mutex;		//connection protection mutex

extern os_mutex_t dev_mutex;		//devices protection mutex
extern os_mutex_t es_mutex;             ///< The thread list protection mutex.

static int is_conn_log_msg = 0;

int cmd_conn_log_msg()
{
	is_conn_log_msg = !is_conn_log_msg;
	printf("is_conn_log_msg:%d   0:closed  1:open\n",is_conn_log_msg);
	return 0;
}
//Notice: before release, should change the "printf  __FUNCTION__" to log_msg(),
//i have change some one,now the other may be in use,so change it latter


#define CONN_LOG(fmt, ...) \
    if (1 == is_conn_log_msg) \
        log_msg(LOG_LEVEL_DEBUG, fmt, __VA_ARGS__)

/**
*@bref start connect timer to delay send event.
*@param conn connection
*@param event event to send
*@param size   size of event
*@param delay_ms time to delay
*/
static int start_timer_send_ev(struct CONNECTION *conn, void *event, uint32_t size, uint32_t delay_ms)
{
	assert(NULL != conn && "connection is NULL");	
	assert(NULL != event && "event is NULL");	

	return event_timer_mod(conn->ev_timer, event, size, delay_ms, TIMER_OPT_ONCE);
	
}
/**
*@bref send event use connection.
*@param conn connection
*@param event event to send
*@param size   size of event
*/
void send_ev_by_conn(struct CONNECTION *conn, void *event, uint32_t size)
{
    EV_ECL_CONNECT_TYPE *new_event;
    ESINFO_T *es_info = NULL;
    SVCID svc_id;

    assert(NULL != conn && "connection is NULL");
    assert(NULL != event && "event is NULL");

	size = sizeof(EV_ECL_CONNECT_TYPE);
	new_event = (EV_ECL_CONNECT_TYPE *)buffer_get(size);
	if (NULL == new_event) {
		CONN_LOG("%s get buffer size %d error\n", __FUNCTION__, size);
        return;
    }

	memset((void *)new_event, 0x0, size);
    memcpy((void *)new_event, event, size);

	new_event->header.code = EV_ECL_CONNECT;
    if (1 == conn->is_accept_conn) {
    	new_event->header.rid = conn->from;
    	new_event->header.sid = conn->to;
    } else {
        new_event->header.rid = conn->to;
    	new_event->header.sid = conn->from;
    }
	new_event->header.length = size;
	new_event->header.checksum = new_event->header.code + new_event->header.rid
							+ new_event->header.sid + new_event->header.length;

	// Timestamp the event.
	new_event->header.sent = get_epoch_time_nano();
	new_event->header.complete = 0;
	new_event->header.received = 0;

	queue_add(conn->queue, (void*)new_event);

    svc_id = ((1 == conn->is_accept_conn ? conn->to : conn->from));
    es_info = find_service_inp(svc_id);

    if ((NULL != es_info) && (conn->fd > 0)) {
		if (!FD_ISSET(conn->fd, &es_info->wset)) {
			FD_SET(conn->fd, &es_info->wset);
		}
		wakeup_select(es_info);
    }

    return;
}

/**
*@bref send connect probe event.
*@param conn connection
*@param is_probe_res probe event or probe response
*@param delay_ms time to delay
*/
static void send_conn_probe_event(struct CONNECTION *conn, int is_probe_res, uint32_t delay_ms)
{
	EV_ECL_CONNECT_TYPE event;	
	uint32_t size = 0;   

	assert(NULL != conn && "connection is NULL");	
	
	size = sizeof(EV_ECL_CONNECT_TYPE);
	memset((void *)&event, 0x0, size);

	event.header.code = EV_ECL_CONNECT;
	event.from = conn->from;
	event.to = conn->to;
    event.fd = conn->fd;
	event.conn_status = conn->conn_status;
	event.en_connected_probe = conn->en_connected_probe;
	event.type = ((1 == is_probe_res) ? CONN_TYPE_PROBE_RES : CONN_TYPE_PROBE);
	
	if (delay_ms > 0) {
		event.type |= CONN_TYPE_TIMER_DELAY;
		start_timer_send_ev(conn, &event, size, delay_ms);
	} else {
	   send_ev_by_conn(conn, &event, size);
	}
}


/**
*@bref send connected or disconnect event, to application.
*@param conn connection
*@param is_connected connected event or disconnect response
*/
static void send_connect_event(struct CONNECTION *conn, int is_connected)
{
	EVENT_HEADER_TYPE *event;	
	ESINFO_T *es_info = NULL;
	uint32_t size = 0;
	char *buf;
	
	assert(NULL != conn && "connection is NULL");


	if (1 == is_connected) {
		size = sizeof(EV_ECL_CONNECTED_TYPE);
	} else {
		size = sizeof(EV_ECL_DISCONNECTED_TYPE);
	}
	
	buf = buffer_get(size);
	assert(NULL != buf && "malloc event is NULL");
	memset((void *)buf, 0x0, size);

	event = (EVENT_HEADER_TYPE *)buf;
	event->code = ((1 == is_connected) ? EV_ECL_CONNECTED : EV_ECL_DISCONNECTED);
	if (1 == conn->is_accept_conn) {
		event->rid = conn->to;
		event->sid = conn->to;
	} else {
		event->rid = conn->from;
		event->sid = conn->from;	
	}
	event->length = size;
	event->checksum = event->code + event->rid 
							+ event->sid + event->length;

		// Timestamp the event.
	event->sent = get_epoch_time_nano();
	event->complete = 0;
	event->received = 0;
	if (1 == is_connected) {
		((EV_ECL_CONNECTED_TYPE *)buf)->from = conn->from;
		((EV_ECL_CONNECTED_TYPE *)buf)->to = conn->to;
	} else {
		((EV_ECL_DISCONNECTED_TYPE *)buf)->from = conn->from;
		((EV_ECL_DISCONNECTED_TYPE *)buf)->to = conn->to;
	}

	es_info = find_service_inp(event->rid);
	if (NULL != es_info) {
		send_in_process(es_info, buf);
	} else {
		buffer_release(buf);
		CONN_LOG("%s service (%d) is not exist\n", __FUNCTION__, event->rid);
	}

	return;
	
}

/** check connect status
 * @param socket handler
 * @param id target service id
 * @return  0:connect is OK
 * @return -1:connect is error
 */
static int check_connect_status(int connfd)
{
    int fd = connfd;
    fd_set rset, wset;
    struct timeval tval;
    int error;
    socklen_t len = sizeof (error);
    FD_ZERO(&rset);
    FD_SET(fd, &rset);
    wset = rset;
    tval.tv_sec = 0;
    tval.tv_usec = 0;
    int rsel = 0;//,rs = 0; ws = 0;

    //when select return >0 then some fd can read or write or have an error , when <=0, the socket is error
    //if the connect is ok. hear at list have a wset return.
    if ((rsel=select(fd + 1, &rset, &wset, NULL, &tval)) <= 0) {
    	CONN_LOG( "%s check connect select fd %d is error\n", __FUNCTION__,fd);
    	return -1;
    }
    //actually,the socket is ok ,the  fd can be not  in the rset,
    //commonly if it in rset,there will be an error or have receive a data, actually we are not notice the received data
    //check the rset getsockopt return 0,the rset is ok
    //actually when the network is not in use, only check the rset is ok
    if (FD_ISSET(fd, &rset)) {
        if (getsockopt(fd, SOL_SOCKET, SO_ERROR, &error, &len) < 0){
        	CONN_LOG( "%s check connect getsockopt rset fd %d is error\n", __FUNCTION__,fd);
        	return -1;
        }
        if (error > 0)    // we have wait a moment for the check, so  the EINPROGRESS,etc. error code lose efficacy
        {
        	CONN_LOG("%s check connect getsockopt rset error: %s(errno: %d)\n", __FUNCTION__,strerror(error),error);
        	return -1;
        }
    }
    //actually,the socket is ok ,the  fd fixed in the wset, but we still check it if is error
    //check the wset getsockopt return 0,the wset is ok
    if (FD_ISSET(fd, &wset)) {
        if (getsockopt(fd, SOL_SOCKET, SO_ERROR, &error, &len) < 0) {
        	CONN_LOG( "%s check connect getsockopt wset fd %d is error\n", __FUNCTION__,fd);
        	return -1;
        }
        if (error > 0)    // we have wait a moment for the check, so  the EINPROGRESS,etc. error code lose efficacy
        {
        	CONN_LOG("%s check connect getsockopt wset error: %s(errno: %d)\n", __FUNCTION__,strerror(error),error);
        	return -1;
        }
    }
    return 0;
}
/**
 * @bref send probe event by conn
 * @param conn connection
 */
static void send_probe_connect(struct CONNECTION *conn)
{
	ESINFO_T *es_info = NULL;
	int ret = 0, arg = 0, fd = 0;
	fd = conn->fd;
	ret  = check_connect_status(fd);
	if (ret < 0)
	{
		close(fd);
		conn->fd = 0;
		conn->conn_status = CONN_STATUS_INITCONNECT ;
		start_expired_check_timer(conn);
		CONN_LOG("%s Connection(from %d to %d) fd %d check error to close. "
				"status CONNECT_RETRY -- > CONNECTING, reconnet %d\n",
				__FUNCTION__, conn->from, conn->to, fd, conn->connect_count);
	}else{
		conn->conn_status = CONN_STATUS_CONNECTED;
		arg = 1;
		setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, &arg, sizeof(int));
		// Set keepalive on socket
		arg = 1;
		setsockopt(fd, SOL_SOCKET, SO_KEEPALIVE, &arg, sizeof(int));
		es_info = find_service_inp(conn->from);
		if (NULL != es_info) {
			if (!FD_ISSET(fd, &es_info->rset))
				FD_SET(fd, &es_info->rset);

			if (!FD_ISSET(fd, &es_info->wset))
				FD_SET(fd, &es_info->wset);
#if 0
            if (queue_size(conn->queue) > 0) {
			    FD_SET(fd, &es_info->wset);
            }
#endif
			if(fd > es_info->maxFd)
				es_info->maxFd = fd;
			wakeup_select(es_info);
		}
		send_conn_probe_event(conn, 0, 0);
		send_connect_event(conn, 1);
		CONN_LOG("%s Connection(from %d to %d) fd %d check ok. "
				"status CONNECT_RETRY -- > CONNECTING, reconnet %d\n",
				__FUNCTION__, conn->from, conn->to, fd, conn->connect_count);
	}
	return;
}


/**
*@bref start connect timer to check timer expired.
*@param conn connection
*/
void start_expired_check_timer(struct CONNECTION *conn)
{
	EV_ECL_CONNECT_TYPE event;
	uint32_t size;
	uint32_t tmo_ms;

	assert(NULL != conn && "connection is NULL");	

	size = sizeof(EV_ECL_CONNECT_TYPE);
	memset((void *)&event, 0x0, size);

	event.header.code = EV_ECL_CONNECT;
	event.from = conn->from;
	event.to = conn->to;
	event.fd = conn->fd;
	event.conn_status = conn->conn_status;
	event.type = CONN_TYPE_TIMER_EXPIRED;
	
	switch (conn->conn_status)
	{
		case CONN_STATUS_INITCONNECT :
			tmo_ms = CONNECT_AGAIN_TIME;
			break;
		case CONN_STATUS_INCOMPLETE:
			tmo_ms = COMPLETE_PROBE_TIME;
			break;
		case CONN_STATUS_CONNECTED:
			tmo_ms = CONNECTED_PROBE_TIME;
			break;
		case CONN_STATUS_PROBE:
			tmo_ms = PROBE_STAT_PROBE_TIME;
			break;
		case CONN_STATUS_ACCEPT:
			tmo_ms = ACCEPT_PROBE_TIME;
			break;
		case CONN_STATUS_WAIT_PROBE:
			tmo_ms = WAIT_PROBE_TIME;
			break;
		case CONN_STATUS_REACHABLE:
			tmo_ms = REACHABLE_PROBE_TIME;
			break;
		default:
			return;
	}
	event_timer_mod(conn->ev_timer, &event, size, tmo_ms, TIMER_OPT_ONCE);
	return;
}


/** 
 *@bref establish the connection
 *
 *@param conn connection
 *@return zero is successful
 */
int establish_connection(struct CONNECTION *conn)
{
	SERVICE_TYPE *svc = NULL;
	struct sockaddr address;
	int fd = 0, ret = 0;
	int arg = 0;

	
	assert(NULL != conn && "connection is NULL");
	svc = lookup_service(conn->to);
	if(svc == NULL)
	 return PLATFORM_ERR_FIND;
	

	address = *(struct sockaddr *)&(svc->addr);
	
	fd = socket(AF_INET, SOCK_STREAM, 0);
    assert(fd >= 0 && "can't create a TCP/IP socket");

	// Set to non-blocking mode.
	arg = 1;
	arg = ioctl(fd, FIONBIO, &arg);
	assert (arg != -1 && "can't set listen socket FIONBIO");

	

	ret = connect(fd, &address, sizeof(address));
	conn->connect_count++;
	if ( ret < 0) {
		if (errno == EINPROGRESS || errno == EWOULDBLOCK) {
			// A connection attempt is in progress.
			// wait some time for retry if in blocking mode, current only support non-blocking mode
		} else if (errno == EISCONN || errno == EALREADY) {
			// We are already connected.

		} else if (errno == ECONNREFUSED) {
			// connection refused
			// wait some time for retry if in blocking mode, current only support non-blocking mode
		} else {
		    //connection failed, start timer connect again.
			close(fd);
			conn->conn_status = CONN_STATUS_INITCONNECT ;
			start_expired_check_timer(conn);

			CONN_LOG("%s Connection(from %d to %d) error.  status CONNECTING, reconnet %d\n",
					__FUNCTION__, conn->from, conn->to, conn->connect_count);
			return PLATFORM_ERR_CONNECT;
		}
	} else {
		// The connect succeeded.

	}


	conn->fd = fd;
	conn->conn_status = CONN_STATUS_INCOMPLETE;
	start_expired_check_timer(conn);

	CONN_LOG("%s Connection(from %d to %d). fd %d  status CONNECT_RETRY\n",
			__FUNCTION__, conn->from, conn->to, conn->fd);
	return 0;
}



/** find the connection info according to from and to service id
 * @param from send connect service id
 * @param id target service id
 * @return CONNECTION
 */
struct CONNECTION *find_connection_bysvc(SVCID from, SVCID to)
{
    struct CONNECTION *conn = NULL;

   
    os_mutex_lock(conn_mutex);
	conn = connections;
    while (NULL != conn) {
        if (conn->from == from && conn->to == to) {
            os_mutex_unlock(conn_mutex);
			return conn;
        }
        conn = conn->next;
    }
	conn = connections;
	while(NULL != conn) {
        if (conn->to == from && conn->from == to) {
			os_mutex_unlock(conn_mutex);
			return conn;
        }
        conn = conn->next;
    }
    os_mutex_unlock(conn_mutex);
	return conn;
}

/** get the connecetion info pointer
 *@param fd of the connection
 *@return pointer to the connection info
 */
struct CONNECTION* get_connection(int fd)
{
    struct CONNECTION *conn = NULL;

    os_mutex_lock(conn_mutex);
    conn = connections;
    while (conn) {
        if (fd == conn->fd) {
            break;
        }
        conn = conn->next;
    }   
    os_mutex_unlock(conn_mutex);
	return conn;
}



void destory_connection(struct CONNECTION *conn);

/** create new connection info 
*
*@param es_info current service specific info
*@param from target service id
*@param to target service id
*@param fd connection's 
*@return pointer to the new connection info
*/
struct CONNECTION* create_connection(struct ESINFO *es_info, SVCID from, SVCID to, int fd)
{
	struct CONNECTION *conn = NULL;
#if 1
	conn = find_connection_bysvc(from, to);
	if(NULL != conn)
		destory_connection(conn);
#endif
	assert(es_info != NULL && "es_info == NULL");
	
	conn = (struct CONNECTION *)malloc(sizeof(struct CONNECTION));
	assert(conn != NULL && "Can't allocate connection specific data");

	memset((void *)conn, 0x0, sizeof(struct CONNECTION));


    os_mutex_lock(conn_mutex);
	//add conntion to global connections
    conn->next = connections;
    if (connections != NULL)
        connections->prev = conn;
    conn->prev = NULL;
    connections = conn;
	os_mutex_unlock(conn_mutex);
    
	conn->from = from;
	conn->to = to;
	
	conn->rstate = R_IDLE;
	conn->rbytes = 0;
	conn->rbuf = NULL;
    conn->queue = queue_new();
	conn->sbytes = 0;
	conn->conn_status = CONN_STATUS_CLOSED;
	conn->connect_count = 0;
	conn->complete_probe_count = 0;
	conn->connected_probe_count = 0;
	conn->probe_stat_probe_count = 0;
	conn->en_connected_probe = 0;
	
	//create a timer
	conn->ev_timer = event_timer_start(es_info, NULL, 0, 0, 0);

	if (fd > 0) {
		conn->fd = fd;
		FD_SET(fd, &es_info->rset);
		if(fd > es_info->maxFd)
			es_info->maxFd = fd;
		wakeup_select(es_info);
	}
	CONN_LOG( "%s from %d to %d, fd %d \n", __FUNCTION__, conn->from, conn->to, fd);

	return conn;
}

void reconnect(struct CONNECTION *conn, int en_probe)
{
    ESINFO_T *es_info = NULL;
    int fd = 0;
    SVCID svc_id;

    assert(NULL != conn && "connection is NULL");

    svc_id = ((1 == conn->is_accept_conn) ? conn->to : conn->from);

    es_info = find_service_inp(svc_id);

    if (NULL ==  es_info) {
    	CONN_LOG("%s get es_info by serivceId (%d) error\n", __FUNCTION__, svc_id);
    }

    if (NULL != es_info && conn->fd > 0) {
        fd = conn->fd;
        close(fd);
        FD_CLR(fd, &es_info->rset);
        FD_CLR(fd, &es_info->wset);
        for (fd = es_info->maxFd; fd > 0; --fd) {
            if (FD_ISSET(fd, &es_info->rset) || FD_ISSET(fd, &es_info->wset)) {
                es_info->maxFd = fd;
                break;
            }
        }
    }
    conn->conn_status = CONN_STATUS_CLOSED;
    conn->connect_count = 0;
    conn->complete_probe_count = 0;
    conn->connected_probe_count = 0;
    conn->en_connected_probe = ((en_probe == 1) ? 1 : 0);

    establish_connection(conn);


}

/**This Function just for UnitTest add by huyf
 * create new connection info use target svc id, don't check if it is in process,
 *@param to target service id
 *@param en_probe is enable probe package
 */
void connection_svc_from_to(SVCID from ,SVCID to, int en_probe)
{
	struct CONNECTION* conn;
    ESINFO_T *es_info = find_service_inp(from);
	if(es_info == NULL)
	{
		printf("service id %d not found \n", from);
	}
	conn = find_connection_bysvc(es_info->sid, to);
	if (NULL == conn) {
		conn = create_connection(es_info, es_info->sid, to, 0);
		if (NULL == conn) {
			CONN_LOG("%s create_connection error\n", __FUNCTION__);
			return ;
		} else {
			conn->en_connected_probe = ((en_probe == 1) ? 1 : 0);
			//connect
			establish_connection(conn);
		}
	}else{
		 reconnect(conn, en_probe);
	}
}

/**create new connection info use target svc id, and auto connect.
 *@param to target service id
 *@param en_probe is enable probe package
 */
void connection_to_svc(SVCID to, int en_probe)
{
	struct ESINFO *es_info;
	struct CONNECTION* conn;
	ESINFO_T *to_svc = NULL;


	es_info = get_es_info();
	assert(es_info != NULL && "the event service info is invalid");

	to_svc =  find_service_inp(to);
	if (NULL != to_svc) {
		CONN_LOG("%s the connectiong from %d to %d is in some process\n",
			__FUNCTION__, es_info->sid, to);
        return;
	}


	conn = find_connection_bysvc(es_info->sid, to);
	if (NULL == conn) {
		conn = create_connection(es_info, es_info->sid, to, 0);
		if (NULL == conn) {
			CONN_LOG("%s create_connection error\n", __FUNCTION__);
			return ;
		} else {
			conn->en_connected_probe = ((en_probe == 1) ? 1 : 0);
			//connect
			establish_connection(conn);
		}
	}else{
		 reconnect(conn, en_probe);
	}
}
/**destory a connection info and remove the fd from read/write fd set
 *@param conn connection
 */
void destory_connection(struct CONNECTION *conn)
{
	ESINFO_T *es_info = NULL;
	int fd = 0;
	SVCID svc_id;
	
	assert(NULL != conn && "connection is NULL");

	event_timer_stop(conn->ev_timer);

	svc_id = ((1 == conn->is_accept_conn) ? conn->to : conn->from);
	
	es_info = find_service_inp(svc_id);

	if (NULL ==  es_info) {
		CONN_LOG("%s get es_info by serivceId (%d) error\n", __FUNCTION__, svc_id);
	}
	
	if (NULL != es_info && conn->fd > 0) {
		fd = conn->fd;
		close(fd);
	    FD_CLR(fd, &es_info->rset);
		FD_CLR(fd, &es_info->wset);
		for (fd = es_info->maxFd; fd > 0; --fd) {
			if (FD_ISSET(fd, &es_info->rset) || FD_ISSET(fd, &es_info->wset)) {
				es_info->maxFd = fd;
				break;
			}
		}
		wakeup_select(es_info);
		
		
	}

    os_mutex_lock(conn_mutex);
	if (conn->prev != NULL) {
		conn->prev->next = conn->next;
	} else {
		connections = conn->next;
	}
	if (conn->next != NULL) {
		conn->next->prev = conn->prev;
	}
	os_mutex_unlock(conn_mutex);
    
	queue_free(&conn->queue);
	FREE(conn);

	return;
}

/**close a connection info and remove the fd from read/write fd set
 * don't free connection
 *@param connection
 */
void close_connection(struct CONNECTION *conn)
{
	ESINFO_T *es_info = NULL;
	int fd = 0;
	SVCID svc_id;
	
	assert(NULL != conn && "connection is NULL");
	
	//disable timer
	event_timer_mod(conn->ev_timer, NULL, 0, 0, 0);

	svc_id = ((1 == conn->is_accept_conn) ? conn->to : conn->from);
	es_info = find_service_inp(svc_id);
	if (NULL ==  es_info) {
		CONN_LOG("%s get es_info by serviceId (%d) error\n", __FUNCTION__, svc_id);
	}

	if ((CONN_STATUS_CONNECTED == conn->conn_status) || 
		(CONN_STATUS_REACHABLE == conn->conn_status)) {
		send_connect_event(conn, 0);
	}
		
	fd = conn->fd;
	if (NULL != es_info && conn->fd > 0) {
		close(fd);
	    FD_CLR(fd, &es_info->rset);
		FD_CLR(fd, &es_info->wset);
		for (fd = es_info->maxFd; fd > 0; --fd) {
			if (FD_ISSET(fd, &es_info->rset) || FD_ISSET(fd, &es_info->wset)) {
				es_info->maxFd = fd;
				break;
			}
		}
		wakeup_select(es_info);
	}
	

	if (1 == conn->is_accept_conn) {

		CONN_LOG("%s close conn from %d to %d fd %d\n",
            __FUNCTION__, conn->from, conn->to, conn->fd);

		event_timer_stop(conn->ev_timer);
		
		conn->conn_status = CONN_STATUS_DEAD;


		os_mutex_lock(conn_mutex);
		if (conn->prev != NULL) {
			conn->prev->next = conn->next;
		} else {
			connections = conn->next;
		}
		if (conn->next != NULL) {
			conn->next->prev = conn->prev;
		}
        os_mutex_unlock(conn_mutex);
        
		queue_free(&conn->queue);
		FREE(conn);
		
		
		
	} else {
	
		conn->rstate = R_IDLE;
		conn->rbytes = 0;
		conn->rbuf = NULL;
		conn->fd = 0;
		conn->conn_status = CONN_STATUS_CLOSED;
		conn->connect_count = 0;
		conn->complete_probe_count = 0;
		conn->connected_probe_count = 0;
		conn->probe_stat_probe_count = 0;

		//go to connection again
		conn->conn_status = CONN_STATUS_INITCONNECT ;
		start_expired_check_timer(conn);
		
	}
	return;
}

/** close connection by connection's fd
*@param fd of the connection
*/
void close_conn_by_fd(int fd)
{
	struct CONNECTION *conn;
	
	assert(fd > 0 && "fd <= 0");
	
	conn = get_connection(fd);
	if (NULL != conn) {
		send_connect_event(conn, 0);
		close_connection(conn);
	} else {
		CONN_LOG("%s get connection by fd (%d) error\n", __FUNCTION__, fd);
	}
}



/**
*@bref destory connection by connection's fd
*
*@param fd of the connection
*/
void destory_conn_by_fd(int fd)
{
	struct CONNECTION *conn;
	
	assert(fd > 0 && "fd <= 0");
	
	conn = get_connection(fd);
	if (NULL != conn) {
		destory_connection(conn);
	} else {
		CONN_LOG("%s get connection by fd (%d) error\n", __FUNCTION__, fd);
	}
}

/**@bref destory service's all connection 
*@param id of service
*/
void destory_conn_by_svcid(SVCID id)
{
	struct CONNECTION *conn, *conn_tmp;
	ESINFO_T *es_info = NULL;
	int fd = 0;
	
	assert(id > 0 && "id <= 0");

    os_mutex_lock(conn_mutex);
	conn = connections;
	
    while (NULL != conn) {
        if (conn->from != id && conn->to != id) {
			 conn = conn->next;
			 continue;
        }


		event_timer_stop(conn->ev_timer);
		
		es_info = find_service_inp(id);
		if (NULL ==  es_info) {
			CONN_LOG("%s get es_info by serviceId (%d) error\n",
				__FUNCTION__, id);
		}
	
		if (NULL != es_info && conn->fd > 0) {
			fd = conn->fd;
			close(fd);
		    FD_CLR(fd, &es_info->rset);
			FD_CLR(fd, &es_info->wset);
			for (fd = es_info->maxFd; fd > 0; --fd) {
				if (FD_ISSET(fd, &es_info->rset) || FD_ISSET(fd, &es_info->wset)) {
					es_info->maxFd = fd;
					break;
				}
			}
		}
        
		
		if (conn->prev != NULL) {
			conn->prev->next = conn->next;
		} else {
			connections = conn->next;
		}
		if (conn->next != NULL) {
			conn->next->prev = conn->prev;
		}
        conn_tmp = conn;
        conn = conn->next;
		
        
		queue_free(&conn_tmp->queue);
		FREE(conn_tmp);
    }
    os_mutex_unlock(conn_mutex);
}


/**
*process expired timer event
*/
static void process_expired_time_ev(EV_ECL_CONNECT_TYPE *event)
{
	struct CONNECTION *conn = NULL;

	assert(NULL != event && "event is NULL");

	conn = find_connection_bysvc(event->from, event->to);
	if ((NULL != conn) && (1 == conn->is_accept_conn)) {// conn is null? how can get conn->is_accept_conn?
            conn = get_connection(event->fd);
	}
   
	if (NULL == conn) {
		CONN_LOG("%s get connection from (%d) to (%d) fd %d is NULL\n",
			__FUNCTION__, event->from, event->to, event->fd);
		return;
	}
	
	CONN_LOG("%s connection from (%d) to (%d) stauts %d\n", __FUNCTION__, event->from, event->to, conn->conn_status);

	switch(conn->conn_status)
	{
		case CONN_STATUS_INITCONNECT :
			if (conn->connect_count > MAX_CONNECT_COUNT) {
				conn->conn_status = CONN_STATUS_DEAD;
				//free connection
				destory_connection(conn);
			} else {
				establish_connection(conn);
			}
			break;
		case CONN_STATUS_INCOMPLETE:
			if (conn->connect_count > MAX_CONNECT_COUNT) {
				conn->conn_status = CONN_STATUS_DEAD;
				//free connection
				destory_connection(conn);
			} else {
				send_probe_connect(conn);
			}
			break;
		case CONN_STATUS_CONNECTED:
			{
				conn->probe_stat_probe_count++;
				
				if(conn->probe_stat_probe_count == MAX_TIMEOUT_COUNT)//modify 18.11.16  by zhiqiang.liu
				{
					send_connect_event(conn, 0);
					close_connection(conn);
					conn->conn_status = CONN_STATUS_PROBE;
					
					/*
					printf("%s connect (fromm %d to %d) fd %d status connected --> probe, send probe, count %d\n",
							__FUNCTION__, conn->from, conn->to, conn->fd, conn->probe_stat_probe_count);*/
					
					CONN_LOG("%s connect (fromm %d to %d) fd %d status connected --> probe, send probe, count %d\n",
							__FUNCTION__, conn->from, conn->to, conn->fd, conn->probe_stat_probe_count);
					
				}
				send_conn_probe_event(conn, 0, 0);
				start_expired_check_timer(conn);
				
				
				CONN_LOG("%s connect expired (fromm %d to %d) fd %d status connected --> connected, send probe, count %d\n",
							__FUNCTION__, conn->from, conn->to, conn->fd, conn->probe_stat_probe_count);
			}
			break;
		case CONN_STATUS_PROBE:
			if (conn->probe_stat_probe_count > MAX_PROBE_STAT_PROBE_COUNT) {
				//close connection
			    reconnect(conn, conn->en_connected_probe);

			/*
				printf("%s close connect (fromm %d to %d) fd %d status probe --> closed,reconnect again\n",
							__FUNCTION__, conn->from, conn->to, conn->fd);
							*/
				CONN_LOG("%s close connect (fromm %d to %d) fd %d status probe --> closed,reconnect again\n",
							__FUNCTION__, conn->from, conn->to, conn->fd);

			} else {
				/*
				if(conn->probe_stat_probe_count == MAX_TIMEOUT_COUNT)
				{
					send_connect_event(conn, 0);
					close_connection(conn);
				}*/
				conn->probe_stat_probe_count++;
				send_conn_probe_event(conn, 0, 0);
	            start_expired_check_timer(conn);
				/*
				printf("%s connect (fromm %d to %d) fd %d status probe, send probe, count %d\n",
				            __FUNCTION__, conn->from, conn->to, conn->fd, conn->probe_stat_probe_count);*/
				            
				CONN_LOG("%s connect (fromm %d to %d) fd %d status probe, send probe, count %d\n",
				            __FUNCTION__, conn->from, conn->to, conn->fd, conn->probe_stat_probe_count);
			}
			break;
		case CONN_STATUS_WAIT_PROBE:
			/*if (conn->wait_probe_count > MAX_WAIT_PROBE_COUNT) {
		
				conn->conn_status = CONN_STATUS_DEAD;
				conn->wait_probe_count = 0;
				conn->accept_probe_count = 0;
						
				//free connect
				destory_connection(conn);

				//send disconnect event
				send_connect_event(conn, 0);
				CONN_LOG("%s close connect (fromm %d to %d) fd %d status wait_probe\n",__FUNCTION__, conn->from, conn->to, conn->fd);
			} else {}*/
			if(conn->wait_probe_count > MAX_TIMEOUT_COUNT)
			{
				send_connect_event(conn, 0);
				close_connection(conn);
				break;
			}else{
				conn->wait_probe_count++;
				start_expired_check_timer(conn);

				CONN_LOG("%s connect (fromm %d to %d) fd %d status wait_probe,count %d\n",
							__FUNCTION__, conn->from, conn->to, conn->fd, conn->wait_probe_count);
			}
			break;

		case  CONN_STATUS_ACCEPT:  //accepte status probe timer expired
			if (conn->accept_probe_count > MAX_ACCEPT_PROBE_COUNT) {

				conn->conn_status = CONN_STATUS_DEAD;
				conn->wait_probe_count = 0;
				conn->accept_probe_count = 0;
				//free connect
				destory_connection(conn);
			} else {
				conn->accept_probe_count++;
				start_expired_check_timer(conn);
				CONN_LOG("%s connect (fromm %d to %d) fd %d status accept,count %d\n",
							__FUNCTION__, conn->from, conn->to, conn->fd, conn->accept_probe_count);
			}
			 break;
		case CONN_STATUS_REACHABLE:
			{
				conn->conn_status = CONN_STATUS_WAIT_PROBE;
				conn->wait_probe_count = 1;
				start_expired_check_timer(conn);
				//send_connect_event(conn, 0);

				CONN_LOG("%s connect (fromm %d to %d) fd %d status reachable --> wait_probe, count %d, reach_probe_count %d\n",
							__FUNCTION__, conn->from, conn->to, conn->fd, conn->wait_probe_count, conn->reach_probe_count);
			}
			break;
		default:
			break;
	}
}

/**exec in server only*/
static void process_conn_probe_ev(EV_ECL_CONNECT_TYPE *event)
{
	struct CONNECTION *conn = NULL;


	assert(NULL != event && "event is NULL");


	conn = get_connection(event->fd);
	if (NULL == conn) {
		CONN_LOG("%s get_connection from (%d) to (%d) fd %d is NULL\n",
			__FUNCTION__, event->from, event->to, event->fd);
		return;
	}
	
	event_timer_mod(conn->ev_timer, NULL, 0, 0, 0);

	//the accept connection must set conn->from when receive the first package.
	if (CONN_STATUS_ACCEPT == conn->conn_status) {
#if 1
	struct CONNECTION *conn1 = NULL;
	conn1 = find_connection_bysvc(event->from, event->to);
	if(NULL != conn1)
		destory_connection(conn1);
#endif
        conn->conn_status = CONN_STATUS_REACHABLE;
		conn->from = event->from;
		conn->en_connected_probe = ((1 == event->en_connected_probe) ? 1 : 0);

		//send connected event
		send_connect_event(conn, 1);

		//send probe response
		send_conn_probe_event(conn, 1, 0);

		//start wait timer
		if (1 == conn->en_connected_probe) {
            conn->reach_probe_count = 0;
			start_expired_check_timer(conn);
		}
		CONN_LOG("%s connection (from %d to %d) fd %d, status accept,receive probe,enable probe %d\n",
					__FUNCTION__, conn->from, conn->to, conn->fd, conn->en_connected_probe);
		return;
	}

	if (CONN_STATUS_REACHABLE == conn->conn_status &&
		(1 == conn->en_connected_probe)) {
		//send probe response and start wait timer
		send_conn_probe_event(conn, 1, 0);
		start_expired_check_timer(conn);
		conn->reach_probe_count++;

		CONN_LOG("%s connect (fromm %d to %d) fd %d, status reachable,receive probe,count %d\n",
					__FUNCTION__, conn->from, conn->to, conn->fd, conn->reach_probe_count);
		return;
	}

	if (CONN_STATUS_WAIT_PROBE == conn->conn_status) {
		conn->conn_status = CONN_STATUS_REACHABLE;
		//send_connect_event(conn, 1);
		if (1 == conn->en_connected_probe) {
            conn->reach_probe_count = 0;
			send_conn_probe_event(conn, 1, 0);
			//start_expired_check_timer(conn);
		}	
		//send_connect_event(conn, 1);
		CONN_LOG("%s connect (fromm %d to %d) fd %d status wait_probe --> reachable\n",
					__FUNCTION__, conn->from, conn->to, conn->fd);
		return ;
	}
    
    //printf("%s connetion status %d not proccessed\n",__FUNCTION__, conn->conn_status);

 	return;
}

/**process connect probe response**/
static void process_conn_probe_res_ev(EV_ECL_CONNECT_TYPE *event)
{
	struct CONNECTION *conn = NULL;

	assert(NULL != event && "event is NULL");


	conn = get_connection(event->fd);
	if (NULL == conn) {
		CONN_LOG("%s connection (from %d to %d) fd %d is NULL\n",
			__FUNCTION__, event->to, event->from, event->fd);
		return;
	}
	
	event_timer_mod(conn->ev_timer, NULL, 0, 0, 0);
	
	if ((CONN_STATUS_CONNECTED == conn->conn_status) && 
		(1 == conn->en_connected_probe)) {
		conn->probe_stat_probe_count=0; //add 18.11.16 by zhiqiang.liu
		send_conn_probe_event(conn, 0, CONNECTED_PROBE_TIME);
		conn->connected_probe_count++;
		CONN_LOG("%s Connection(from %d to %d) fd %d, status CONNECTED, receive probe response,count %d\n",
				__FUNCTION__, conn->from, conn->to, conn->fd, conn->connected_probe_count);
		return;
	}

	if (CONN_STATUS_PROBE == conn->conn_status) {
		conn->conn_status = CONN_STATUS_CONNECTED;
		if (1 == conn->en_connected_probe) {
            conn->connected_probe_count = 0;
			send_conn_probe_event(conn, 0, CONNECTED_PROBE_TIME);
		}
		
		send_connect_event(conn, 1);

		/*
		printf("%s Connection(from %d to %d) fd %d,count=%d, status PROBE --> CONNECTED\n",
			__FUNCTION__, conn->from, conn->to, conn->fd,conn->probe_stat_probe_count);*/
		return;
	}

     //printf("%s connetion status %d not proccessed\n",__FUNCTION__, conn->conn_status);
	
	return;
}

/**process connect delay send evnet response**/
static void process_conn_delay_send_ev(EV_ECL_CONNECT_TYPE *event)
{
	struct CONNECTION *conn = NULL;

	assert(NULL != event && "event is NULL");

	
	conn = get_connection(event->fd);
	if (NULL == conn) {
		CONN_LOG("%s connection from (%d) to (%d) is not existent\n",
			__FUNCTION__, event->from, event->to);
		return;
	}
	
	event->type &= ~CONN_TYPE_TIMER_DELAY;
    
	send_ev_by_conn(conn, (EVENT_HEADER_TYPE *)event, sizeof(EV_ECL_CONNECT_TYPE));	
	start_expired_check_timer(conn);
}

/**
*@bref process connect event
*
*@evnet connection event
*/
void process_conn_event(EV_ECL_CONNECT_TYPE *event)
{

	assert(NULL != event && "event is NULL");	

	if (CONN_TYPE_TIMER_EXPIRED == event->type) {
		process_expired_time_ev(event);	
	} else if (CONN_TYPE_PROBE == event->type){
		process_conn_probe_ev(event);
	} else if (CONN_TYPE_PROBE_RES == event->type) {
		process_conn_probe_res_ev(event);
	} else if (CONN_TYPE_TIMER_DELAY & event->type) { 
		process_conn_delay_send_ev(event);
	} else {
		CONN_LOG("%s unsport connect event type %d\n", __FUNCTION__, event->type);
	}
	
	//buffer_release((void *)event);
	log_event((void *)event);
	
}
const char * TRYLOCK(os_mutex_t mutex)
{
	if (0 == os_mutex_trylock(mutex))
	{
		os_mutex_unlock(mutex);
		return "Free";
	}else{
		return "Lock";
	}
}


int cmd_display_conns(int argc, char * const argv[])
{
	ESINFO_T *es_info = NULL;

    printf("\nAlive connections: \n");
    printf("\nfd              from                            to          status\tconn count\tqueue size:\n");


    os_mutex_lock(conn_mutex);
    struct CONNECTION *conn = connections;
    while (NULL != conn) {
        printf("%2d   %20s(%3d)  %20s(%3d)", conn->fd, get_service_name(conn->from),conn->from, get_service_name(conn->to),conn->to );
        switch(conn->conn_status){
        case CONN_STATUS_CLOSED:
            printf("   closed");
            break;
        case CONN_STATUS_ACCEPT:
            printf("  accept");
            break;
        case CONN_STATUS_REACHABLE:
            printf("   reachable");
            break;
        case CONN_STATUS_WAIT_PROBE:
            printf("   wait probe");
            break;


        case CONN_STATUS_INITCONNECT :
            printf("   initconn");
            break;
        case CONN_STATUS_INCOMPLETE:
            printf("   incomplete");
            break;
        case CONN_STATUS_CONNECTED:
            printf("   connected");
            break;
        case CONN_STATUS_PROBE:
            printf("   probe");
            break;
        case CONN_STATUS_DEAD:
            printf("    dead");
            break;	                
        }
        printf("\t%8d\t%8d\t\n", conn->connect_count, queue_size(conn->queue) );

        conn = conn->next;
    }
    os_mutex_unlock(conn_mutex);



    for (es_info = services; es_info; es_info = es_info->next)
    {
        printf("%s, serice %d max fd=%d, queue size %d, are monitoring :", __FUNCTION__, es_info->sid, es_info->maxFd, queue_size(es_info->queue));
        for (int fd = es_info->maxFd; fd > 0; --fd)
        {
            if (FD_ISSET(fd, &es_info->rset))
                printf("%d, ", fd);
        }
        printf("\n");
    }

	printf("\nname/id \t\t mutex status\n");
    for (es_info = services; es_info; es_info = es_info->next)
        printf("%d(queue->mutex) \t %s\n", es_info->sid, TRYLOCK(es_info->queue->mutex));


    printf("dev_mutex \t\t %s\n", TRYLOCK(dev_mutex));
    printf("es_mutex \t\t %s\n", TRYLOCK(es_mutex));
    printf("conn_mutex \t\t %s\n", TRYLOCK(conn_mutex));

    printf("\n-------end-------- \n");

	return 0;
}

int cmd_display_queue(int argc, char * const argv[])
{
    ESINFO_T *es_info = NULL;
    char *buf;
    for (es_info = services; es_info; es_info = es_info->next)
    {
        printf("%s:serice %d max fd=%d, queue size %d, are monitoring :", __FUNCTION__, es_info->sid, es_info->maxFd, queue_size(es_info->queue));
        if((queue_size(es_info->queue)) > 0)
        {
            buf = queue_get(es_info->queue);
            if(buf != NULL)
                printf("%s---> memory address = 0x%x,  code = %d, sid = %d, rid = %d, length = %d, checksum = %d \n ",
                    __FUNCTION__, (unsigned int)buf, ((EVENT_HEADER_TYPE *)buf)->code, ((EVENT_HEADER_TYPE *)buf)->sid,
                    ((EVENT_HEADER_TYPE *)buf)->rid, ((EVENT_HEADER_TYPE *)buf)->length, ((EVENT_HEADER_TYPE *)buf)->checksum);
            buffer_release(buf);
        }
        printf("\n");
    }
    return 0;
}


