/**@file 
 * Copyright (C) 2013, Sinovision Tech Ltd.
 * All rights reserved.
 *
 * @brief   This file implements the event communication interface
 *    for inter-thread communication, use a local queue
 *    for inter-process communication, will use tcp scoket
 *
 * @author  
 * @date 2013-4-7
 *
 */
#include<stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <netinet/tcp.h>
#include <stdio.h>
#include <time.h>
#include <stdbool.h>
#include <fcntl.h>
#include <assert.h>
#include <signal.h>
#include "os_intf.h"
#include "ev_comm.h"
#include "logger.h"

#include <libxml/parser.h>
#include <libxml/tree.h>

extern const char *verInfo[];
extern DEVINFO_T *devices;			//gloable devices
extern os_mutex_t dev_mutex;		//devices protection mutex
int TestCount;

/** get ns since 1970-1-1 as 64 bit integer data
 */
uint64_t get_epoch_time_nano()
{
    struct timespec tm;
    clock_gettime(CLOCK_REALTIME, &tm);
    return (uint64_t)(tm.tv_sec) * 1e9 + tm.tv_nsec;
}

 
/** Set up a TCP/IP listen socket for future connections.
 * @param es_info current service specific info
 * @param port The requred port.
 * @param end the end of the actual port number allowed, =0 means no change from the requied port
 * @return The allocated port or -1 if no port available.
 */
int  tcp_listen(ESINFO_T* es_info, int port, int end)
{
    struct sockaddr_in address;
    int result;
    socklen_t count;
    int fd;

    // Create a TCP listen socket.
    fd = socket(AF_INET, SOCK_STREAM, 0);
    assert(fd >= 0 && "create tcp socket error");

	//  set the address structure 	
    memset(&address, 0, sizeof(address));
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = htonl(INADDR_ANY);

    // Set the reuse address socket option
    count = 1;
    setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &count, sizeof(count));

    // Wait forever to get a connection socket.
    for (count = 0; ; ++count) {
        address.sin_port = htons(port);         // Set the port.
        result = bind(fd, (struct sockaddr *) &address, sizeof(address));
        if(result<0)
        {
        	printf("bind result is %d port is %d\n",result,port);
        	perror("bind error");
        }
		assert(result >= 0 && "bind tcp socket error\n");
        if (result >= 0) {
            int arg;
            // Handle ephemeral ports.
            if (port == 0) {
                socklen_t size = sizeof(address);
                getsockname(fd, (struct sockaddr*) &address, &size);
                port = ntohs(address.sin_port);
            }
            arg = 1;
            //set the socket non blocking
            arg = ioctl(fd, FIONBIO, &arg);
            assert (arg != -1 && "can't set listen socket FIONBIO");
            // Listen for connections.
            listen(fd, 5);
			//register_fd(es_info,(SVCID)NULL, fd );
			create_connection(es_info,(SVCID)NULL, es_info->sid, fd);
			//printf("%s svc(%d) listen %d\n", __FUNCTION__, es_info->sid, port);
			es_info->listenFd = fd;
            break;
        } else if (end) {
            // Find the first open port.
            ++port;
            if (port > end) {
                port = -1;
                close (fd);
                break;
            }
        } else {//huyf this will be not run
        	printf("bind failure on TCP port %d, attempt %d: %s\n", port, count, strerror(errno));
            sleep(1);
        }
    }
    return port;
}


/** Accept a TCP/IP connection.
 * @param es_info current service info
 * @param fd file discriptor for listening socket
 * @return the new fd for the connection
 */
int tcp_accept(struct ESINFO *es_info, int fd)
{
    struct CONNECTION *conn;
    struct sockaddr_in address;
    socklen_t addrlen;
    int newFd = 0;
    int arg = 0;
    int flag = 0;
	
    addrlen = sizeof(address);
    newFd = accept(fd, (struct sockaddr *)&address, &addrlen);
    assert(newFd >= 0 && "Accept of connection failed");
    
    arg = 1;
    //set the socket to non block mode
    arg = ioctl(newFd, FIONBIO, &arg);
    assert (arg != -1 && "can't set connecting socket FIONBIO");
    // Turn off the Nagle algorithm.
    flag = 1;
    setsockopt(newFd, IPPROTO_TCP, TCP_NODELAY, &flag, sizeof(int));
    // Set keepalive on socket
    flag = 1;
    setsockopt(newFd, SOL_SOCKET, SO_KEEPALIVE, &flag, sizeof(int));

	//new connection
	if (newFd > 0) {
		printf("new connection accepted, fd=%d \n",newFd);
		conn = create_connection(es_info, (SVCID)NULL, es_info->sid, newFd);
		if (NULL ==  conn) {
			printf("%s create connection error\n", __FUNCTION__);
		} else {
			conn->conn_status = CONN_STATUS_ACCEPT;  /**huyf add new connect change it*/
			//conn->conn_status = CONN_STATUS_REACHABLE;
			conn->is_accept_conn = 1;
			start_expired_check_timer(conn);
		}
	}
	
    return newFd;
}


/** wakeup the select call in main thread
 * by sending a byte to a pipe which is registed to the select fd set
 * this is known as the self pipe trick
 * for windows, the same function can be achieved by create a UDP socket and close it in other thread
 * @param es_info current service specific info
 * @return pointer to the connection info
 */
void wakeup_select(ESINFO_T *es_info)
{
	ssize_t res;
	do {
		// Write one byte to pipe.
		res = write(es_info->pipe_fd[1], "x", 1);
		if(res == -1 && errno == SIGPIPE)
			printf(" %s,  broken pipe error: %s(errno: %d)\n", __FUNCTION__, strerror(errno), errno);
	} while (res < 0 && errno == EINTR);
}


/** send block of data by tcp socket
 * @param es_info current service specific info
 * @param to target service id
 * @param data pointer of the data block
 * @param size size of the data block
 * @return status of the send
 */
int tcp_send(ESINFO_T* es_info, SVCID to, char* data, size_t size)
{
	struct CONNECTION* conn;
    int fd = 0;

	assert(es_info != NULL && "es_info == NULL");
	
	//conn = find_connection(es_info, to);
	conn = find_connection_bysvc(es_info->sid, to);

	if (NULL == conn) {
		conn = create_connection(es_info, es_info->sid, to, 0);
		if (NULL == conn) {
			printf("%s create_connection error\n", __FUNCTION__);
			return PLATFORM_ERR_CREATE;
		} else {
			//connect
			establish_connection(conn);
		}
		
	}
	
	//check the queue number if to flush
	if(queue_size(conn->queue)>QUEUE_FLUSH_THRE)
	{
		log_msg(LOG_LEVEL_WARNING, "src sid is %d to sid is %d conn queue is flushed number is %d\n",es_info->sid,to,QUEUE_FLUSH_THRE+1);
		queue_flush(conn->queue);
	}

	// put the data to send queue and wake up the socket handler thread	
	queue_add(conn->queue, (void*)data);
#if 0
	printf("%s---> memory address = 0x%x, code = %d, sid = %d, rid = %d, length = %d, checksum = %d \n ",
				__FUNCTION__, (unsigned int)data, ((EVENT_HEADER_TYPE *)data)->code, ((EVENT_HEADER_TYPE *)data)->sid,
				((EVENT_HEADER_TYPE *)data)->rid, ((EVENT_HEADER_TYPE *)data)->length, ((EVENT_HEADER_TYPE *)data)->checksum);
#endif
	fd = conn->fd;

	/**huyf add new connect change it*/
#if 1
	if ((fd > 0) && 
     (CONN_STATUS_CONNECTED == conn->conn_status || CONN_STATUS_REACHABLE ==  conn->conn_status ||
      CONN_STATUS_WAIT_PROBE == conn->conn_status || CONN_STATUS_PROBE == conn->conn_status))
#else
	if ((fd > 0) &&
     (CONN_STATUS_CONNECTED == conn->conn_status || CONN_STATUS_REACHABLE ==  conn->conn_status /*||
      CONN_STATUS_WAIT_PROBE == conn->conn_status || CONN_STATUS_PROBE == conn->conn_status*/))
#endif
	{
		if (!FD_ISSET(fd, &es_info->wset)) {
			FD_SET(fd, &es_info->wset);
		}
		wakeup_select(es_info);
	}
	
    return 0;
}


/** write the data in the sending queue into the fd
 * @param es_info current service specific info
 * @param fd fd of the connection
 * @return status of the send
 */
int tcp_send_pending(ESINFO_T* es_info,int fd)
{
	struct CONNECTION* conn;
	char *buf;
	char *data;
	size_t size;
	ssize_t result;
	
	conn = get_connection(fd);
	if(conn == NULL)
		return 0;
	
	buf = queue_get(conn->queue);
	if(buf == NULL)
	{
		printf("%s---> queue_get is NULL \n ",	__FUNCTION__);
		FD_CLR(fd, &es_info->wset);
		return 0;
	}
#if 0
	printf("%s---> memory address = 0x%x,  code = %d, sid = %d, rid = %d, length = %d, checksum = %d \n ",
				__FUNCTION__, (unsigned int)buf, ((EVENT_HEADER_TYPE *)buf)->code, ((EVENT_HEADER_TYPE *)buf)->sid,
				((EVENT_HEADER_TYPE *)buf)->rid, ((EVENT_HEADER_TYPE *)buf)->length, ((EVENT_HEADER_TYPE *)buf)->checksum);
#endif
	data = buf+conn->sbytes;
	size = buffer_size(buf) - conn->sbytes;
	
	result = write(fd, data, size);
#if 0
	printf("%s-->write fd:%d  result is %d, bufer size is %d\n", __FUNCTION__, fd, result, size);
#endif
	conn->sbytes+=result;
	if (result < 0)
	{
		if(result == -1 && errno == SIGPIPE)
			printf(" %s, fd :%d  broken pipe error: %s(errno: %d)\n", __FUNCTION__, fd, strerror(errno), errno);
		conn->sbytes = 0;
		FD_CLR(fd, &es_info->wset);	
		buffer_release(buf);
		close_conn_by_fd(fd);
		//return -1;
		 return PLATFORM_ERR_WRITE;
	}else if(result >= size)
	{
	    //printf("%s write fd %d a event\n", __FUNCTION__, fd);
		// all data sent
		conn->sbytes = 0;
		//buffer_release(buf);
		EVENT_HEADER_TYPE *ev = (EVENT_HEADER_TYPE *)buf;
		ev->received = get_epoch_time_nano();
		log_event(buf);
		if(queue_size(conn->queue) == 0)
			FD_CLR(fd, &es_info->wset);		
	}else{
	    //printf("%s write fd %d return %d add event back to queue\n", __FUNCTION__, fd, result);
	    // if the write did not send all data, need to put the buffer back to the queue
		queue_add_head(conn->queue, (void*)buf);
    }

    return 0;
}


/** send the data to service in the same data chain
 * @param to_svc the destination service specific info
 * @param data pointer of the data block
 */
int send_in_process(ESINFO_T* to_svc, char* data)
{
	if((NULL != to_svc) && (NULL != to_svc->queue) &&
		(NULL != data)) {
		queue_add(to_svc->queue, (void*)data);
		os_sem_post(to_svc->sem);	
	}
	return 0;
}

/** send an event to a destinition device
 * this the interface of event comm lib, the prototype is defined in ecl.h
 * @param dev_id to target device name
 * @param event pointer of the event data block
 * @param size size of the data block
 */
int send_ev_todev_byid(int dev_id, char *event, size_t size)
{
	DEVINFO_T *dev_info;
	int fd = -1, len = 0;

	assert((NULL != event || size > 0) && " parameter event is error ");
	assert((dev_id <= SVC_ID_DEV_END || dev_id >= SVC_ID_DEV_BASE) && " invalid dev_id ");


	os_mutex_lock(dev_mutex);
	for (dev_info = devices; NULL != dev_info; dev_info = dev_info->next) {
		if ( dev_id == dev_info->dev_id ) {
			//This device is finded.
			fd = dev_info->fd;
			break;
		}
	}
	os_mutex_unlock(dev_mutex);
	
	if (fd < 0) {
		printf("%s: device (id = %d) is not find\n", __FUNCTION__, dev_id);
		buffer_release((char *)event);
		//return -1;
		 return PLATFORM_ERR_FIND;
	}

	os_mutex_lock(dev_info->wr_mutex);	
	
	len = write(fd, event, size);
	if(len == -1 && errno == SIGPIPE)
		printf(" %s, fd :%d  broken pipe error: %s(errno: %d)\n", __FUNCTION__, fd, strerror(errno), errno);

	os_mutex_unlock(dev_info->wr_mutex);

	//buffer_release((char *)event);
	log_event((void *)event);

	return len;
}



/** send an event to a destinition service
 * this the interface of event comm lib, the prototype is defined in ecl.h
 * @param to target service id
 * @param event pointer of the event data block
 * @param size size of the data block
 * @param not_log
 */
int send_event(SVCID to, EVENT_HEADER_TYPE *event, size_t size, int not_log)
{
    ESINFO_T *es_info = NULL;

	es_info = get_es_info();
	assert(es_info != NULL && "the event service info is invalid");


	
	ESINFO_T *to_svc =  find_service_inp(to);

	//to determine whether the target app is in process or not
	bool in_process = (to_svc != NULL)?true:false;

	EVENT_HEADER_TYPE * buf = (EVENT_HEADER_TYPE *)buffer_get(size);
	memset(buf, 0, size);
	memcpy(buf, event, size);

	// Get the event size.
	buf->length = size;
	buf->sid = es_info->sid;
	buf->rid = to;
	buf->not_log = not_log;
	
	// Calculate the checksum.
	buf->checksum = buf->length + buf->code + buf->sid + buf->rid;
	// Timestamp the event.
	buf->sent = get_epoch_time_nano();
	buf->complete = 0;
	buf->received = 0;
#if 0
	printf("%s---> memory address = 0x%x,  code = %d, sid = %d, rid = %d, length = %d, checksum = %d \n ",
				__FUNCTION__,(unsigned int)buf, buf->code, buf->sid,
				buf->rid, buf->length, buf->checksum);
#endif
	//send the event to device
	if (to > SVC_ID_DEV_BASE && to < SVC_ID_DEV_END) {
		return send_ev_todev_byid(to, (char*)buf, size);
	}
	
	// Send the event.
	if(in_process)
		return send_in_process(to_svc, (char*)buf);
	else
		return tcp_send(es_info, to, (char*)buf, size);
}

int send_event_from_tcp(SVCID from, SVCID to, EVENT_HEADER_TYPE *event, size_t size, int not_log)
{
    ESINFO_T *es_info = find_service_inp(from);
	if(es_info == NULL)
	{
		printf("service id %d not found \n", from);
		return 0;
	}

	EVENT_HEADER_TYPE * buf = (EVENT_HEADER_TYPE *)buffer_get(size);
	memset(buf,0,size);
	memcpy(buf, event, size);

	// Get the event size.
	buf->length = size;
	buf->sid = es_info->sid;
	buf->rid = to;
	buf->not_log = not_log;

	// Calculate the checksum.
	buf->checksum = buf->length + buf->code + buf->sid + buf->rid;
	// Timestamp the event.
	buf->sent = get_epoch_time_nano();
	buf->complete = 0;
	buf->received = 0;

	if (to > SVC_ID_DEV_BASE && to < SVC_ID_DEV_END) {
		return send_ev_todev_byid(to, (char*)buf, size);
	}
	return tcp_send(es_info, to, (char*)buf, size);
}


/** the loop of receiving data and send pending  data
 * @param arg ponter to current service specific info
 */
void* socket_handler(void * arg)
{
	ESINFO_T * es_info = (ESINFO_T*)arg;
	int flags;
    int fd;
	size_t size = 0;
	char* data = NULL;
	int count;
	char ch;
	int i;

	int res;

    /* Create self pipe to wakeup the select call*/
//    int res = pipe(es_info->pipe_fd);
//	assert(res != -1 && "pipe creation failed");

	//add the pipe fd to the rset fd
	FD_SET(es_info->pipe_fd[0], &es_info->rset);
	if(es_info->pipe_fd[0] > es_info->maxFd)
		es_info->maxFd = es_info->pipe_fd[0];
	
    /* Make read and write ends of pipe nonblocking */
    flags = fcntl(es_info->pipe_fd[0], F_GETFL);
    if(flags == -1)
    	printf("errno=%d\n", errno);
	assert(flags != -1 && "pipe fcntl-F_SETFL failed");
    flags |= O_NONBLOCK;                /* Make read end nonblocking */
    res = fcntl(es_info->pipe_fd[0], F_SETFL, flags);
    if(res == -1)
    {
    	perror("es_info->pipe_fd[0], F_SETFL, flags\n");
    }
	assert(res != -1 && "pipe fcntl-F_SETFL failed");

    flags = fcntl(es_info->pipe_fd[1], F_GETFL);
    if(flags == -1)
    {
    	perror("es_info->pipe_fd[1], F_GETFL\n");
    }
	assert(flags != -1 && "pipe fcntl-F_SETFL failed");
    flags |= O_NONBLOCK;                /* Make write end nonblocking */
    res = fcntl(es_info->pipe_fd[1], F_SETFL, flags);
	assert(res != -1 && "pipe fcntl-F_SETFL failed");

	SERVICE_TYPE *svc = lookup_service(es_info->sid);
	assert(svc != NULL && "cannot find the service info");

	int port = ntohs(svc->addr.sin_port);
    es_info->soc_tid = syscall(SYS_gettid); 
    tcp_listen(es_info, port,65000); //tcp listen

	for ( ;; ) {
		//update the  file descriptor sets
		int maxFd = es_info->maxFd;
		fd_set wset = es_info->wset;
		fd_set rset = es_info->rset;
		fd_set eset = es_info->wset;
		// Wait for a file descriptor
		int active = select(maxFd+1, &rset, &wset, &eset, NULL);
		if (active < 0) {
			if ( (errno == EINTR) || (errno == EBADF) ){
				// signal or bad discriptor happened
				continue;
			}
            log_msg(LOG_LEVEL_DEBUG,"select errror, service:%s maxFd:%d, rset:0x%08X wset:0x%08X\n",
						es_info->name, maxFd,
						*(unsigned int *)&rset, *(unsigned int *)&wset);
			
            log_msg(LOG_LEVEL_DEBUG, "select error: %s(errno: %d)\n",strerror(errno),errno);
		}
		// At least one file descriptor is active.
		for (fd = 0; active > 0 && fd <= maxFd; fd++) {
			
			// Check all active file descriptors.
			if (FD_ISSET(fd, &wset)) {
				
				// there is more data to write
				tcp_send_pending(es_info,fd);
				// TODO:  need to consider connection failed situation
			
			}
			if (FD_ISSET(fd, &rset)) {
				--active;
				
				if (fd == es_info->listenFd){ 
					// new connection request coming accept it and wait for next loop to process the new fd
					tcp_accept(es_info, fd);	
				}else if (fd == es_info->pipe_fd[0]) {
				    //self pipe data coming
					//printf("self pipe triggered \n");
					if (ioctl(fd, FIONREAD, &count) != -1) {
						for (i=0;i<count;i++) {
							read(fd,&ch,1);
						}
					}
				}else{
					data =  receive(fd,&size);
					if( size <=0 ){
						printf("%s read fd (%d) return %d to close connection\n", __FUNCTION__, fd, size);
						close_conn_by_fd(fd);
						continue;
					}
					//add event to queue
					if(data != NULL){
						//modify EV_ECL_CONNECT->fd to find the connection.
						EVENT_HEADER_TYPE *event = (EVENT_HEADER_TYPE *)data;
						if (EV_ECL_CONNECT == event->code) {
                          
							((EV_ECL_CONNECT_TYPE *)event)->fd = fd;

                            if (((EV_ECL_CONNECT_TYPE *)event)->type == CONN_TYPE_PROBE ||
                                ((EV_ECL_CONNECT_TYPE *)event)->type == CONN_TYPE_PROBE_RES) {
                                    process_conn_event((EV_ECL_CONNECT_TYPE *)event);
                                    continue;   
                            }
						} 
						queue_add(es_info->queue, (void*)data);
						os_sem_post(es_info->sem);
						
					} 
				}
			} //if (FD_ISSET(fd, &rset))
		}          
	}
}

/** receive event from a fd
 * @param fd file discriptor of a connection
 * @param size data size received, 
 * @return pointer of the received data, =0 means receiving still on going
 */
char* receive(int fd, size_t* size)
{
	ssize_t rsize = 0;
    size_t ssize = 0;
	char* buffer = NULL;
	char *data = NULL;
	*size = 0;	
	EVENT_HEADER_TYPE *header;
	struct CONNECTION* conn = get_connection(fd);
	if(conn == NULL)
		return NULL; // TODO: need to report an error here
	
	if(conn->rstate == R_IDLE){
		//in idle state and initialize the data reading
        ssize = sizeof(EVENT_HEADER_TYPE);  // The bytes needed for a header.
        conn->rbytes = 0;                     // The bytes have been read
        conn->rbuf = buffer_get(ssize);
		conn->rstate = R_HEADER;
	}
	else if(conn->rstate == R_HEADER){
		ssize = sizeof(EVENT_HEADER_TYPE) - conn->rbytes;
	}
	else{
		data = conn->rbuf;
        header = (EVENT_HEADER_TYPE*)data;
		ssize = header->length - conn->rbytes;

        if(header->length > buffer_size(conn->rbuf)){
            conn->rbuf = buffer_expand(conn->rbuf, header->length);
        }
	}
	
	buffer = conn->rbuf+conn->rbytes;

    rsize = read(fd, buffer, ssize);
    *size = rsize;
	if (rsize <= 0){
		// Return the closed/error status.		
		return NULL;
	}	
	conn->rbytes += rsize;
	if(rsize < ssize){
        return NULL;
	}
	else if(conn->rstate == R_HEADER){
		//swith the receive state

		data = conn->rbuf;
        header = (EVENT_HEADER_TYPE*)data;
					
		//verify the header checksum
		if(header->length + header->code + header->sid + header->rid != header->checksum){
			// the header checksum is mismatched
			printf("code = %d, sid = %d, rid = %d, length = %d, checksum = %d \n invalid event header, the checksum check failed \n",
					header->code, header->sid, header->rid, header->length, header->checksum);
			conn->rbytes = 0;
			buffer_release(conn->rbuf);
			conn->rstate = R_IDLE;
			*size = 0;
			return NULL;
		}
		if(header->length <= conn->rbytes){
			//only header exist for the event, no payload attached
			conn->rstate = R_IDLE;
			*size = conn->rbytes;
		}else{
			conn->rstate = R_PAYLOAD;
			return NULL;
		}
	}
	else{
		data = conn->rbuf;
		header = (EVENT_HEADER_TYPE*)data;
		//swith the receive state
		conn->rstate = R_IDLE;
		*size = conn->rbytes;
	}
	
	header = (EVENT_HEADER_TYPE*)data;
	return data;
}




/** send an event to a destinition service as another service
 * for monitor debug command only
 * @param to target service id
 * @param event pointer of the event data block
 * @param size size of the data block
 * @param not_log 
 */
int send_event_from(SVCID from, SVCID to, EVENT_HEADER_TYPE *event, size_t size, int not_log)
{
    ESINFO_T *es_info = find_service_inp(from);
	if(es_info == NULL)
	{
		printf("service id %d not found \n", from);
		return 0;
	}
	
	ESINFO_T *to_svc =  find_service_inp(to);

	//to determine whether the target app is in process or not
	bool in_process = (to_svc != NULL)?true:false;

	EVENT_HEADER_TYPE * buf = (EVENT_HEADER_TYPE *)buffer_get(size);
	memset(buf,0,size);
	memcpy(buf, event, size);

	// Get the event size.
	buf->length = size;
	buf->sid = es_info->sid;
	buf->rid = to;
	buf->not_log = not_log;
	
	// Calculate the checksum.
	buf->checksum = buf->length + buf->code + buf->sid + buf->rid;
	// Timestamp the event.
	buf->sent = get_epoch_time_nano();
	buf->complete = 0;
	buf->received = 0;
#if 0
	printf("%s---> memory address = 0x%x,  code = %d, sid = %d, rid = %d, length = %d, checksum = %d \n ",
				__FUNCTION__,(unsigned int)buf, buf->code, buf->sid,
				buf->rid, buf->length, buf->checksum);
#endif
	//send the event to device
	if (to > SVC_ID_DEV_BASE && to < SVC_ID_DEV_END) {
		return send_ev_todev_byid(to, (char*)buf, size);
	}

	// Send the event.
	if(in_process)
		return send_in_process(to_svc, (char*)buf);
	else
		return tcp_send(es_info, to, (char*)buf, size);
}


/** send an event to a destinition device
 * this the interface of event comm lib, the prototype is defined in ecl.h
 * @param dev_name to target device name
 * @param event pointer of the event data block
 * @param size size of the data block
 * @param not_log 
 */
int send_event_todev(char *dev_name, EVENT_HEADER_TYPE *event, size_t size, int not_log)
{
	DEVINFO_T *dev_info;
	int fd = -1, len = 0;

	assert((NULL != dev_name) && "device name is NULL");
	assert((NULL != event || size > 0) && " parameter event is error ");

	EVENT_HEADER_TYPE * buf = (EVENT_HEADER_TYPE *)buffer_get(size);
	memset(buf, 0, size);
	memcpy(buf, event, size);

	// Get the event size.
	buf->length = size;
	
	// Timestamp the event.
	buf->sent = get_epoch_time_nano();
	buf->complete = 0;
	buf->received = 0;
	buf->not_log = not_log;

	os_mutex_lock(dev_mutex);
	for (dev_info = devices; NULL != dev_info; dev_info = dev_info->next) {
		if (0 == strcmp(dev_info->dev_name, dev_name)) {
			//This device is finded.
			fd = dev_info->fd;
			buf->rid =dev_info->dev_id;
			if (NULL != dev_info->service) {
				buf->sid = dev_info->service->sid;
			}
			break;
		}
	}
	os_mutex_unlock(dev_mutex);

		
	// Calculate the checksum.
	buf->checksum = buf->length + buf->code + buf->sid + buf->rid;
	
	if (fd < 0) {
		printf("%s: device %s is not find\n", __FUNCTION__, dev_name);
		buffer_release((char *)buf);
		return PLATFORM_ERR_FIND;
	}

    os_mutex_lock(dev_info->wr_mutex);	
	
	len = write(fd, buf, size);
    
	if(len == -1 && errno == SIGPIPE)
		printf(" %s, fd :%d  broken pipe error: %s(errno: %d)\n", __FUNCTION__, fd, strerror(errno), errno);

    os_mutex_unlock(dev_info->wr_mutex);
    
	//buffer_release((char *)buf);
	log_event(buf);

	return len;
}



/**
  *open device and add file descriptor to service's rset
  *@param dev_name 
  *@param es_info   service 
  *@param dev_id
  *@return DEVINFO
 */
struct DEVINFO* open_device(char *dev_name, int dev_id, struct ESINFO *es_info)
{
	DEVINFO_T *dev_info;
	int fd;

	assert((NULL != dev_name) && "parameter dev_name is NULL");
	assert((NULL != es_info) && "parameter es_info is NULL");

	assert((dev_id <= SVC_ID_DEV_END || dev_id >= SVC_ID_DEV_BASE) && " invalid dev_id ");
	

	dev_info = malloc(sizeof(DEVINFO_T));
	if (NULL == dev_info) {
		printf("%s malloc DEVINFO_T error\n", __FUNCTION__);
		return NULL;
	}
	
	memset(dev_info, 0x0, sizeof(DEVINFO_T));

	snprintf(dev_info->dev_name, DEV_NAME_MAX, "%s", dev_name);

	dev_info->dev_id = dev_id;
	dev_info->service = es_info;
	os_recursive_mutex_init(dev_info->wr_mutex);

	fd = open(dev_name, O_RDWR | O_NONBLOCK);
	//printf("\n modify by wjw %s fd is %d\n",dev_name,fd);

	if (fd < 0) {
		printf("%s: open %s error\n", __FUNCTION__, dev_name);
		os_mutex_destroy(dev_info->wr_mutex);
		free(dev_info);
		return NULL;
	}
	
	dev_info->fd = fd;

	strcpy(dev_info->ver_info.build_time,"unknow");
	strcpy(dev_info->ver_info.svn_ver,"unknow");

	//register_fd(es_info, (SVCID)NULL, fd);
	create_connection(es_info, (SVCID)es_info->sid, (SVCID)dev_id, fd);

	return dev_info;

}

/**
  *find fd by dev id .
  *@param dev_id
  *@return the fd we find,-1 we don't find it;
 */
int find_fd_by_id(int dev_id)
{
	int ret=-1;
	DEVINFO_T *dev_info;
    
	assert((dev_id <= SVC_ID_DEV_END || dev_id >= SVC_ID_DEV_BASE) && " invalid parameter dev_id ");
    
	os_mutex_lock(dev_mutex);
	for (dev_info = devices; NULL != dev_info; dev_info = dev_info->next) {
		if (dev_id==dev_info->dev_id) {
			ret=dev_info->fd;
			break;
		}
	}
	os_mutex_unlock(dev_mutex);
    
	return ret;
}

int proc_dev_ioctl(int dev_id, int cmd, unsigned long arg)
{
    DEVINFO_T *dev_info = NULL;
    int fd = -1, ret = 0;
    
	assert((dev_id <= SVC_ID_DEV_END || dev_id >= SVC_ID_DEV_BASE) && " invalid parameter dev_id ");
    
	os_mutex_lock(dev_mutex);
	for (dev_info = devices; NULL != dev_info; dev_info = dev_info->next) {
		if (dev_id == dev_info->dev_id) {
			break;
		}
	}
	os_mutex_unlock(dev_mutex);

    if (NULL != dev_info) {
        fd = dev_info->fd;
        if (fd <= 0) {
        	printf("%s device(%d) not open\n", __FUNCTION__, dev_id);
           return PLATFORM_ERR_OPEN;
        }
        os_mutex_lock(dev_info->wr_mutex);
        ret = ioctl(fd, cmd, arg);
        os_mutex_unlock(dev_info->wr_mutex);
        
        return ret;
    } else {
    	printf("%s device(%d) not finded\n", __FUNCTION__, dev_id);
        return PLATFORM_ERR_FIND;
    }
}

/**
  *get device Name.
  *@param dev_id
  *@return the name of device we find, NULL we don't find it;
 */
char *get_devname_by_id(int dev_id)
{
	char *dev_name = NULL;
	DEVINFO_T *dev_info = NULL;
    
	assert((dev_id <= SVC_ID_DEV_END || dev_id >= SVC_ID_DEV_BASE) && " invalid parameter dev_id ");
    
	os_mutex_lock(dev_mutex);
	for (dev_info = devices; NULL != dev_info; dev_info = dev_info->next) {
		if (dev_id == dev_info->dev_id) {
			dev_name = dev_info->dev_name;
			break;
		}
	}
	os_mutex_unlock(dev_mutex);
	return dev_name;
}

/**
  *register device to service's devs
  *@param dev_name
  *@param dev_id
  *@return -1 is failed,0 is successful
 */
int register_device(char *dev_name, int dev_id)
{
	ESINFO_T *es_info;
	DEVINFO_T *dev_info;

	assert((NULL != dev_name) && "parameter dev_name is NULL");
	assert((dev_id <= SVC_ID_DEV_END || dev_id >= SVC_ID_DEV_BASE) && " invalid parameter dev_id ");

	es_info = get_es_info();
	assert((NULL != es_info) && "the service info is NULL");

	os_mutex_lock(dev_mutex);
	for (dev_info = devices; NULL != dev_info; dev_info = dev_info->next) {
		if (0 == strcmp(dev_name, dev_info->dev_name)) {
			// This device is already registered.
			printf("%s: device %s (id = %d) is already registered\n",
			__FUNCTION__, dev_name, dev_id);
			os_mutex_unlock(dev_mutex);
			return 0;
		}
	}
	os_mutex_unlock(dev_mutex);
	//add device 
	if (dev_info == NULL) {
		dev_info = open_device(dev_name, dev_id, es_info);
		if (NULL == dev_info) {
			printf("%s open device %s error\n", __FUNCTION__, dev_name);
			//return -1;
			 return PLATFORM_ERR_OPEN;
		}
		os_mutex_lock(dev_mutex);
		dev_info->next = devices;
		devices = dev_info;
		os_mutex_unlock(dev_mutex);
	}
	
	
	
	wakeup_select(es_info);

	return 0;

}

/**
  *remove device from service's devs
  *@param dev_name
  *@return -1 is failed,0 is successful
 */
//huyf will be remove this code 2014-10-17
int remove_device(char *dev_name)
{
	DEVINFO_T *pre_dev,*cur_dev;

	assert((NULL != dev_name) && "parameter dev_name is NULL");
	
	//have no device
	if (NULL == devices) {
		printf("%s: the system have no device \n", __FUNCTION__);
		//return -1;
		 return PLATFORM_ERR_DEFINE;
	}

	os_mutex_lock(dev_mutex);
	
	pre_dev = cur_dev = devices;
	while ((NULL != cur_dev) && 
		(0 != strcmp(dev_name, cur_dev->dev_name))) {
		pre_dev = cur_dev;
		cur_dev = cur_dev->next;
		
	}
		
	//find device 
	if ((NULL != cur_dev) && (0 == strcmp(dev_name, cur_dev->dev_name))) {

		if (NULL == cur_dev->service) {
			printf("%s device->service is NULL\n", __FUNCTION__);
			os_mutex_unlock(dev_mutex);
			return PLATFORM_ERR_EMPTY;
		}

		
		//remove_fd(cur_dev->service, cur_dev->fd);
		destory_conn_by_fd(cur_dev->fd);
		
		//remove from list devices
		if (pre_dev != cur_dev) {
			pre_dev->next = cur_dev->next;
		//is list head
		} else { 
			devices = cur_dev->next;
		}
		os_mutex_destroy(cur_dev->wr_mutex);
		free(cur_dev);
	//not find device
	} else {
		printf("%s: not find device %s \n", __FUNCTION__, dev_name);
		os_mutex_unlock(dev_mutex);
		return PLATFORM_ERR_FIND;
	}
	os_mutex_unlock(dev_mutex);

	return 0;

}


/**
  *remove device from service's devs
  *@param dev_name
  *@return -1 is failed,0 is successful
 */
int remove_device_byid(int dev_id)
{
	DEVINFO_T *pre_dev,*cur_dev;

	assert((dev_id <= SVC_ID_DEV_END || dev_id >= SVC_ID_DEV_BASE) && " invalid dev_id ");


	//have no device
	if (NULL == devices) {
		printf("%s: the system have no device \n", __FUNCTION__);
		//return -1;
		 return PLATFORM_ERR_DEFINE;
	}

	os_mutex_lock(dev_mutex);
	
	pre_dev = cur_dev = devices;
	while ((NULL != cur_dev) &&
		(dev_id != cur_dev->dev_id)) {
		pre_dev = cur_dev;
		cur_dev = cur_dev->next;
	}
		
	//find device 
	if ((NULL != cur_dev) && (dev_id == cur_dev->dev_id)) {

		if (NULL == cur_dev->service) {
			printf("%s device->service is NULL\n", __FUNCTION__);
			os_mutex_unlock(dev_mutex);
			return PLATFORM_ERR_EMPTY;
		}
		
		//remove_fd(cur_dev->service, cur_dev->fd);
		destory_conn_by_fd(cur_dev->fd);
		//remove from list devices
		if (pre_dev != cur_dev) {
			pre_dev->next = cur_dev->next;
		//is list head
		} else { 
			devices = cur_dev->next;
		}
		os_mutex_destroy(cur_dev->wr_mutex);
		free(cur_dev);
		
	//not find device
	} else {
		printf("%s: not find device id = %d \n", __FUNCTION__, dev_id);
		os_mutex_unlock(dev_mutex);
		return PLATFORM_ERR_FIND;
	}
	
	os_mutex_unlock(dev_mutex);

	return 0;
	
}

/**
  *remove all device from service's devs
  *@param dev_name
  *@return -1 is failed,0 is successful
 */
int remove_device_bysvc(struct ESINFO *es_info)
{
	DEVINFO_T *pre_dev,*cur_dev,*tmp_dev;

	assert((NULL != es_info) && "parameter es_info is NULL");


	//have no device
	if (NULL == devices) {
		//printf("%s: the system have no device \n", __FUNCTION__);
		//return -1;
		 return PLATFORM_ERR_DEFINE;
	}

	os_mutex_lock(dev_mutex);
	
	pre_dev = cur_dev = devices;
	while (NULL != cur_dev) {
		
		if ((NULL != cur_dev->service) && 
			(es_info->sid == cur_dev->service->sid)) {
			tmp_dev = cur_dev;
			
			//remove_fd(es_info, tmp_dev->fd);
			destory_conn_by_fd(tmp_dev->fd);
			//remove from list devices
			pre_dev->next = tmp_dev->next;
			cur_dev = tmp_dev->next;
			os_mutex_destroy(tmp_dev->wr_mutex);
			free(tmp_dev);
		} else {
			pre_dev = cur_dev;
			cur_dev = cur_dev->next;
		}
	}
		
	os_mutex_unlock(dev_mutex);

	return 0;
	
}



int cmd_send_event(int argc, char * const argv[])
{
	
	if ( (argc == 4) && (0 == strcmp(argv[0], "-h")) ){
		EVENT_HEADER_TYPE header;
		int from =strtol(argv[1],NULL,10);
		int to =strtol(argv[2],NULL,0);
		header.code =strtol(argv[3],NULL,10);
		return send_event_from((SVCID)from,(SVCID)to,&header, sizeof(EVENT_HEADER_TYPE), 0);

	} else if( argc >= 6){
		printf("this mode not supported now\n");
	} else {
		printf("%s: 3\n", __FUNCTION__);
		printf("Usage: \n");
		printf("send [mode] [from] [to] [code] [length] [data] \n");
		printf("mode : -h header only \n");
		printf("       -l header and body \n");	
		printf("e.g. send -h from to code \n");
		printf("     send -l from to code length word0 word1 ... \n");
	}
	return 0;
}


int cmd_event_test(int argc, char * const argv[])
{

	if ( argc == 4 ){
		//EVENT_HEADER_TYPE header;
		int i,step,j =0;
		char x[300]={0};
		float sendrate=0;
		TestCount =0;

		time_t starttime;
		time_t stoptime;


		int from =strtol(argv[0],NULL,10);
		int to =strtol(argv[1],NULL,0);
		int times = strtol(argv[2],NULL,0);
		int size = strtol(argv[3],NULL,0);


		char* data = (char*)malloc(size+sizeof(EV_EVENT_TEST_TYPE));
		memset(data+sizeof(EV_EVENT_TEST_TYPE), 0xA5, size);
		EV_EVENT_TEST_TYPE *event = (EV_EVENT_TEST_TYPE *)data;
		event->from =(SVCID)from;
		event->to = (SVCID)to;
		event->header.code = EV_EVENT_TEST;


		printf("from: %d to: %d times:%d\n",from,to,times);

		if(times>100)
			step = (int)(times/100);
		else
			step =1;

		starttime = time(NULL);
		for(i=1; i<=times; i++)
		{
			event->item = i;
			send_event_from((SVCID)from,(SVCID)to,(void*)event,sizeof(EV_EVENT_TEST_TYPE)+size,0);

			for(;;)
			{
				//printf("i:%d  TestCount:%d\n",i,TestCount );
				if (i==TestCount)
					break;
			}
			if(0 == (i%step))
			{
				    sprintf(&x[0],"%4d",j+1);
			        x[4]='%';
			        x[5]='[';
			        x[6+j]='=';
			        printf("\r%s>",x);
			        fflush(stdout);
			        j++;
			}

		}
		printf("\n");
		stoptime=time (NULL);
	    printf("\nEvent Test Informations: \n");
	    printf("\nfrom\tto\ttimes\tlength\t\tconsuming(s)\tsendrate(kB/s) \n");
	    sendrate=(sizeof(EV_EVENT_TEST_TYPE)+size)*times/(difftime(stoptime,starttime)*1024);
	    printf("%d\t%d\t%d\t%d\t\t%0.2f\t\t%0.2f\n",from,to,times,size,difftime(stoptime,starttime),sendrate);
		//header.code =strtol(argv[3],NULL,10);
		//return send_event_from((SVCID)from,(SVCID)to,&header, sizeof(EVENT_HEADER_TYPE), 0);
	    TestCount = 0;
	}else if( argc >= 6){
		printf("this mode not supported now\n");
	} else {
		printf("%s: 4\n", __FUNCTION__);
		printf("Usage: \n");
		printf("et [from] [to] [times] [length] \n");
		printf("e.g. et  from to code  times length \n");
		printf("FYI: the progress bar's value is between 1 and 199,\n");
		printf("     it is because of the type conversion,\n");
		printf("     so the times's value like multiple of 100,\n" );
		printf("     then the progress bar's value will be equal 100.\n");
	}
	return 0;
}


void process_event_test(EV_EVENT_TEST_TYPE *event)
{
	if(event->header.sid == event->from)
	{
		event->header.code = EV_EVENT_TEST;
		send_event_from(event->to,event->from,(void *)event,event->header.length,0);
		//printf("event->item:%d\n",event->item);
	}else{
		TestCount++;
		//printf("event->item:%d\n",event->item);
	}

}

void process_event_sv_request(EV_SV_REQUEST_STATUS_TYPE *event)
{
	EV_SV_RESPONSE_STATUS_TYPE ev;
	ev.header.code = EV_SV_RESPONSE_STATUS;
	send_event_from(event->header.rid, event->header.sid, (void *)&ev, sizeof(EV_SV_RESPONSE_STATUS_TYPE), 1);
}


void process_ver_event(EV_SS_DEV_REPORT_VER_TYPE *event)
{

	ESINFO_T *es_info;
	DEVINFO_T *dev_info;

	es_info = get_es_info();
	assert((NULL != es_info) && "the service info is NULL");

	os_mutex_lock(dev_mutex);
	for (dev_info = devices; NULL != dev_info; dev_info = dev_info->next) {
		if (dev_info->dev_id==event->header.sid) {
			// This device is already registered.
			memset(dev_info->ver_info.build_time,0,sizeof(dev_info->ver_info.build_time));
			memset(dev_info->ver_info.svn_ver,0,sizeof(dev_info->ver_info.svn_ver));
			memset(dev_info->ver_info.name,0,sizeof(dev_info->ver_info.name));
			strcpy(dev_info->ver_info.build_time,event->buildTime);
			strcpy(dev_info->ver_info.svn_ver,event->svnVer);
			strcpy(dev_info->ver_info.name,event->devName);
			//printf("%s(%s) : \n	%s\n	%s\n",dev_info->ver_info.name,dev_info->ver_info.name,dev_info->ver_info.build_time,dev_info->ver_info.svn_ver);
			os_mutex_unlock(dev_mutex);
			return ;
		}
	}
	os_mutex_unlock(dev_mutex);

}




