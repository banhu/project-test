/**@file 
 * Copyright (C) 2013, Sinovision Tech Ltd.
 * All rights reserved.
 *
 * @brief   This file defines the event communication interface
 *    for inter-thread communication, will use a queue directly
 *    for inter-process communication, will use tcp scoket
 *
 * @author  
 * @date 2013-4-7
 *
 */
#ifndef _EV_COMM_H_
#define _EV_COMM_H_

#include <stdio.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <assert.h>

#include "sys_topology.h"
#include "ev_service.h"
#include "queue.h"
#include "connect_manager.h"


struct ESINFO;


// Platform error code
enum PLATFORM_ERR_TYPE
{
    PLATFORM_ERR_CREATE = -11,     //create error
    PLATFORM_ERR_JOIN,             //pthread join error
    PLATFORM_ERR_CONNECT,          //connect error
    PLATFORM_ERR_GET,              //buffer_get error
    PLATFORM_ERR_SET,              //set error
    PLATFORM_ERR_WRITE,            //write error
    PLATFORM_ERR_FIND,             //not fine
    PLATFORM_ERR_OPEN,             //open error
    PLATFORM_ERR_EQUAL,            //check  if equal error
    PLATFORM_ERR_EMPTY,            //no data,is empty
    PLATFORM_ERR_DEFINE            //no define
};


/** Accept a TCP/IP connection.
 * @param es_info current service info
 * @param fd file discriptor for listening socket
 * @return the new fd for the connection
 */
int tcp_accept(struct ESINFO *es_info, int fd);


/** send block of data by tcp socket
 * @param es_info current service specific info
 * @param id target service id
 * @param data pointer of the data block
 * @param size size of the data block
 * @return status of the send
 */

int tcp_send(struct ESINFO *es_info, SVCID id, char* data, size_t size);

/** receive event from a fd
 * @param fd file discriptor of a connection
 * @param size data size received, =0 means receiving still on going
 * @return pointer of the received data
 */
char* receive(int fd, size_t* size);


/** Set up a TCP/IP listen socket for future connections.
 * @param es_info current service specific info
 * @param port The desired port.
 * @param end != 0 to allocate any port between port and end inclusive.
 * @return The allocated port or -1 if no port available.
 */
int tcp_listen(struct ESINFO* es_info, int port, int end);

/** the loop of receiving data and send pending  data
 * @param arg ponter to current service specific info
 */
void* socket_handler(void * arg);

/** get ns since 1970-1-1 as 64 bit integer data
 */
uint64_t get_epoch_time_nano();


/** get the connecetion info pointer
 * @param fd of the connection
 * @return pointer to the connection info
 */
void wakeup_select(struct ESINFO *es_info);


/** write the data in the sending queue into the fd
 * @param es_info current service specific info
 * @param fd fd of the connection
 * @return status of the send
 */
int tcp_send_pending(struct ESINFO* es_info,int fd);


/** send the data to service in the same data chain
 * @param to_svc the destination service specific info
 * @param data pointer of the data block
 */
int send_in_process(struct ESINFO* tes_info, char* data);

/**
  *open device and add file descriptor to service's rset
  *@param dev_name 
  *@param dev_id
  *@param es_info   service 
  *@return DEVINFO
 */
struct DEVINFO* open_device(char *dev_name, int dev_id, struct ESINFO *es_info);

/**
  *remove all device from service's devs
  *@param dev_name
  *@return -1 is failed,0 is successful
 */
int remove_device_bysvc(struct ESINFO *es_info);

/**
  *get device Name.
  *@param dev_id
  *@return the name of device we find, NULL we don't find it;
 */
char *get_devname_by_id(int dev_id);

/**
  *EV_EVENT_TEST .
 */
void process_event_test(EV_EVENT_TEST_TYPE *event);

/**
 * request servers status
 */
void process_event_sv_request(EV_SV_REQUEST_STATUS_TYPE *event);

void process_ver_event(EV_SS_DEV_REPORT_VER_TYPE *event);

#endif




