/**@file 
 * Copyright (C) 2013, Sinovision Tech Ltd.
 * All rights reserved.
 *
 * @brief   program version related functions 
 *
 * @author  
 * @date 2013-6-6
 *
 */
#include <stdio.h> 


extern const char *verInfo[];
extern const int verInfoSize;

int dump_ver(int argc, char * const argv[])
{
    int i = 0;
    while(i<verInfoSize){
        printf("%s \n", verInfo[i]);
        i++;
    }
    return 0;
}

