/**@file 
 * Copyright (C) 2013, Sinovision Tech Ltd.
 * All rights reserved.
 *
 * @brief   posix timer
 *
 * @author  
 * @date 2013-6-6
 *
 */
#include <stdio.h> 
#include <stdlib.h> 
#include <string.h>
#include <signal.h>
#include <time.h>
#include <errno.h>
#include   <unistd.h> //for sleep

#include "rbtree.h"
#include "sys_topology.h"
#include "buffer.h"
#include "monitor.h"
#include "timer.h"




#define MAX_INT					(65535)
#define TIMER_THREAD_PRIORITY 	(0)
#define	TIMER_THREAD_STACK		(1024 * 4)		


extern os_mutex_t es_mutex;             ///< The thread list protection mutex.
extern ESINFO_T *services; 
///static QUEUE 		*expire_timer_queue;  //remove, change to sigwaitinfo
//static os_sem_t 	queue_sem;                //remove for change to sigwaitinfo
static os_thread_t 	timer_thread_id; 
static int tm_pipe_fd[2];                   //pipe for signal
static int not_log_interval_ev = 1;          //log the interval event
int cmd_log_interval_ev()
{
	not_log_interval_ev = !not_log_interval_ev;
	printf("not_log_interval_ev:%d   0:log  1:not log\n",not_log_interval_ev);
	return 0;
}
/**
 *@bref write the signal pipe
 *@val   union sigval
 *@option write the &val.sival_ptr
 */
static void sigqueue_handler(union sigval val)
{
	if( write(tm_pipe_fd[1], (char*)&val.sival_ptr, sizeof(void*)) < 0)
		printf(" %s, errno =13 is broken pipe error: %s(errno: %d)\n", __FUNCTION__, strerror(errno), errno);
}

static int ec_init_timer(struct ev_timer_t *ev_timer, uint32_t tmo_ms, uint32_t option)
{
	struct sigevent   se;
	int ret = 0;
	memset(&se, 0, sizeof(struct sigevent));
	se.sigev_notify =  SIGEV_THREAD; //SIGEV_SIGNAL;
	se.sigev_value.sival_ptr = ev_timer;       //set the signal information
	se.sigev_notify_attributes = NULL;
	se.sigev_notify_function = sigqueue_handler;   //the notify_function, when timer expire create a thread and do it to write a pipe

	//create timer
	ret = timer_create(CLOCK_REALTIME, &se, &(ev_timer->timer));
	if (ret < 0) {
		printf("%s timer_create happen error(%d)\n", __FUNCTION__, ret);
		return PLATFORM_ERR_CREATE;
	}
	return 0;
}
static int ec_set_timer(struct ev_timer_t *ev_timer, uint32_t tmo_ms, uint32_t option)
{
	struct itimerspec  ts, ots;
	int ret, sec, nsec;

	memset(&ts, 0, sizeof(struct itimerspec));
	memset(&ots, 0, sizeof(struct itimerspec));

	sec = tmo_ms / 1000;
	nsec = (tmo_ms % 1000) * 1000 * 1000;


	ts.it_value.tv_sec	= sec;
	ts.it_value.tv_nsec = nsec;

	switch (option) {
		case TIMER_OPT_INTERVAL:
		case TIMER_OPT_INTERVAL_NO_LOG:
			ts.it_interval.tv_sec = sec;
			ts.it_interval.tv_nsec = nsec;
			break;
		case TIMER_OPT_ONCE:
		case TIMER_OPT_ONCE_NO_LOG:
		default:
			ts.it_interval.tv_sec = 0;
			ts.it_interval.tv_nsec = 0;
			break;
		//default:
			//assert(0 && "parameter option is unsupport \n");
		//	break;

	}
	//enable timer
	ret = timer_settime(ev_timer->timer, 0, &ts, &ots);
	if (ret < 0) {
		printf("%s timer_settime happen error(%d)\n", __FUNCTION__, ret);
		timer_delete(ev_timer->timer);
		return PLATFORM_ERR_SET;
	}
	return 0;
}


static int init_timer_event(struct ev_timer_t *ev_timer, void *event, uint32_t ev_size)
{
	EVENT_HEADER_TYPE *new_event = NULL;
	if (NULL != event && ev_size > 0) {

		new_event = (EVENT_HEADER_TYPE *)buffer_get(ev_size);
		if (NULL == new_event) {
			printf("%s buffer_get(%d) is NULL \n", __FUNCTION__, ev_size);
			return PLATFORM_ERR_GET;
		}

		memset(new_event, 0, ev_size);
		memcpy(new_event, event, ev_size);

		new_event->length = ev_size;
		new_event->sid = ev_timer->es_info->sid;
		new_event->rid = ev_timer->es_info->sid;

		// Calculate the checksum.
		new_event->checksum = new_event->length + new_event->code + new_event->sid + new_event->rid;

		/*add code  2017-5-3*/
		if(TIMER_OPT_ONCE_NO_LOG == ev_timer->option || TIMER_OPT_INTERVAL_NO_LOG == ev_timer->option)
			new_event->not_log = 1;
		else
			new_event->not_log = 0;


		ev_timer->ev_code = new_event->code;
		if (NULL != ev_timer->event) {
			buffer_release(ev_timer->event);
			ev_timer->event = NULL;
		}
		ev_timer->event = new_event;
	}
	return 0;
}
/*
static EVENT_HEADER_TYPE *pack_event_code(ESINFO_T *es_info, uint32_t code)
{
	EVENT_HEADER_TYPE *new_event = NULL;

	new_event = (EVENT_HEADER_TYPE *)buffer_get(sizeof(EVENT_HEADER_TYPE));
	if (NULL == new_event) {
		 return NULL;
	}

	memset(new_event, 0, sizeof(EVENT_HEADER_TYPE));
	new_event->length = sizeof(EVENT_HEADER_TYPE);
	new_event->sid = es_info->sid;
	new_event->rid = es_info->sid;
	new_event->not_log = 0;
	new_event->code = code;

	// Calculate the checksum.
	new_event->checksum = new_event->length + new_event->code + new_event->sid + new_event->rid;
	// Timestamp the event.
	new_event->sent = get_epoch_time_nano();
	new_event->complete = 0;
	new_event->received = 0;
	return new_event;
}*/
/**
*@bref start a timer,and expired send evnet
*@event timer respond when timer expired
*@size event size
*@tmo_ms timer expiration time
*@option timer option
*
*@return NULL is failed
*/
struct ev_timer_t *event_timer_start(ESINFO_T *es_info_p, void *event, uint32_t ev_size, uint32_t tmo_ms, uint32_t option)
{
	struct ev_timer_t *ev_timer;
	ESINFO_T *es_info;
	int ret = 0;

	if (NULL == es_info_p) {
		es_info = get_es_info();
	} else {
		es_info = es_info_p;
	}
	assert((NULL != es_info) && " get_es_info reurn NULL ");


	ev_timer = (struct ev_timer_t *)buffer_get(sizeof(struct ev_timer_t));
	assert((NULL != ev_timer) && " call buffer_get() reurn NULL \n");
	memset(ev_timer, 0, sizeof(struct ev_timer_t));
	
	ev_timer->es_info = es_info;
	ev_timer->sid = es_info->sid;
	ev_timer->option = option;
	ev_timer->interval_time = tmo_ms;
	if (NULL != event && ev_size > 0)
	{
		ret = init_timer_event(ev_timer, event, ev_size);
		if (ret < 0)
		{
			timer_delete(ev_timer->timer);
			buffer_release((void *)ev_timer);
			ev_timer = NULL;
			return NULL;
		}
	}else{
		ev_timer->event = NULL;
	}

	ret = ec_init_timer(ev_timer, tmo_ms, option);
	if(ret < 0 )
	{
		if(NULL != ev_timer->event)
			buffer_release((void *)ev_timer->event);
		buffer_release((void *)ev_timer);
		ev_timer = NULL;
		return NULL;
	}
	if(tmo_ms >0)
	{
		ret = ec_set_timer(ev_timer, tmo_ms, option);
		if(ret < 0 )
		{
			if(NULL != ev_timer->event)
				buffer_release((void *)ev_timer->event);
			buffer_release((void *)ev_timer);
			ev_timer = NULL;
			return NULL;
		}
	}
	os_recursive_mutex_init(ev_timer->timer_mutex);
	
	return ev_timer;
}

/**
*@bref modify a timer,and expired send evnet
*@ev_timer 
*@event timer respond when timer expired
*@size event size
*@tmo_ms timer expiration time
*@option timer option
*
*@return  zero is successful,other is failed
*/
int event_timer_mod(struct ev_timer_t *ev_timer, void *event, uint32_t ev_size, uint32_t tmo_ms, uint32_t option)
{
	ESINFO_T *es_info;
	int ret = 0;

	assert((NULL != ev_timer) && "inval parameter event = NULL ");
	es_info = ev_timer->es_info;
	assert((NULL != es_info) && " get_es_info reurn NULL ");

	os_mutex_lock(ev_timer->timer_mutex);
	
	ev_timer->option = option;
	ev_timer->interval_time = tmo_ms;
	ev_timer->es_info = es_info;
	ev_timer->sid = es_info->sid;

	if (NULL != event && ev_size > 0)
	{
		ret = init_timer_event(ev_timer, event, ev_size);
		if (ret < 0)
		{
			os_mutex_unlock(ev_timer->timer_mutex);
			return ret;
		}
	}

	ret = ec_set_timer(ev_timer, tmo_ms, option);
	if(ret < 0 )
	{
		os_mutex_unlock(ev_timer->timer_mutex);
		return ret;
	}

	os_mutex_unlock(ev_timer->timer_mutex);
	
	return 0;
}

/**@bref stop and destroy timer*/
int event_timer_stop(struct ev_timer_t *ev_timer)
{
	assert((NULL != ev_timer) && "inval parameter event = NULL ");
	os_mutex_lock(ev_timer->timer_mutex);
	ev_timer->interval_time = 0;
	timer_delete(ev_timer->timer);
	if (NULL != ev_timer->event) {
		buffer_release((void *)ev_timer->event);
		ev_timer->event = NULL;
	}
	os_mutex_unlock(ev_timer->timer_mutex);
	os_mutex_destroy(ev_timer->timer_mutex);

	buffer_release((void *)ev_timer);
	ev_timer = NULL;
	
	return 0;
}

/**
*@bref start a timer
*@code timer respond event code when timer expired
*@tmo_ms timer expiration time
*@option timer option
*
*@return zero is successful,other is failed
*/
int ec_timer_start(uint32_t code, uint32_t tmo_ms, uint32_t option)
{
	ESINFO_T *es_info;
	RB_NODE_T *result = NULL;
	assert((tmo_ms > 0) && "inval parameter tmo_ms <= 0");
	es_info = get_es_info();
	assert((NULL != es_info) && " get_es_info reurn NULL ");
	EVENT_HEADER_TYPE event;
	event.code = code;

	result = rbtree_find(&(es_info->timer_tree), (void *)code);
	if(NULL != result)	{
		event_timer_mod((struct ev_timer_t *)result->item, (void *)&event, sizeof(EVENT_HEADER_TYPE), tmo_ms, option);
	}else{
		struct ev_timer_t *ev_timer = event_timer_start(NULL, (void *)&event, sizeof(EVENT_HEADER_TYPE), tmo_ms, option);
		//add to service timer tree
		if(NULL != ev_timer)
			rbtree_insert(&(es_info->timer_tree), (void *)ev_timer->ev_code, (void *)ev_timer);
		else
			return PLATFORM_ERR_CREATE;
	}
	return 0;
}



/**
*@bref stop a timer
*@ev_code  event code which timer respond to service
*
*@return zero is successful,other is failed
*/
int ex_timer_stop(uint32_t ev_code)
{
	RB_NODE_T *result = NULL;
	ESINFO_T *es_info;
	struct ev_timer_t *tmp_timer;

	es_info = get_es_info();
	assert((NULL != es_info) && " get_es_info reurn NULL \n");

	//fist timer
	result = rbtree_find(&(es_info->timer_tree), (void *)ev_code);

	if (NULL != result) {
		tmp_timer = (struct ev_timer_t *)result->item;
		if ((NULL != tmp_timer) && (tmp_timer->ev_code == ev_code) && (tmp_timer->es_info== es_info)) {
			os_mutex_lock(tmp_timer->timer_mutex);
			if (NULL != tmp_timer->event) {
				buffer_release((void *)tmp_timer->event);
				tmp_timer->event = NULL;
			}
			os_mutex_unlock(tmp_timer->timer_mutex);
			event_timer_mod(tmp_timer, NULL, 0, 0, 0);
		} else {
			printf("%s timer is finded, but timer id is not equal\n", __FUNCTION__);	
			return PLATFORM_ERR_EQUAL;
		}
	} else {
		printf("%s timer is not finded\n", __FUNCTION__);
		return PLATFORM_ERR_FIND;
	}
	
	return 0;
}

/**
*@bref get a timer's status
*@code timer respond event code when timer expired
*
*@return TIMER_STATUS
*/
int ec_timer_status(uint32_t code)
{
	RB_NODE_T *result = NULL;
	ESINFO_T *es_info;
	struct ev_timer_t *tmp_timer;
	struct itimerspec curts;


	es_info = get_es_info();
	assert((NULL != es_info) && " get_es_info reurn NULL \n");


	//fist timer
	result = rbtree_find(&(es_info->timer_tree), (void *)code);
	if (NULL != result) {
		tmp_timer = (struct ev_timer_t *)result->item;
		if ((NULL != tmp_timer) && 
			(tmp_timer->ev_code == code) &&
			(tmp_timer->es_info->sid == es_info->sid)) {
			
				timer_gettime(tmp_timer->timer, &curts);
				
	        	if ((0 == curts.it_interval.tv_sec) && 
					(0 == curts.it_interval.tv_nsec) &&
					(0 == curts.it_value.tv_sec) && 
					(0 == curts.it_value.tv_nsec)) {
					return TIMER_STATUS_EXPIRED;
				} else {
					return TIMER_STATUS_ACTIVE;
				}
					
			
		} else {
			printf("%s timer is finded, but timer id is not equal\n", __FUNCTION__);	
			return TIMER_STATUS_NONEXITENT;
		}
	} else {
		return TIMER_STATUS_NONEXITENT;
	}

	return TIMER_STATUS_NONEXITENT;
}

/***/
static void *timer_thread_entry(void *arg)
{
	struct ev_timer_t *ev_timer;
	EVENT_HEADER_TYPE *event = NULL;
	int  size = 0;
	int  status = 0;
	 
	while (1){

        status = read(tm_pipe_fd[0], (char*)&ev_timer, sizeof(void*));
        if (status >0 ) {
			//ev_timer = (struct ev_timer_t *)queue_get(expire_timer_queue);
			if (NULL == ev_timer) {        //check if the signal information is NULL
				printf("%s ev_timer_t is NULL \n", __FUNCTION__);
				continue;
			}
			
			os_mutex_lock(ev_timer->timer_mutex);

			//get service info by id
			ev_timer->es_info = find_service_inp(ev_timer->sid);
			if (NULL == ev_timer->es_info) {
				printf("%s ev_timer_t->es_info is NULL \n", __FUNCTION__);
				os_mutex_unlock(ev_timer->timer_mutex);
				continue;
			}
			if (NULL != ev_timer->event) {
				event = (EVENT_HEADER_TYPE *)ev_timer->event;
				// Timestamp the event.
				event->sent = get_epoch_time_nano();
				event->complete = 0;
				event->received = 0;	
				
			} else {
				if (TIMER_OPT_INTERVAL == ev_timer->option || TIMER_OPT_INTERVAL_NO_LOG == ev_timer->option){
					size = sizeof (EVENT_HEADER_TYPE);
					event = (EVENT_HEADER_TYPE *)buffer_get(size);
					if (NULL == event) {
						printf("%s buffer_get(EVENT_HEADER_TYPE) is NULL \n", __FUNCTION__);
						os_mutex_unlock(ev_timer->timer_mutex);
						continue;
					}
					memset(event, 0, size);
					
					event->code = ev_timer->ev_code;
					event->length = size;
					event->sid = ev_timer->es_info->sid;
					event->rid = ev_timer->es_info->sid;
					if(not_log_interval_ev || TIMER_OPT_INTERVAL_NO_LOG == ev_timer->option || TIMER_OPT_ONCE_NO_LOG == ev_timer->option)
						event->not_log = 1;
					else
						event->not_log = 0;
					
					// Calculate the checksum.
					event->checksum = event->length + event->code + event->sid + event->rid;
					// Timestamp the event.
					event->sent = get_epoch_time_nano();	
					event->complete = 0;
					event->received = 0;
				} else {
					printf("%s event is NULL\n", __FUNCTION__);
					os_mutex_unlock(ev_timer->timer_mutex);
					continue;
				}
			} 
			
			if (ev_timer->interval_time <= 0) {
				printf("%s timer is stoped\n", __FUNCTION__);
				if (NULL != ev_timer->event) {
					buffer_release(ev_timer->event);
					ev_timer->event = NULL;
				}
				os_mutex_unlock(ev_timer->timer_mutex);
				continue;
			}
			ev_timer->event = NULL;
			send_in_process(ev_timer->es_info, (char *)event);
			os_mutex_unlock(ev_timer->timer_mutex);
		}
	}
	
	return NULL;
}


/** init the timer
 * this should be called after all service created and started
 */
void timer_init(void)
{
	signal(SIGPIPE, SIG_IGN);
    int res = pipe(tm_pipe_fd);
    assert(res != -1 && "pipe creation failed\n");

	os_thread_create(0,
                     &timer_thread_id,
                     TIMER_THREAD_PRIORITY,
                     TIMER_THREAD_STACK,
                     timer_thread_entry,
                     NULL,
                     0);
}

int join_timer_thread(void)
{
    int ret;
    void *status = NULL;
    ret = os_thread_join(timer_thread_id,status);
    if(ret == 0){
        printf("pthread_join Error, code: %d\n", ret);
        //return -1;
        return PLATFORM_ERR_JOIN;
    }
    return 0;
}

/**
* destroy service's all timer
*/
void destroy_svc_timer(ESINFO_T *es_info)
{
	struct ev_timer_t *tmp_timer;
	RB_NODE_T *result = NULL;

	assert((NULL != es_info) && " parmeter es_info is NULL \n");

  	//delete timer
	result = rbtree_first(&(es_info->timer_tree));
	while (NULL != result) {
		
		tmp_timer = (struct ev_timer_t *)result->item;
		if (NULL != tmp_timer) {
			timer_delete(tmp_timer->timer);
			if (NULL != tmp_timer->event) {
				buffer_release((void *)tmp_timer->event);
				tmp_timer->event = NULL;
			}
			os_mutex_destroy(tmp_timer->timer_mutex);
			buffer_release((void *)tmp_timer);
			tmp_timer = NULL;
		} 
		
		rbtree_remove(&(es_info->timer_tree), result);
		
		//next timer
		result = rbtree_next(&(es_info->timer_tree), result);
	}
}

/**
* destroy all timer
*/
void timer_destroy(void)
{
	struct ev_timer_t *tmp_timer;
	RB_NODE_T *result = NULL;
	ESINFO_T *cur_es;


	os_mutex_lock(es_mutex);
    
    for (cur_es = services; NULL != cur_es; cur_es = cur_es->next) {
      	//delete timer
		result = rbtree_first(&(cur_es->timer_tree));
		while (NULL != result) {
			
			tmp_timer = (struct ev_timer_t *)result->item;
			//tmp_timer->interval_time = 0; huyf change for cppcheck error
			if (NULL != tmp_timer) {
				tmp_timer->interval_time = 0;
				timer_delete(tmp_timer->timer);
				if (NULL != tmp_timer->event) {
					buffer_release((void *)tmp_timer->event);
					tmp_timer->event = NULL;
				}
				os_mutex_destroy(tmp_timer->timer_mutex);
				buffer_release((void *)tmp_timer);
			} 
			
			rbtree_remove(&(cur_es->timer_tree), result);
			
			//next timer
			result = rbtree_next(&(cur_es->timer_tree), result);
		}
    }
	os_mutex_unlock(es_mutex);
}


#include "connect_manager.h"
extern struct CONNECTION *connections;
extern os_mutex_t conn_mutex;		//connection protection mutex

int cmd_timer(int argc, char * const argv[])
{
	struct ev_timer_t *tmp_timer;
	RB_NODE_T *result = NULL;
	ESINFO_T *cur_es;


	printf("svc_id	event_code	type    interval(ms)   overrun\n");
		
	os_mutex_lock(es_mutex);
    for (cur_es = services; NULL != cur_es; cur_es = cur_es->next) {
      	//delete timer
		result = rbtree_first(&(cur_es->timer_tree));
		while (NULL != result) {
			tmp_timer = (struct ev_timer_t *)result->item;
			if (NULL != tmp_timer) {
				printf("%d	0x%6x    %8s	    %d          %d\n",
				tmp_timer->es_info->sid,
				tmp_timer->ev_code, 
				tmp_timer->option == TIMER_OPT_ONCE ? "once" : "periodical",
				tmp_timer->interval_time,
				timer_getoverrun(tmp_timer->timer));
			} 
			
			
			//next timer
			result = rbtree_next(&(cur_es->timer_tree), result);
		}
    }
	os_mutex_unlock(es_mutex);

    os_mutex_lock(conn_mutex);
    struct CONNECTION *conn = connections;
    while (NULL != conn) {
			tmp_timer = conn->ev_timer;
			if (NULL != tmp_timer) {
                if(0 != tmp_timer->interval_time ){
    				printf("%d	0x%6x    %8s	    %d          %d\n",
    				tmp_timer->es_info->sid,
    				tmp_timer->ev_code, 
    				tmp_timer->option == TIMER_OPT_ONCE ? "once" : "periodical",
    				tmp_timer->interval_time,
    				timer_getoverrun(tmp_timer->timer));
                }
			} 
        conn = conn->next;
    }
    os_mutex_unlock(conn_mutex);


	return 0;
}





