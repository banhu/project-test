/**@file
 * Copyright (C) 2013, Sinovision Tech Ltd.
 * All rights reserved.
 *
 * @brief   This file implement the interface to read black tree operation
 *         the tree reused BSD header file
 *
 * @author  
 * @date 2013-3-30
 *
 */
#include <stdio.h>
#include <malloc.h>
#include <string.h>
#include <assert.h>

#include"rbtree.h"
#include"buffer.h"



/**compare function of the events
 */
static int ev_compare(struct TREE_NODE *a, struct TREE_NODE *b)
{
	assert(a->key_type == b->key_type && "comparing rb tree node with different type");

	if(a->key_type == KEY_INT){
		return a->key-b->key;
	}else{
	    return strcmp((char *)a->key, (char *)b->key);
	}
}

/**the marco represents all the code related with the tree
 */
RB_GENERATE(TREE_HEAD, TREE_NODE, entry, ev_compare);

/**initialize the rb tree
 */
void rbtree_init(RB_TREE_T* tree, int key_type)
{
	RB_INIT(&(tree->head));
	tree->key_type = key_type;
}

/**insert a node to the tree
 */
RB_NODE_T *rbtree_insert(RB_TREE_T* tree, void* key, void* item)
{
    RB_NODE_T *pnode = (RB_NODE_T*)buffer_get(sizeof(RB_NODE_T));
	if(pnode == NULL) // need to report error?
		return NULL;
	//what if the key is duplicated with a existing one?
	
	pnode->key = key;
	pnode->item = item;
	pnode->key_type = tree->key_type;
	return RB_INSERT(TREE_HEAD,&(tree->head),pnode);
}

/**remove a node from the tree
 */
void rbtree_remove(RB_TREE_T* tree, RB_NODE_T* n)
{
	RB_REMOVE(TREE_HEAD,&(tree->head),n);
    buffer_release((char*)n);
}

/**search the tree with provided tree
 */
RB_NODE_T *rbtree_find(RB_TREE_T* tree, void* key)
{
    RB_NODE_T node;
	node.key = key;
	node.key_type = tree->key_type;
	return RB_FIND(TREE_HEAD, &(tree->head), &node );
}

/**get the first node  of the tree
 */
RB_NODE_T *rbtree_first(RB_TREE_T* tree)
{
	return RB_MIN(TREE_HEAD, &(tree->head)); 
}

/**get the next  node  of the tree
 */
RB_NODE_T *rbtree_next(RB_TREE_T* tree, RB_NODE_T *node)
{
	return RB_NEXT(TREE_HEAD, &(tree->head), node);
}



