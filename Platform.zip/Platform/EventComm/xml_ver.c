/**@file 
 * Copyright (C) 2013, Sinovision Tech Ltd.
 * All rights reserved.
 *
 * @brief   This file implements the event communication interface
 *    for inter-thread communication, use a local queue
 *    for inter-process communication, will use tcp scoket
 *
 * @author  
 * @date 2013-4-7
 *
 */
#include<stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <netinet/tcp.h>
#include <stdio.h>
#include <time.h>
#include <stdbool.h>
#include <fcntl.h>
#include <assert.h>
#include "ev_comm.h"
#include "os_intf.h"
#include "logger.h"

#include <libxml/parser.h>
#include <libxml/tree.h>

extern const char *verInfo[];
extern DEVINFO_T *devices;			//gloable devices
extern os_mutex_t dev_mutex;		//devices protection mutex

static EV_SS_FPGA_REPORT_VER_TYPE *pFpgaVer = NULL;

extern char* get_process_name();
extern char* get_service_name(SVCID id);

void set_fpga_ver(EV_SS_FPGA_REPORT_VER_TYPE *ev)
{
	int len = sizeof(EV_SS_FPGA_REPORT_VER_TYPE);
	if(ev == NULL)
	{
		return;
	}
	pFpgaVer = (EV_SS_FPGA_REPORT_VER_TYPE *)buffer_get(len);
	memcpy(pFpgaVer,ev,len);
}

xmlDocPtr gen_xml_ver()
{
    xmlDocPtr doc = xmlNewDoc(BAD_CAST "1.0");

    char *index = NULL;
    int i=0;
    char svn[32];
    char time[64];
    char dri_name[64];
    //char fpga_name[32];
	ESINFO_T *es_info;
	DEVINFO_T *dev_info;
	xmlNodePtr node=NULL;
	memset(svn,0,sizeof(svn));
	memset(time,0,sizeof(time));

	es_info = get_es_info();
	assert((NULL != es_info) && "the service info is NULL");
	xmlNodePtr root_node = xmlNewNode(NULL,BAD_CAST "Component");
    xmlDocSetRootElement(doc,root_node);

    index = (char *)strstr(verInfo[6],"Revision");
    if(index!=NULL)
    {
		index=index+strlen("Revision: ");
		for(i=0;(*(index+i)!='\n')&&(i<32);i++);
		strncpy(svn,index,i);
		//printf("i=%d\n",i);

    }
    strcpy(time,verInfo[4]+strlen("##Version:  "));
    strcpy(svn,verInfo[5]+strlen("SVN Revision: "));
    xmlNewTextChild(root_node, NULL, BAD_CAST "Name", BAD_CAST get_process_name());
	xmlNewTextChild(root_node, NULL, BAD_CAST "ServiceName", BAD_CAST get_service_name( es_info->sid ));
    xmlNewTextChild(root_node, NULL, BAD_CAST "BuildTime", BAD_CAST time);
    xmlNewTextChild(root_node, NULL, BAD_CAST "SvnVersion", BAD_CAST svn);

	os_mutex_lock(dev_mutex);
	for (dev_info = devices; NULL != dev_info; dev_info = dev_info->next) {
		memset(dri_name,0,sizeof(dri_name));
		strcpy(dri_name,&(dev_info->dev_name[1]));
		dri_name[3]='_';
		node = xmlNewNode(NULL, BAD_CAST "SubComponent");
		xmlNewTextChild(node, NULL, BAD_CAST "Name", BAD_CAST dri_name);
		xmlNewTextChild(node, NULL, BAD_CAST "BuildTime", BAD_CAST (dev_info->ver_info.build_time+strlen("##Version:  ")));
		xmlNewTextChild(node, NULL, BAD_CAST "SvnVersion", BAD_CAST (dev_info->ver_info.svn_ver+strlen("SVN Revision: ")));
		xmlAddChild(root_node,node);

	}
	os_mutex_unlock(dev_mutex);

	if(pFpgaVer != NULL)
	{
		node = xmlNewNode(NULL, BAD_CAST "SubComponent");
		xmlNewTextChild(node, NULL, BAD_CAST "Name", BAD_CAST (pFpgaVer->fpgaName));
		xmlNewTextChild(node, NULL, BAD_CAST "BuildTime", BAD_CAST (pFpgaVer->buildTime));
		xmlNewTextChild(node, NULL, BAD_CAST "SvnVersion", BAD_CAST (pFpgaVer->svnVer));
		xmlAddChild(root_node,node);
	}

//    int nRel = xmlSaveFormatFileEnc("CreatedXml.xml", doc, "UTF-8", 1);
//    if (nRel != -1)
//    {
//       printf("%d byte was written to xml file \n", nRel);
//    }
    return doc;

}

int send_ver_to_ctl(SVCID to)
{

#if 0
	int buffersize=0;
	char *tmp;

	xmlDocPtr doc =gen_xml_ver();
    xmlDocDumpFormatMemory(doc, (xmlChar **)&(tmp), &buffersize, 0);
    int length = sizeof(EVENT_HEADER_TYPE) + buffersize;

    char *buf = buffer_get(length);
    memcpy(buf+sizeof(EVENT_HEADER_TYPE),tmp, buffersize);

    EV_XML_VERSION_TYPE *ev = (EV_XML_VERSION_TYPE *)buf;
    ev->header.code=EV_XML_VERSION;
    send_event(to,(EVENT_HEADER_TYPE *)(ev),length,0);
    printf("after send:%s\n",(char*)&(ev->data));
    xmlFree((xmlChar *)tmp);
    xmlFreeDoc(doc);
	return 0;
#endif

	int buffersize=0;
	char *tmp;

	xmlDocPtr doc =gen_xml_ver();
    xmlDocDumpFormatMemory(doc, (xmlChar **)&(tmp), &buffersize, 0);
    int length = sizeof(EVENT_HEADER_TYPE) + buffersize;

    char *buf = buffer_get(length);
    memcpy(buf+sizeof(EVENT_HEADER_TYPE),tmp, buffersize);

    EV_XML_VERSION_TYPE *ev = (EV_XML_VERSION_TYPE *)buf;
    ev->header.code=EV_XML_VERSION;
    send_event(to,(EVENT_HEADER_TYPE *)(ev),length,0);
   // printf("after send:%s\n",ev->data);
    xmlFree((xmlChar *)tmp);
    xmlFreeDoc(doc);
	return 0;
}


