/**@file 
 * Copyright (C) 2013, Sinovision Tech Ltd.
 * All rights reserved.
 *
 * @brief   This file defines the event service interface
 *    the event service handles the main thread of event service
 *
 * @author  
 * @date 2013-4-7
 *
 */

#ifndef _EV_SERVICE_H_
#define _EV_SERVICE_H_



#include "ecl.h"
#include "ev_comm.h"
#include "buffer.h"
#include "queue.h"
#include "rbtree.h"
#include <sys/syscall.h> 

#define DEV_NAME_MAX	256


// TODO: if mutex needed for this structure

// Event Service specific info.

typedef struct ESINFO
{                            			
	struct ESINFO *next;                  // The next service in the service list.
    const char *name;                   // The name of the service.
    SVCID sid;                   // The id of the service.
    os_thread_t id;                     // The id of main thread .
    pid_t tid;
    int priority;                       // The thread priority.
    size_t stack;                       // The initial stack size.
    int (*prethread)(os_thread_data_t); // The pre-thread initialization function.
    int (*threadinitialize)(os_thread_data_t);  // The thread init function - does not loop.
    void (*dispatch)(EVENT_HEADER_TYPE*, void *);           // The thread entry point - executes dispatch loop.
    void (*on_exit)(os_thread_data_t);   // The thread exit function.
    os_thread_data_t arg;               // The thread argument.
    int detach;                         // 1 if the thread is detached.    
	fd_set wset;	 					// Active write file descriptors.
	fd_set rset;	 					// Active read file descriptors.
	int maxFd;							// The highest active file descriptor.
	int listenFd;
	os_thread_t soc_id;                 // The socket handler thread id
    pid_t soc_tid;
	int pipe_fd[2];                     // The self pipe fd is to wake up the comm thread in main thread
    os_sem_t sem;                       // The message semaphore.
    QUEUE *queue;
	RB_TREE_T 	timer_tree;				//timer	
	int is_log;							//flag for service enable / disable log
    /*
    int timerExpired;                   // 1 if the thread's timer has expired.
    */
}ESINFO_T;
typedef struct VER_INFO
{
	char name[32];
	char build_time[64];
	char svn_ver[32];

}VER_INFO_T;

typedef struct DEVINFO
{
	struct DEVINFO *next;			//next device.
	ESINFO_T *service;				//which service the device belong 	
	int fd;							//file descriptor of the device.
	int dev_id;						//device id.
	char dev_name[DEV_NAME_MAX];	//device name.
	os_mutex_t wr_mutex;			//device write mutex
	VER_INFO_T ver_info;

}DEVINFO_T;


//void disp_ev_header(const EVENT_HEADER_TYPE *event);

ESINFO_T* find_service_inp(int id);

ESINFO_T* get_es_info();
void display_services();


/**get service id of self thread
*/
SVCID self_id();



#endif //_EC_THREAD_H_

