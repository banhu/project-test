/**@file 
 * Copyright (C) 2013, Sinovision Tech Ltd.
 * All rights reserved.
 *
 * @brief   This file defines the command interface
 *
 * @author  
 * @date 2013-4-9
 *
 */

#ifndef _MONITOR_H_
#define _MONITOR_H_


#define PREFIX		"debug#"
#define CMD_WIDTH	8
#define MONITOR_LINE_MAX	512
#define NEME_MAX	32
#define ARG_MAX		16
#include "sys_topology.h"
/*
 * Error codes that commands return to cmd_process().
 * We use the standard 0 and 1 for success and failure, 
 * but add one more case - failure with a request to call cmd_usage().
 */
enum command_ret_t {
	CMD_RET_SUCCESS,	/* 0 = Success */
	CMD_RET_FAILURE,	/* 1 = Failure */
	CMD_RET_USAGE = -11,	/* Failure, please report 'usage' error */
};

typedef int	(*CMD_FUN_T)(int argc, char * const argv[]);

/***/
struct cmd_t {
	/* Command Name	*/
	char	name[NEME_MAX];		
	/* maximum number of arguments	*/
	int		maxargs;	
	/* Implementation function	*/
	CMD_FUN_T cmd_fun;
	char	help[MONITOR_LINE_MAX];		/* Help  message	(long)	*/
};
int readline_into_buffer(const char *const prefix, char *buffer);
int insert_command(char *cmd_name, CMD_FUN_T cmd_fun, char *help);
int delete_command(char *cmd_name);
void monitor_init(void);
void monitor_run(void);
void telnet_run(PROCESSID pid);
//int parse_run_command(const char *cmd_line, int len); //delete it for unittest
#endif /*_MONITOR_H_*/
