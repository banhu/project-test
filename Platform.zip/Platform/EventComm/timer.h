/**@file
 * Copyright (C) 2013, Sinovision Tech Ltd.
 * All rights reserved.
 *
 * @brief   This file defines the interface to timer handling
 *
 * @author  
 * @date 2013-5-14
 *
 */
#ifndef _TIMER_H_
#define _TIMER_H_

#include <stdint.h>
#include "ev_service.h"
#include "ecl.h"

struct ev_timer_t {
	unsigned int 	timer_id;
	timer_t			timer;
	ESINFO_T 		*es_info;
	SVCID 			sid;		// The id of the timer's service.
	unsigned int 	ev_code;
	void 			*event;
	unsigned int	option;
	unsigned int	expire_del;
	unsigned int	interval_time; //ms
	os_mutex_t 		timer_mutex;   //timer mutex
};

/**
* destroy service's all timer
*/
void destroy_svc_timer(ESINFO_T *es_info);

/**
*@bref start a timer,and expired send evnet
*@event timer respond when timer expired
*@size event size
*@tmo_ms timer expiration time
*@option timer option
*
*@return NULL is failed
*/
struct ev_timer_t *event_timer_start(ESINFO_T *es_info_p, void *event, uint32_t ev_size, uint32_t tmo_ms, uint32_t option);
/**
*@bref modify a timer,and expired send evnet
*@ev_timer 
*@event timer respond when timer expired
*@size event size
*@tmo_ms timer expiration time
*@option timer option
*
*@return  zero is successful,other is failed
*/
int event_timer_mod(struct ev_timer_t *ev_timer, void *event, uint32_t ev_size, uint32_t tmo_ms, uint32_t option);

/**@bref stop and destroy timer*/
int event_timer_stop(struct ev_timer_t *ev_timer);

/**
*@bref join timer thread to wait it end
*/
int join_timer_thread(void);

#endif // _TIMER_H_
