/**@file: telnetserver.c
 * Copyright (C) 2014, Sinovision Tech Ltd.
 * All rights reserved.
 *
 * @brief   
 *
 * @author  huyf
 * @date    2014-09-10 17:09:48
 * xmlReadFile
 */
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <ctype.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <netinet/tcp.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdbool.h>
#include <fcntl.h>
#include <assert.h>
#include <signal.h>
#include <pthread.h>

#include "monitor.h"

#define TELNET_LINE_MAX	512
extern char* process_name_by_id(PROCESSID pid);
extern int process_port_by_id(PROCESSID pid);
extern int parse_run_command(const char *cmd_line, int len);

void *telnet_thread(void *arg)
{

	int server_fd;       //socket fd for server
	int new_fd;    //socket of new connection
	int result;          //result: bind's return.
	socklen_t  count;    //for setsockopt
	bool myinput = false;   //control the client input
	char cmd_line[TELNET_LINE_MAX + 1];  //buffer of receive from client
	int len;                             //receive buffer's length
	char* pName = NULL;

	struct sockaddr_in addr;                     //net address of telnet server

	server_fd = socket(AF_INET, SOCK_STREAM, 0);  //create a TCP listen socket
	assert(server_fd >= 0 && "create tcp socket error\n"); //assert the TCP listen socket is create

	memset(&addr, 0, sizeof(addr));              //Data initialization 
	addr.sin_family = AF_INET;                   //set the IP communication
	addr.sin_addr.s_addr = htonl(INADDR_ANY);    //telnet server ip address, allow connect to all local address
	addr.sin_port = htons(process_port_by_id((PROCESSID)arg));                 //port of telnet server
	pName = process_name_by_id((PROCESSID)arg);          //get the process name

	//printf("addr.sin_por:%d\n",addr.sin_port);
	// Set the reuse address socket option
	count = 1;
	setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, &count, sizeof(count));    //SO_REUSEADDR: can reuse the address and port.

	result = bind(server_fd,(struct sockaddr *)&addr, sizeof(addr));  //bind the socket to the server address
	assert(result >= 0 && "bind tcp socket error\n"); //assert the bind is OK
	//listen(server_fd, 5);          //listen for connect, the listen queue's length is 5
    if( listen(server_fd, 5) == -1){
		printf("listen socket error: %s(errno: %d)\n",strerror(errno),errno);
		exit(0);
    }


	while(1){

		//check the accept is ok
		if( (new_fd = accept(server_fd, (struct sockaddr*)NULL, NULL)) == -1){
			printf("accept socket error: %s(errno: %d)\n",strerror(errno),errno);
			continue;
		}

		//create a child process to do the request, the present process wait other request
		//dup2(new_fd, 0);   //change the stdin to the socket of connect
		dup2(new_fd, 1);   //change the stdout to the socket of connect
		dup2(new_fd, 2);   //change the stderr to the socket of connect
		printf("Welcom use this telnet debug!\n");  //print welcom
		printf("If you will logout please input 'exit'!\n");  //print welcom
		printf("\n%s:~#", pName);
		fflush(stdout);
		myinput = true;    //set the input

		//receive the commond and do it
		while(myinput){
			memset(cmd_line, 0x0, TELNET_LINE_MAX);        //Data initialization of cmd_line
			len = recv(new_fd, cmd_line, TELNET_LINE_MAX, 0);  //receive the commond form telnet client

			if(len ==0){
				myinput = false;
				break;
			}          //when the client stopped then the server will recv a 0 length message ,then break;

			if ((len == -1) && (errno != 4)) {
				puts("<INTERRUPT>\n");
			} else {
				if (0 == strncmp(cmd_line, "exit", 4)) {
					//return;
					myinput = false;
					break;
				}
				if(isalpha(cmd_line[0])){
					if(NULL != strstr(cmd_line,"\r")) // if have "\r" reduce 1
						len -= 1;
					if(NULL != strstr(cmd_line,"\n")) // if have "\n" reduce 1
						len -= 1;
					if(len > 0)
					{
						parse_run_command(cmd_line, len);                             //if the ENTER have 2 byte, we have to drop it
						fflush(stdout);
					}
				}else{
					if(NULL != strstr(cmd_line,"\r") || NULL != strstr(cmd_line,"\n")) // if have "\r" reduce 1
					{
						printf("\n%s:~#", pName);
						fflush(stdout);
					}
				}
			}

		}
		shutdown(new_fd, SHUT_RDWR); //shutdown the client
		close(new_fd);      //close the client socket fd
	}
	close(server_fd);       //close the server socket
}




void telnet_run(PROCESSID pid)
{
	pthread_t telid;
	int ret;
	signal(SIGPIPE, SIG_IGN);
	ret = pthread_create(&telid, NULL, telnet_thread, (void *)pid);
	if (ret != 0)
	        printf("can't create thread: %s(errno: %d)\n", strerror(ret),ret);
}
