/**@file 
 * Copyright (C) 2013, Sinovision Tech Ltd.
 * All rights reserved.
 *
 * @brief  this file defines the interface of event flag
 *
 * @author  
 * @date 2013-5-14
 *
 */
#ifndef _EV_FLAG_H_
#define _EV_FLAG_H_

#include <stdint.h>
#include "ECService.h"


class EvFlag
{
public:
	
	EvFlag();
	virtual ~EvFlag();

	typedef enum
	{
		FLAG_OR = 1,
		FLAG_AND,
	} FLAG_PEND_TYPE;
	int post(uint32_t flag);
	uint32_t inquiry();
	int clear(uint32_t flag);
    
	int subscribe(uint32_t waitFlags, FLAG_PEND_TYPE type, uint32_t code);
	void unSubscribe(uint32_t waitFlags);



protected:
	typedef struct FLAG_WAIT
	{
	    FLAG_WAIT *next;
        SVCID id;
	    FLAG_PEND_TYPE pendType;
	    uint32_t waitFlags;
        uint32_t evCode;
        bool inUse;
	}FLAG_WAIT_TYPE;

    os_sem_t sem; 
	uint32_t currentFlag; // current flag value
	FLAG_WAIT_TYPE  *subscribeList;

};


#endif

