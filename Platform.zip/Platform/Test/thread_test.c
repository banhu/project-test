

#include <stdlib.h>
#include <unistd.h>

#include <stdio.h>
#include "os_intf.h"
#include "TestFramework.h"

#ifdef __cplusplus
extern "C" {
#endif


os_thread_data_t disp_time(os_thread_data_t interval);

int os_thread_test() {

    TEST_INIT(1);
	TEST_CATEGORY("OS Thread");
	
	printf("posix thread test  start\n");

	int noCreate = 0;
	os_thread_t id_1 = 0;
	os_thread_t id_2 = 0;
	int priority = 100;
	size_t stack = 1024;
	int detach = 0;
	int arg_1 = 1000;
	int arg_2 = 2000;

	os_thread_create(noCreate,
					 &id_1,
					 priority,
					 stack,
					 disp_time,
					 (os_thread_data_t)arg_1,
					 detach);

	os_thread_create(noCreate,
					 &id_2,
					 priority+1,
					 stack,
					 disp_time,
					 (os_thread_data_t)arg_2,
					 detach);

	sleep(5);
	TEST(id_1!=id_2, "thread ID are different");
    TEST(0 == os_thread_cancel(id_1), "thread 1 cancel");
	TEST(0 == os_thread_cancel(id_2), "thread 2 cancel");
	TEST_DONE();

	return 0;
}


os_thread_data_t disp_time(os_thread_data_t arg)
{
	int interval = (int)arg;
	int currentT=0;
    while(1)
    {
    	//printf("task id=0x%x interval %d ms, current time %d ms \n", os_thread_self(),interval,currentT);
    	currentT +=interval;
    	usleep(interval*1000);
    }
}



#ifdef __cplusplus
}
#endif

