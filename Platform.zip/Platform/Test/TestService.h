
#ifndef _TEST_SERVICE_H_
#define _TEST_SERVICE_H_

#include "os_intf.h"
#include "ECService.h"
#include "Macho.h"
#include "timer.h"


class TestService : public ECService
{
public:
	explicit TestService(SVCID id, int priority,
        bool detach, size_t stack,os_thread_data_t arg = NULL);
	~TestService(){};

private:
	int initialize();
	int threadInitialize();
	void processEvent(EVENT_HEADER_TYPE *event);
	void test1(EVENT_HEADER_TYPE *event);

};



class TestService2 : public ECService
{
public:
	explicit TestService2(SVCID id, int priority,
        bool detach, size_t stack,os_thread_data_t arg = NULL);
	~TestService2(){};

private:
	int initialize();
	int threadInitialize();

};

class TestService3 : public ECService
{
public:
	explicit TestService3(SVCID id, int priority,
        bool detach, size_t stack,os_thread_data_t arg = NULL);
	~TestService3(){};
	void test(void);

private:
	int initialize();
	int threadInitialize();
	void evtHandler(EVENT_HEADER_TYPE *event);

};


class TestService4 : public ECService
{
public:
	explicit TestService4(SVCID id, int priority,
        bool detach, size_t stack,os_thread_data_t arg = NULL);
	~TestService4(){};

private:
	int initialize();
	int threadInitialize();
	void evtHandler(EVENT_HEADER_TYPE *event);

};

class TestService5 : public ECService
{
public:
	explicit TestService5(SVCID id, int priority,
        bool detach, size_t stack,os_thread_data_t arg = NULL);
	~TestService5(){};

private:
	int initialize();
	int threadInitialize();
	void evtHandler(EVENT_HEADER_TYPE *event);

};

class TestService6 : public ECService
{
public:
	explicit TestService6(SVCID id, int priority,
        bool detach, size_t stack,os_thread_data_t arg = NULL);
	~TestService6(){};

private:
	int initialize();
	int threadInitialize();
	void evtHandler(EVENT_HEADER_TYPE *event);

};


class TestService7 : public ECService
{
public:
	explicit TestService7(SVCID id, int priority,
        bool detach, size_t stack,os_thread_data_t arg = NULL);
	~TestService7(){};
	void runTest();

private:
	uint32_t timerid1,timerid2,timerid3;
	uint32_t timer_expired_count;
	int initialize();
	int threadInitialize();
	void evtHandler(EVENT_HEADER_TYPE *event);
	

};


class TestService8 : public ECService
{
public:
	explicit TestService8(SVCID id, int priority,
        bool detach, size_t stack,os_thread_data_t arg = NULL);
	~TestService8(){};
	void runTest();

private:
	int initialize();
	int threadInitialize();
	void evtHandler(EVENT_HEADER_TYPE *event);
	

};



#endif


















