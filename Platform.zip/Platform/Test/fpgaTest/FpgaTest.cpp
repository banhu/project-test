

#include "FpgaTest.h"
#include "TestFramework.h"
#include <unistd.h>
#include "malloc.h"
#include "ev_sr_status.h"


static void fpgaCmdUsage(void)
{
		printf("usage:\n");
		printf("	fpga [set | get ] [address] [value]\n");
}

static int	fpga_command(int argc, char * const argv[])
{
	EV_WR_FPGA_REG_TYPE wrFpgaRegEvt;
	EV_RD_FPGA_REG_TYPE rdFpgaRegEvt;
		
	if (argc < 2 || argc > 3) {
		fpgaCmdUsage();
		return -1;
	}

	if (0 == strcmp(argv[0], "set")) {
		if (argc != 3) {
			fpgaCmdUsage();
			return -1;
		}
		wrFpgaRegEvt.reg_offset = strtol(argv[1], NULL, 16);//atoi(argv[1]);
		wrFpgaRegEvt.val = strtol(argv[2], NULL, 16);//atoi(argv[2]);
		//ECService::sendEvent(SVC_ID_DEV_FPGATEST, EV_WR_FPGA_REG, (void *)&wrFpgaRegEvt, sizeof(EV_WR_FPGA_REG_TYPE));
		ECService::sendEventToDev((char *)FPGATESTDEV, EV_WR_FPGA_REG, (void *)&wrFpgaRegEvt, sizeof(EV_WR_FPGA_REG_TYPE));
		printf("set 0x%x = 0x%x\n", wrFpgaRegEvt.reg_offset, wrFpgaRegEvt.val);
		return 0;
	}
	if (0 == strcmp(argv[0], "get")) {
		if (argc != 2) {
			fpgaCmdUsage();
			return -1;
		}
		rdFpgaRegEvt.reg_offset = strtol(argv[1], NULL, 16);//atoi(argv[1]);
		//ECService::sendEvent(SVC_ID_DEV_FPGATEST, EV_RD_FPGA_REG, (void *)&rdFpgaRegEvt, sizeof(EV_RD_FPGA_REG_TYPE));
		ECService::sendEventToDev((char *)FPGATESTDEV, EV_RD_FPGA_REG, (void *)&rdFpgaRegEvt, sizeof(EV_RD_FPGA_REG_TYPE));
		return 0;
	}
	

	return 0;
}




FpgaTest::FpgaTest(SVCID id,int priority,bool detach,size_t stack,os_thread_data_t arg)
:ECService(id, priority, detach, stack, arg)
{
}

int  FpgaTest::initialize()
{
	registerEvent(EV_RD_FPGA_REG_RES, (EventHandler)&FpgaTest::evtHandler);
	return 0;
}


int FpgaTest::threadInitialize()
{
	registerDevice((char *)FPGATESTDEV, SVC_ID_DEV_FPGATEST);
	ECL::insert_command((char*)"fpga", fpga_command, (char*)"fpga test command ");
	/*
	EV_WR_FPGA_REG_TYPE wrFpgaRegEvt;
	EV_RD_FPGA_REG_TYPE rdFpgaRegEvt;

	registerDevice((char *)ADCCOMMDEV, SVC_ID_DEV_ADC_COMM);

	//registerDevice((char *)MEMDEV, SVC_ID_DEV_MEM);
	
	removeDevice((char *)FPGATESTDEV);
	
	registerDevice((char *)FPGATESTDEV, SVC_ID_DEV_FPGATEST);
	//sleep(1);
	removeDeviceByid(SVC_ID_DEV_FPGATEST);

	registerDevice((char *)FPGATESTDEV, SVC_ID_DEV_FPGATEST);
	

	wrFpgaRegEvt.reg_offset = 0x101;
	wrFpgaRegEvt.val = 0x7;
		
	//sendEventToDev((char *)FPGATESTDEV, EV_WR_FPGA_REG, (void *)&wrFpgaRegEvt, sizeof(EV_WR_FPGA_REG_TYPE));
	sendEvent(SVC_ID_DEV_FPGATEST, EV_WR_FPGA_REG, (void *)&wrFpgaRegEvt, sizeof(EV_WR_FPGA_REG_TYPE));
	
	rdFpgaRegEvt.reg_offset = 0x505;
	//sendEventToDev((char *)FPGATESTDEV, EV_RD_FPGA_REG, (void *)&rdFpgaRegEvt, sizeof(EV_RD_FPGA_REG_TYPE));
	sendEvent(SVC_ID_DEV_FPGATEST, EV_RD_FPGA_REG, (void *)&rdFpgaRegEvt, sizeof(EV_RD_FPGA_REG_TYPE));
	*/
	return 0;
}

void FpgaTest::evtHandler(EVENT_HEADER_TYPE *event)
{
	EV_RD_FPGA_REG_RES_TYPE *rdFpgaRegResEvt;
	
	//printf("\nevent %d handler:\n", event->code);

	rdFpgaRegResEvt = (EV_RD_FPGA_REG_RES_TYPE *)event;

	printf("0x%x = 0x%x\n", rdFpgaRegResEvt->reg_offset, rdFpgaRegResEvt->val);
	
	
}











