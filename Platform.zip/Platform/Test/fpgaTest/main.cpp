
#include <unistd.h>
//#include "TestFramework.h"
#include "FpgaTest.h"





int timer_test_done = 0;
	
int main(int argc, char *argv[])
{


	new FpgaTest(SVC_ID_TEST7, 0, 1, 10000, 0);



    ECService::startAll();


	

    ECL::monitor_run();
}




