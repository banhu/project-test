
#ifndef _TEST_SERVICE_H_
#define _TEST_SERVICE_H_

#include "os_intf.h"
#include "ECService.h"
#include "Macho.h"
#include "timer.h"



class ConnManagerTest : public ECService
{
public:
	explicit ConnManagerTest(SVCID id, int priority,
        bool detach, size_t stack,os_thread_data_t arg = NULL);
	~ConnManagerTest(){};
	void evtHandler(EVENT_HEADER_TYPE *event);
	void evtTestHandler(EVENT_HEADER_TYPE *event);
	void evtDisConnHandler(EVENT_HEADER_TYPE *event);
	void evtConnHandler(EVENT_HEADER_TYPE *event);
	void evtTestTimerHandler(EVENT_HEADER_TYPE *event);

private:
	int initialize();
	int threadInitialize();



};

class ConnManagerTest2 : public ECService
{
public:
	explicit ConnManagerTest2(SVCID id, int priority,
        bool detach, size_t stack,os_thread_data_t arg = NULL);
	~ConnManagerTest2(){};
	void evtHandler(EVENT_HEADER_TYPE *event);
	void evtTestHandler(EVENT_HEADER_TYPE *event);
	void evtDisConnHandler(EVENT_HEADER_TYPE *event);
	void evtConnHandler(EVENT_HEADER_TYPE *event);
	void evtTestTimerHandler(EVENT_HEADER_TYPE *event);

private:
	int initialize();
	int threadInitialize();


};


#endif


















