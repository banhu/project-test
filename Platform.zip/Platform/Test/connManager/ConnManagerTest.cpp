

#include "ConnManagerTest.h"
#include "TestFramework.h"
#include <unistd.h>
#include "malloc.h"
#include "ev_sr_status.h"



ConnManagerTest::ConnManagerTest(SVCID id,int priority,bool detach,size_t stack,os_thread_data_t arg)
:ECService(id, priority, detach, stack, arg)
{
}

int  ConnManagerTest::initialize()
{
	registerEvent(EV_RD_FPGA_REG_RES, (EventHandler)&ConnManagerTest::evtHandler);
	registerEvent(EV_TEST, (EventHandler)&ConnManagerTest::evtTestHandler);
	registerEvent(EV_ECL_CONNECTED, (EventHandler)&ConnManagerTest::evtConnHandler);
	registerEvent(EV_ECL_DISCONNECTED, (EventHandler)&ConnManagerTest::evtDisConnHandler);
	registerEvent(EV_TEST_TIMER, (EventHandler)&ConnManagerTest::evtTestTimerHandler);
	return 0;
}


int ConnManagerTest::threadInitialize()
{
	//registerDevice((char *)FPGATESTDEV, SVC_ID_DEV_FPGATEST);
	//ECL::insert_command((char*)"fpga", fpga_command, (char*)"fpga test command ");
	connToSvc(SVC_ID_TEST7, 1);
	/*
	EV_WR_FPGA_REG_TYPE wrFpgaRegEvt;
	EV_RD_FPGA_REG_TYPE rdFpgaRegEvt;

	registerDevice((char *)ADCCOMMDEV, SVC_ID_DEV_ADC_COMM);

	//registerDevice((char *)MEMDEV, SVC_ID_DEV_MEM);
	
	removeDevice((char *)FPGATESTDEV);
	
	registerDevice((char *)FPGATESTDEV, SVC_ID_DEV_FPGATEST);
	//sleep(1);
	removeDeviceByid(SVC_ID_DEV_FPGATEST);

	registerDevice((char *)FPGATESTDEV, SVC_ID_DEV_FPGATEST);
	

	wrFpgaRegEvt.reg_offset = 0x101;
	wrFpgaRegEvt.val = 0x7;
		
	//sendEventToDev((char *)FPGATESTDEV, EV_WR_FPGA_REG, (void *)&wrFpgaRegEvt, sizeof(EV_WR_FPGA_REG_TYPE));
	sendEvent(SVC_ID_DEV_FPGATEST, EV_WR_FPGA_REG, (void *)&wrFpgaRegEvt, sizeof(EV_WR_FPGA_REG_TYPE));
	
	rdFpgaRegEvt.reg_offset = 0x505;
	//sendEventToDev((char *)FPGATESTDEV, EV_RD_FPGA_REG, (void *)&rdFpgaRegEvt, sizeof(EV_RD_FPGA_REG_TYPE));
	sendEvent(SVC_ID_DEV_FPGATEST, EV_RD_FPGA_REG, (void *)&rdFpgaRegEvt, sizeof(EV_RD_FPGA_REG_TYPE));
	*/
	
	return 0;
}

void ConnManagerTest::evtHandler(EVENT_HEADER_TYPE *event)
{
	EV_RD_FPGA_REG_RES_TYPE *rdFpgaRegResEvt;
	
	printf("\nevent %d handler:\n", event->code);

	rdFpgaRegResEvt = (EV_RD_FPGA_REG_RES_TYPE *)event;

	printf("0x%x = 0x%x\n", rdFpgaRegResEvt->reg_offset, rdFpgaRegResEvt->val);
	
	
}

void ConnManagerTest::evtTestHandler(EVENT_HEADER_TYPE *event)
{
	
	printf("****receive test event %d handler:\n", event->code);
	
}

void ConnManagerTest::evtDisConnHandler(EVENT_HEADER_TYPE *event)
{
	printf("\n***************************************\n");
	printf("receive disconnected event %d handler:\n", event->code);
	printf("close form %d to %d:\n", ((EV_ECL_CONNECTED_TYPE *)event)->from, ((EV_ECL_CONNECTED_TYPE *)event)->to);
	printf("***************************************\n");
	if (((EV_ECL_CONNECTED_TYPE *)event)->from == SVC_ID_TEST8) {
		timerStop(EV_TEST_TIMER);
	}
}

void ConnManagerTest::evtConnHandler(EVENT_HEADER_TYPE *event)
{
	printf("\n***************************************\n");
	printf("receive connected event %d handler:\n", event->code);
	printf("connected form %d to %d:\n", ((EV_ECL_DISCONNECTED_TYPE *)event)->from, ((EV_ECL_DISCONNECTED_TYPE *)event)->to);
	printf("***************************************\n");
	sendEvent(SVC_ID_TEST7, EV_TEST);
	if (((EV_ECL_CONNECTED_TYPE *)event)->from == SVC_ID_TEST8) {
		timerStart(EV_TEST_TIMER, 1000, TIMER_OPT_INTERVAL);
	}
}

void ConnManagerTest::evtTestTimerHandler(EVENT_HEADER_TYPE *event)
{
	sendEvent(SVC_ID_TEST7, EV_TEST);
}



ConnManagerTest2::ConnManagerTest2(SVCID id,int priority,bool detach,size_t stack,os_thread_data_t arg)
:ECService(id, priority, detach, stack, arg)
{
}

int  ConnManagerTest2::initialize()
{
	registerEvent(EV_RD_ADC_COMM_RES, (EventHandler)&ConnManagerTest2::evtHandler);
	registerEvent(EV_TEST, (EventHandler)&ConnManagerTest2::evtTestHandler);
	registerEvent(EV_ECL_CONNECTED, (EventHandler)&ConnManagerTest2::evtConnHandler);
	registerEvent(EV_ECL_DISCONNECTED, (EventHandler)&ConnManagerTest2::evtDisConnHandler);
	registerEvent(EV_TEST_TIMER, (EventHandler)&ConnManagerTest2::evtTestTimerHandler);
	return 0;
}


int ConnManagerTest2::threadInitialize()
{

	//EV_RD_ADC_COMM_TYPE rdAdcCommRegEvt;

	//registerDevice((char *)ADCCOMMDEV, SVC_ID_DEV_ADC_COMM);
	connToSvc(SVC_ID_TEST8, 0);
	
	
	//rdAdcCommRegEvt.chan_mask = 0xFF;
	
		
	//sendEventToDev((char *)ADCCOMMDEV, EV_RD_ADC_COMM, (void *)&rdAdcCommRegEvt, sizeof(EV_RD_ADC_COMM_TYPE));
	//sendEvent(SVC_ID_DEV_FPGATEST, EV_WR_FPGA_REG, (void *)&wrFpgaRegEvt, sizeof(EV_WR_FPGA_REG_TYPE));
	
	
	return 0;
}

void ConnManagerTest2::evtHandler(EVENT_HEADER_TYPE *event)
{
	EV_RD_ADC_COMM_RES_TYPE *rdAdcCommResEvt;
	int  i;
	int64_t diff;
	
	printf("\nevent %d handler:\n", event->code);

	rdAdcCommResEvt = (EV_RD_ADC_COMM_RES_TYPE *)event;

	diff = rdAdcCommResEvt->header.received - rdAdcCommResEvt->header.sent;
	printf("command use %lld \n", diff);

	for (i = 0; i < 8; i++) {
		printf("%d = %d\n", i, rdAdcCommResEvt->channel_val[i]);
	}
	
}

void ConnManagerTest2::evtTestHandler(EVENT_HEADER_TYPE *event)
{

	printf("****receive event %d handler:\n", event->code);
}

void ConnManagerTest2::evtDisConnHandler(EVENT_HEADER_TYPE *event)
{
	printf("\n***************************************\n");
	printf("receive disconnected event %d handler:\n", event->code);
	printf("close from %d to %d:\n", ((EV_ECL_CONNECTED_TYPE *)event)->from, ((EV_ECL_CONNECTED_TYPE *)event)->to);
	printf("***************************************\n");
}

void ConnManagerTest2::evtConnHandler(EVENT_HEADER_TYPE *event)
{
	printf("\n***************************************\n");
	printf("receive connected event %d handler:\n", event->code);
	printf("connect from %d to %d:\n", ((EV_ECL_DISCONNECTED_TYPE *)event)->from, ((EV_ECL_DISCONNECTED_TYPE *)event)->to);
	printf("***************************************\n");
}

void ConnManagerTest2::evtTestTimerHandler(EVENT_HEADER_TYPE *event)
{
	sendEvent(SVC_ID_TEST8, EV_TEST);
}









