
#include <unistd.h>
//#include "TestFramework.h"
#include "ConnManagerTest.h"


extern "C" int cmd_display_conns(int argc, char * const argv[]);
	
int main(int argc, char *argv[])
{
	//scu
	new ConnManagerTest(SVC_ID_TEST8, 0, 1, 10000, 0);
	
	// rcu
	//new ConnManagerTest2(SVC_ID_TEST7, 0, 1, 10000, 0);


    ECService::startAll();

	//testservice->test();

   ECL::monitor_run();

   //sleep(60);	

   printf("go to stop\n");
 //   ECL::monitor_run();

     ECL::stop_services();
	
     sleep(1);
     cmd_display_conns(1, NULL);

}




