

#include "SlipringStatus.h"
#include "TestFramework.h"
#include <unistd.h>
#include "malloc.h"
#include "ev_sr_status.h"




static int	slipring_command(int argc, char * const argv[])
{
	EV_WR_SLIPRING_REG_TYPE wrSlipring;
	EV_RD_SLIPRING_STATUS_TYPE rdStatus;
		
	if ((argc < 1) || (argc > 3)) {
		printf("usage:\n");
		printf("	slpring status\n");
		printf("	slpring set reg value\n");
		return -1;
	}

	if (0 == strcmp("status", argv[0])) {
		SlipringStatus::sendEventToDev((char *)SLIPRINGSTATDEV, EV_RD_SLIPRING_STATUS, (void *)&rdStatus, sizeof(EV_RD_SLIPRING_STATUS_TYPE));
	} else {
		if (argc < 3 || (0 != strcmp("set", argv[0]))){
			printf("command args error. use help\n");
			return -1;
		}
		
		wrSlipring.reg_offset = atoi(argv[1]);
		wrSlipring.val = atoi(argv[2]);
	
		SlipringStatus::sendEventToDev((char *)SLIPRINGSTATDEV, EV_WR_SLIPRING_REG, (void *)&wrSlipring, sizeof(EV_WR_SLIPRING_REG_TYPE));
	} 

	return 0;
}




SlipringStatus::SlipringStatus(SVCID id,int priority,bool detach,size_t stack,os_thread_data_t arg)
:ECService(id, priority, detach, stack, arg)
{
	;
}

int  SlipringStatus::initialize()
{

	registerEvent(EV_RD_SLIPRING_STATUS_RES, (EventHandler)&SlipringStatus::evtHandler);
	
	return 0;
}


int SlipringStatus::threadInitialize()
{
	registerDevice((char *)SLIPRINGSTATDEV, SVC_ID_DEV_SLIPRING_STAT);
	



	ECL::insert_command((char*)"slipring", slipring_command, (char*)"slipring command get status and write status");
	
	return 0;
}

void SlipringStatus::evtHandler(EVENT_HEADER_TYPE *event)
{
	EV_RD_SLIPRING_STATUS_RES_TYPE *stat_evt;

	stat_evt = (EV_RD_SLIPRING_STATUS_RES_TYPE *)event;
	/*
	int64_t diff;
	
	printf("\nevent %d handler\n", event->code);

	diff = event->received - event->sent;
	printf("event use %lld \n", diff);
	*/
	printf("rx_int count: %ld\n",(long int)stat_evt->status.int_stat.rx_int);
	printf("tx_int count: %ld\n", (long int)stat_evt->status.int_stat.tx_int);
	printf("pac_crc_err count: %ld\n",(long int) stat_evt->status.int_stat.pac_crc_err);
	printf("pac_ack_timeout count: %ld\n", (long int)stat_evt->status.int_stat.pac_ack_timeout);
	printf("pac_nack count: %ld\n", (long int)stat_evt->status.int_stat.pac_nack);
	printf("rx_fifo_ovr count: %ld\n", (long int)stat_evt->status.int_stat.rx_fifo_ovr);
	printf("tx_fifo_ovr count: %ld\n", (long int)stat_evt->status.int_stat.tx_fifo_ovr);
	printf("ack_hl_timeout count: %ld\n", (long int)stat_evt->status.int_stat.ack_hl_timeout);
	printf("ack_xray_timeout count: %ld\n",(long int) stat_evt->status.int_stat.ack_xray_timeout);
	printf("error_int count: %ld\n", (long int)stat_evt->status.int_stat.error_int);
	printf("hl_nack count: %ld\n", (long int)stat_evt->status.int_stat.hl_nack);
	printf("xray_nack count: %ld\n", (long int)stat_evt->status.int_stat.xray_nack);
	printf("adn_unlock count: %ld\n",(long int) stat_evt->status.int_stat.adn_unlock);
	printf("adn_los count: %ld\n", (long int)stat_evt->status.int_stat.adn_los);
	printf("adn_repeat_sync count: %ld\n", (long int)stat_evt->status.int_stat.adn_repeat_sync);
	
	
	printf("count_send_hardline: %ld\n", (long int)stat_evt->status.count_send_hardline);
	printf("count_rec_right_hardline: %ld\n", (long int)stat_evt->status.count_rec_right_hardline);
	printf("count_rec_err_hardline: %ld\n", (long int)stat_evt->status.count_rec_err_hardline);
	
	printf("count_send_xrayon: %ld\n", (long int)stat_evt->status.count_send_xrayon);
	printf("count_rec_right_xrayon: %ld\n", (long int)stat_evt->status.count_rec_right_xrayon);
	printf("count_rec_err_xrayon: %ld\n", (long int)stat_evt->status.count_rec_err_xrayon);

	printf("count_send_xrayoff: %ld\n", (long int)stat_evt->status.count_send_xrayoff);
	printf("count_rec_right_xrayoff: %ld\n", (long int)stat_evt->status.count_rec_right_xrayoff);
	printf("count_rec_err_xrayoff: %ld\n", (long int)stat_evt->status.count_rec_err_xrayoff);
	
	printf("count_rec_hardline_sub_pac_0: %ld\n", (long int)stat_evt->status.count_rec_hardline_sub_pac_0);
	printf("count_rec_hardline_sub_pac_1: %ld\n", (long int)stat_evt->status.count_rec_hardline_sub_pac_1);
	printf("count_rec_hardline_sub_pac_2: %ld\n", (long int)stat_evt->status.count_rec_hardline_sub_pac_2);
	printf("count_rec_hardline_sub_pac_3: %ld\n", (long int)stat_evt->status.count_rec_hardline_sub_pac_3);
	printf("count_rec_hardline_sub_pac_4: %ld\n", (long int)stat_evt->status.count_rec_hardline_sub_pac_4);
	printf("count_rec_hardline_sub_pac_5: %ld\n", (long int)stat_evt->status.count_rec_hardline_sub_pac_5);
	
}









