
#ifndef _TEST_SERVICE_H_
#define _TEST_SERVICE_H_

#include "os_intf.h"
#include "ECService.h"
#include "Macho.h"
#include "timer.h"


class SlipringStatus : public ECService
{
public:
	explicit SlipringStatus(SVCID id, int priority,
        bool detach, size_t stack,os_thread_data_t arg = NULL);
	~SlipringStatus(){};
	void runTest();

private:
	int initialize();
	int threadInitialize();
	void evtHandler(EVENT_HEADER_TYPE *event);
	

};



#endif


















