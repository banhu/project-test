
#include <unistd.h>
//#include "TestFramework.h"
#include "SlipringStatus.h"



	
int main(int argc, char *argv[])
{


	new SlipringStatus(SVC_ID_TEST7, 0, 1, 10000, 0);



    ECService::startAll();


    ECL::monitor_run();
}




