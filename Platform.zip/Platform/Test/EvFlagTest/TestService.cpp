

#include "TestService.h"
#include "TestFramework.h"
#include <unistd.h>
#include "malloc.h"



typedef struct
{
    EVENT_HEADER_TYPE header;
	char body[256];
} EV_TEST_KERNEL_TYPE;


TestService::TestService(SVCID id,int priority,bool detach,size_t stack,os_thread_data_t arg)
:ECService(id, priority, detach, stack, arg)
{
	//TEST_INIT(1);
}

int  TestService::initialize()
{
	//TEST(1, "Initialize operation entered ");
    registerEvent(10, (EventHandler)&TestService::test1);
	return 0;
}
void TestService::test1(EVENT_HEADER_TYPE *event)
{
	printf(" \n\n test 1 handler \n\n");
}

int TestService::threadInitialize()
{
    //TEST(1, "Thread initialize operation entered ");
    //TEST_DONE();
	return 0;
}

TestService2::TestService2(SVCID id,int priority,bool detach,size_t stack,os_thread_data_t arg)
:ECService(id, priority, detach, stack, arg)
{
}

int  TestService2::initialize()
{
	return 0;
}


int TestService2::threadInitialize()
{
	printf("test service 2: sending the data \n");
	int size = 4096;
	char* data = (char*)malloc(size+sizeof(EV_TEST_TYPE));
	memset(data+sizeof(EV_TEST_TYPE), 0xA5, size);
	EV_TEST_TYPE *event = (EV_TEST_TYPE *)data;
	int i=0;
	for(i=0; i<10;i++){
		printf("\n\n i=%d \n\n", i);
		sendEvent(SVC_ID_OC_SCANMGR,10+i,(void*)event,sizeof(EV_TEST_TYPE)+size);
		sleep(2);
	}
	return 0;
}



TestService3::TestService3(SVCID id,int priority,bool detach,size_t stack,os_thread_data_t arg)
:ECService(id, priority, detach, stack, arg)
{
}

int  TestService3::initialize()
{
	registerEvent(EV_RD_MEM_RES, (EventHandler)&TestService3::evtHandler);
	return 0;
}


int TestService3::threadInitialize()
{
	EV_WR_MEM_TYPE wrMemEvt;
	EV_RD_MEM_TYPE rdMemEvt;

	//registe in sys_topology.c
	//registerDevice((char *)MEMDEV, SVC_ID_DEV_MEM);

	wrMemEvt.phy_addr = 0x44E10968;//0x4C000000;
	wrMemEvt.val = 0x7;
		
	sendEventToDev((char *)MEMDEV, EV_WR_MEM, (void *)&wrMemEvt, sizeof(EV_WR_MEM_TYPE));
	
	rdMemEvt.phy_addr = 0x44E10968;//0x4C000000;
	sendEventToDev((char *)MEMDEV, EV_RD_MEM, (void *)&rdMemEvt, sizeof(EV_RD_MEM_TYPE));
	
	return 0;
}

void TestService3::evtHandler(EVENT_HEADER_TYPE *event)
{
	EV_RD_MEM_RES_TYPE *rdMemResEvt;
	
	printf("\nevent %d handler:\n", event->code);

	rdMemResEvt = (EV_RD_MEM_RES_TYPE *)event;

	printf("0x%x = 0x%x\n", rdMemResEvt->phy_addr, rdMemResEvt->val);
	
	
}

void TestService3::test(void)
{
	
}



TestService4::TestService4(SVCID id,int priority,bool detach,size_t stack,os_thread_data_t arg)
:ECService(id, priority, detach, stack, arg)
{
}

int  TestService4::initialize()
{
	registerEvent(EV_RD_FPGA_REG_RES, (EventHandler)&TestService4::evtHandler);
	return 0;
}


int TestService4::threadInitialize()
{
	EV_WR_FPGA_REG_TYPE wrFpgaRegEvt;
	EV_RD_FPGA_REG_TYPE rdFpgaRegEvt;

	//registerDevice((char *)MEMDEV, SVC_ID_DEV_MEM);
	registerDevice((char *)FPGATESTDEV, SVC_ID_DEV_FPGATEST);
	removeDevice((char *)FPGATESTDEV);
	
	registerDevice((char *)FPGATESTDEV, SVC_ID_DEV_FPGATEST);
	//sleep(1);
	removeDeviceByid(SVC_ID_DEV_FPGATEST);

	registerDevice((char *)FPGATESTDEV, SVC_ID_DEV_FPGATEST);
	

	wrFpgaRegEvt.reg_offset = 0x101;
	wrFpgaRegEvt.val = 0x7;
		
	//sendEventToDev((char *)FPGATESTDEV, EV_WR_FPGA_REG, (void *)&wrFpgaRegEvt, sizeof(EV_WR_FPGA_REG_TYPE));
	sendEvent(SVC_ID_DEV_FPGATEST, EV_WR_FPGA_REG, (void *)&wrFpgaRegEvt, sizeof(EV_WR_FPGA_REG_TYPE));
	
	rdFpgaRegEvt.reg_offset = 0x505;
	//sendEventToDev((char *)FPGATESTDEV, EV_RD_FPGA_REG, (void *)&rdFpgaRegEvt, sizeof(EV_RD_FPGA_REG_TYPE));
	sendEvent(SVC_ID_DEV_FPGATEST, EV_RD_FPGA_REG, (void *)&rdFpgaRegEvt, sizeof(EV_RD_FPGA_REG_TYPE));
	
	return 0;
}

void TestService4::evtHandler(EVENT_HEADER_TYPE *event)
{
	EV_RD_FPGA_REG_RES_TYPE *rdFpgaRegResEvt;
	
	printf("\nevent %d handler:\n", event->code);

	rdFpgaRegResEvt = (EV_RD_FPGA_REG_RES_TYPE *)event;

	printf("0x%x = 0x%x\n", rdFpgaRegResEvt->reg_offset, rdFpgaRegResEvt->val);
	
	
}






TestService5::TestService5(SVCID id,int priority,bool detach,size_t stack,os_thread_data_t arg)
:ECService(id, priority, detach, stack, arg)
{
}

int  TestService5::initialize()
{
	registerEvent(EV_RD_ADC_COMM_RES, (EventHandler)&TestService5::evtHandler);
	return 0;
}


int TestService5::threadInitialize()
{

	EV_RD_ADC_COMM_TYPE rdAdcCommRegEvt;

	registerDevice((char *)ADCCOMMDEV, SVC_ID_DEV_ADC_COMM);
	
	
	rdAdcCommRegEvt.chan_mask = 0xFF;
	
		
	sendEventToDev((char *)ADCCOMMDEV, EV_RD_ADC_COMM, (void *)&rdAdcCommRegEvt, sizeof(EV_RD_ADC_COMM_TYPE));
	//sendEvent(SVC_ID_DEV_FPGATEST, EV_WR_FPGA_REG, (void *)&wrFpgaRegEvt, sizeof(EV_WR_FPGA_REG_TYPE));
	
	
	return 0;
}

void TestService5::evtHandler(EVENT_HEADER_TYPE *event)
{
	EV_RD_ADC_COMM_RES_TYPE *rdAdcCommResEvt;
	int  i;
	int64_t diff;
	
	printf("\nevent %d handler:\n", event->code);

	rdAdcCommResEvt = (EV_RD_ADC_COMM_RES_TYPE *)event;

	diff = rdAdcCommResEvt->header.received - rdAdcCommResEvt->header.sent;
	printf("command use %lld \n", diff);

	for (i = 0; i < 8; i++) {
		printf("%d = %d\n", i, rdAdcCommResEvt->channel_val[i]);
	}
	
	
}



TestService6::TestService6(SVCID id,int priority,bool detach,size_t stack,os_thread_data_t arg)
:ECService(id, priority, detach, stack, arg)
{
}

int  TestService6::initialize()
{
	registerEvent(EV_RD_FPGA_KEY_RES, (EventHandler)&TestService6::evtHandler);
	return 0;
}


int TestService6::threadInitialize()
{

	EV_RD_FPGA_KEY_TYPE rdFpgaKeyEvt;

	registerDevice((char *)FPGAKEYDEV, SVC_ID_DEV_FPGA_KEY);
	
	
	rdFpgaKeyEvt.reg_offset = 0x2;
	
		
	sendEventToDev((char *)FPGAKEYDEV, EV_RD_FPGA_KEY, (void *)&rdFpgaKeyEvt, sizeof(EV_RD_FPGA_KEY_TYPE));
	//sendEvent(SVC_ID_DEV_FPGATEST, EV_WR_FPGA_REG, (void *)&wrFpgaRegEvt, sizeof(EV_WR_FPGA_REG_TYPE));
	
	
	return 0;
}

void TestService6::evtHandler(EVENT_HEADER_TYPE *event)
{
	EV_RD_FPGA_KEY_RES_TYPE *rdFpgaKeyResEvt;
	int64_t diff;
	
	printf("\nevent %d handler:\n", event->code);

	rdFpgaKeyResEvt = (EV_RD_FPGA_KEY_RES_TYPE *)event;

	diff = rdFpgaKeyResEvt->header.received - rdFpgaKeyResEvt->header.sent;
	printf("command use %lld \n", diff);

	
	printf("0x%x = %x\n", rdFpgaKeyResEvt->reg_offset, rdFpgaKeyResEvt->val);
	
	
	
}


extern int timer_test_done;

TestService7::TestService7(SVCID id,int priority,bool detach,size_t stack,os_thread_data_t arg)
:ECService(id, priority, detach, stack, arg)
{
	timer_expired_count = 0;
}

int  TestService7::initialize()
{

	return 0;
}


int TestService7::threadInitialize()
{

	runTest();
	
	return 0;
}

void TestService7::evtHandler(EVENT_HEADER_TYPE *event)
{
	/*
	int64_t diff;
	
	printf("\nevent %d handler\n", event->code);

	diff = event->received - event->sent;
	printf("event use %lld \n", diff);
	*/
	
	if (3000 == event->code) {
		timer_expired_count++;
	}	
}

void TestService7::runTest()
{
	EVENT_HEADER_TYPE *ev = NULL;
	int64_t diff, sum, time_start, time_end;
 	uint32_t ev_code, ev_code1, interval_time, count;
	int ret, ret1, idx;
	

	
	TEST_CATEGORY("timer Test");
	TEST_INIT(1);

	/************interval timer test************************/
	sum = 0;
	idx = count = 100;
	interval_time = 100;
	ev_code = 1000;

	while (idx--) {
		time_start = ECL::get_epoch_time_nano();
		timerStart(ev_code, interval_time, TIMER_OPT_ONCE);

		ret = waitEvent(ev_code, &ev, 150);
		time_end = ECL::get_epoch_time_nano();
		sum += time_end - time_start;
		
	}
	diff = sum / count;
	TEST((ret >= 0) && ( diff < 103 * 1000 * 1000), 
		"timer interval time test. "
		"timer is %d ms, real interval: %d avg  %lld", interval_time, count, diff);

	ret = timerStop(ev_code);

	/************timer delete test************************/
	interval_time = 200;
	ev_code = 2000;
	timerStart(ev_code, interval_time, TIMER_OPT_ONCE);
	usleep(100 * 1000);

	ret = timerStop(ev_code);
	ret1 = waitEvent(ev_code, &ev, 150);
	TEST((ret >= 0) && ( ret1 < 0), "timer delete test");
	

	/************many timer test************************/
	interval_time = 200;
	ev_code = 1000;
	timerStart(ev_code, interval_time, TIMER_OPT_ONCE);
	
	interval_time = 500;
	ev_code1 = 2000;
	ECL::ec_timer_start(ev_code1, interval_time, TIMER_OPT_ONCE);
	ret = waitEvent(ev_code, &ev, 250);
	ret1 = waitEvent(ev_code1, &ev, 550);
	TEST((ret >= 0) && (ret1 >= 0), "many timer test");
	timerStop(ev_code);
	timerStop(ev_code1);

	/************interval timer test************************/
	interval_time = 100;
	ev_code = 3000;
	idx = count = 10;
	//sum = (interval_time * count + count * 2) * 1000;
	timerStart(ev_code, interval_time, TIMER_OPT_INTERVAL);
	while (idx--) {
		ret = waitEvent(ev_code, &ev, interval_time + 3);
		if (ret >= 0) {
			timer_expired_count++;	
		}
	}
	TEST((timer_expired_count == count), "interval timer test. "
					"interval %d ms timer expired %d expectation expired %d", 
					interval_time,  timer_expired_count, count);
	timerStop(ev_code);

	/************timer fault-tolerant test************************
	ev_code = 3000;
	ret = timerStart(ev_code, 0, TIMER_OPT_INTERVAL);
	TEST((ret != 0), "timer fault-tolerant test. interval time ");
	ret = timerStart(ev_code, 100, 1000);
	TEST((ret != 0), "timer fault-tolerant test. option");
	ret = timerStop(1000);
	TEST((ret != 0), "timer fault-tolerant test. delet not used timer_id");
	*/
	/***********test timer delete in service's on_exit**************/
	ret = timerStart(ev_code, 100, TIMER_OPT_ONCE);
	ret = timerStart(ev_code, 200, TIMER_OPT_ONCE);
	ret = timerStart(ev_code, 300, TIMER_OPT_ONCE);
	

	timer_test_done = 1;
}





TestService8::TestService8(SVCID id,int priority,bool detach,size_t stack,os_thread_data_t arg)
:ECService(id, priority, detach, stack, arg)
{
	logMsg(LOG_LEVEL_ERR, "%s \n", __FUNCTION__);
	logMsg(LOG_LEVEL_ERR, "%s \n", __FUNCTION__);
	logMsg(LOG_LEVEL_ERR, "%s \n", __FUNCTION__);
	logMsg(LOG_LEVEL_ERR, "%s \n", __FUNCTION__);
	logMsg(LOG_LEVEL_ERR, "%s \n", __FUNCTION__);
}

int  TestService8::initialize()
{
	registerEvent(EV_FW_LOGGER, (EventHandler)&TestService8::evtHandler);
	
	logMsg(LOG_LEVEL_WARNING, "%s\n", __FUNCTION__);
	logMsg(LOG_LEVEL_WARNING, "%s\n", __FUNCTION__);
	logMsg(LOG_LEVEL_WARNING, "%s\n", __FUNCTION__);
	logMsg(LOG_LEVEL_WARNING, "%s\n", __FUNCTION__);
	logMsg(LOG_LEVEL_WARNING, "%s\n", __FUNCTION__);
	
	return 0;
}


int TestService8::threadInitialize()
{
	EV_RD_FPGA_KEY_RES_TYPE rdFpgaKeyResEvt;

	logMsg(LOG_LEVEL_INFO, "%s\n", __FUNCTION__);
	logMsg(LOG_LEVEL_INFO, "%s\n", __FUNCTION__);
	logMsg(LOG_LEVEL_INFO, "%s\n", __FUNCTION__);
	logMsg(LOG_LEVEL_INFO, "%s\n", __FUNCTION__);
	logMsg(LOG_LEVEL_INFO, "%s\n", __FUNCTION__);


		
	rdFpgaKeyResEvt.reg_offset = 0xFFFF; 
	rdFpgaKeyResEvt.val = 0xFFFF;
	sendEvent(SVC_ID_TEST8, EV_RD_FPGA_KEY_RES, 
		(void *)&rdFpgaKeyResEvt, sizeof(EV_RD_FPGA_KEY_RES_TYPE));	


	rdFpgaKeyResEvt.reg_offset = 0xFFFE; 
	rdFpgaKeyResEvt.val = 0xFFFE;
	sendEvent(SVC_ID_TEST8, EV_RD_FPGA_KEY_RES, 
		(void *)&rdFpgaKeyResEvt, sizeof(EV_RD_FPGA_KEY_RES_TYPE));	


	
	
	return 0;
}

void TestService8::evtHandler(EVENT_HEADER_TYPE *event)
{
	printf("\n code %d len %d \n", event->code, event->length);
	printf("%s", (char *)event + sizeof(EVENT_HEADER_TYPE));
	
	return;	
}








