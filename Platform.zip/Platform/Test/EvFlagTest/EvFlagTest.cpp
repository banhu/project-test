








#include <unistd.h>

#include "os_intf.h"
#include"TestFramework.h"
#include "../EvFlag.h"
#ifdef __cplusplus
extern "C" {
#endif


//os_thread_data_t runTest(os_thread_data_t arg);
os_thread_data_t rcv1(os_thread_data_t arg);
os_thread_data_t rcv2(os_thread_data_t arg);

static int status1 = 0;
static int status2 = 0;
static int status3 = 0;

static int counter1 = 0;
static int counter2 = 0;


static unsigned int flag1 = 0;
static unsigned int flag2 = 0;


#define FLAG_0 1<<0
#define FLAG_1 1<<1
#define FLAG_2 1<<2
#define FLAG_3 1<<3
#define FLAG_4 1<<4
#define FLAG_5 1<<5
#define FLAG_6 1<<6
#define FLAG_7 1<<7

static os_thread_t id_2 = 0;
static os_thread_t id_3 = 0;


#define FLAG_ALL FLAG_0|FLAG_1|FLAG_2|FLAG_3|FLAG_4|FLAG_5|FLAG_6|FLAG_7

EvFlag flag;


int create_flag_test() 
{
	int noCreate = 0;
	//os_thread_t id_1 = 0;

	//os_thread_t id_4 = 0;
	int priority = 100;
	size_t stack = 1024;
	int detach = 0;
	/*
	os_thread_create(noCreate,
					 &id_1,
					 priority,
					 stack,
					 runTest,
					 NULL,
					 detach);
*/
	os_thread_create(noCreate,
					 &id_2,
					 priority+1,
					 stack,
					 rcv1,
					 NULL,
					 detach);

	os_thread_create(noCreate,
					 &id_3,
					 priority+1,
					 stack,
					 rcv2,
					 NULL,
					 detach);

	
	return 0;
}

void run_flag_test()
{
	sleep(1);
    TEST_INIT(1);
	TEST_CATEGORY("Event Flag");
	flag.clear(FLAG_ALL);
	flag.post(FLAG_1);
	TEST(counter1 == 0, "flag should be keep suspend");
	flag.post(FLAG_0);
	
	usleep(100);
	TEST(counter1 == 1, "suspend should be wakeup");	
	TEST(status1== 0, "status need to be 0");	
	TEST(flag1 == (FLAG_1|FLAG_0), "flag need to be set");	
	usleep(100);
	TEST(flag.inquiry()== FLAG_1, "flag has been cleared");

	flag.post(FLAG_3);
	usleep(100);
	TEST(counter1 == 2, "suspend should be wakeup");	
	TEST(status1== 0, "status need to be 0");	
	TEST(flag1 == (FLAG_1|FLAG_3), "flag need to be set");	
	usleep(100);
	TEST(flag.inquiry()== 0, "flag has been cleared");

	flag.post(FLAG_3);
	usleep(100);
	TEST(counter1 == 3, "suspend should be wakeup");	
	TEST(status1== 0, "status need to be 0");	
	TEST(flag1 == FLAG_3, "flag need to be set");	
	TEST(flag.inquiry()== 0, "flag has been cleared");

	TEST(status2 < 0, "rcv 2 thread should be returned with timeout");
	flag.post(FLAG_2);
	usleep(100);
	TEST(counter2 == 2, "suspend should be wakeup");	
	TEST(status3== 0, "status need to be 0");	
	TEST(flag2 == FLAG_2, "flag need to be set");	
	TEST(flag.inquiry()== 0, "flag has been cleared");


	TEST(counter1 == 4, "suspend should be wakeup");	
	TEST(status1== 0, "status need to be 0");	
	TEST(flag1 == FLAG_2, "flag need to be set");	
	TEST(flag.inquiry()== 0, "flag has been cleared");
	
	TEST_DONE();
}



os_thread_data_t rcv1(os_thread_data_t arg)
{
	status1 = flag.pend(FLAG_0, EvFlag::FLAG_AND, &flag1);		
	flag.clear(FLAG_0);
	counter1++;

	status1 = flag.pend(FLAG_1|FLAG_3, EvFlag::FLAG_AND, &flag1);		
	flag.clear(FLAG_1|FLAG_3);
	counter1++;
	while(1)
	{
		status1 = flag.pend(FLAG_1|FLAG_3|FLAG_2, EvFlag::FLAG_OR, &flag1);		
		flag.clear(flag1&(FLAG_1|FLAG_3|FLAG_2));
		counter1++;
	}
	return 0;
}

os_thread_data_t rcv2(os_thread_data_t arg)
{
	while(1)
	{
		status2 = flag.pend(FLAG_2, EvFlag::FLAG_AND, &flag2, 1000);
		flag.clear(FLAG_2);
		counter2++;
	}
	return 0;
}



void clear_flag_test()
{
	os_thread_cancel(id_2);
	os_thread_cancel(id_3);
}



#ifdef __cplusplus
}
#endif


