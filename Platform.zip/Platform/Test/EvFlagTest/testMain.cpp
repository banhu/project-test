


#include"ecl.h"
#include "TestFramework.h"
#include <unistd.h>
#include "TestService.h"
#include "timer.h"

#ifdef __cplusplus
extern "C" {
#endif
extern int create_flag_test();
extern void run_flag_test();
extern void clear_flag_test();

#ifdef __cplusplus
}
#endif

int timer_test_done = 0;

int main(int argc, char *argv[])
{
	//int ret;
	//create_flag_test();

	//run_flag_test();

	//clear_flag_test();

	/*
	TestService7 *tmpService =
	new TestService7(SVC_ID_TEST7, 0, 1, 10000, 0);

    ECL::start_services();

	

	while (!timer_test_done) {
		;
	}

	delete tmpService;
	
	TEST_CATEGORY("timer Test");
	TEST_INIT(1);
	ret = ECL::timerStart(1000, 100, TIMER_OPT_INTERVAL);
	TEST((ret != 0), "timer fault-tolerant test. not in service thread");

	usleep(1000);
	
	ECL::timer_destroy();
	*/

	//TestService8 *tmpService =
	new TestService8(SVC_ID_TEST8, 0, 1, 10000, 0);

	ECL::start_services();

	ECL::monitor_run();

	ECL::logger_exit();
}





