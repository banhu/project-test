

#include "AdcComTest.h"
#include "TestFramework.h"
#include <unistd.h>
#include "malloc.h"
#include "ev_sr_status.h"



AdcComTest::AdcComTest(SVCID id,int priority,bool detach,size_t stack,os_thread_data_t arg)
:ECService(id, priority, detach, stack, arg)
{
}

int  AdcComTest::initialize()
{
	registerEvent(EV_RD_ADC_COMM_RES, (EventHandler)&AdcComTest::cbAdcComRes);
	return 0;
}


int AdcComTest::threadInitialize()
{

	EV_RD_ADC_COMM_TYPE rdAdcCommRegEvt;

	registerDevice((char *)ADCCOMMDEV, SVC_ID_DEV_ADC_COMM);
	
	
	rdAdcCommRegEvt.chan_mask = 0xFF;
	
		
	sendEventToDev((char *)ADCCOMMDEV, EV_RD_ADC_COMM, (void *)&rdAdcCommRegEvt, sizeof(EV_RD_ADC_COMM_TYPE));
	//sendEvent(SVC_ID_DEV_ADC_COMM, EV_RD_ADC_COMM, (void *)&rdAdcCommRegEvt, sizeof(EV_RD_ADC_COMM_TYPE));
	
	
	return 0;
}

void AdcComTest::cbAdcComRes(EV_RD_ADC_COMM_RES_TYPE *event)
{
	int  i;
	int64_t diff;
	
	printf("\nevent %d handler:\n", event->header.code);


	diff = event->header.received - event->header.sent;
	printf("command use %lld \n", diff);

	for (i = 0; i < 8; i++) {
		printf("%d = %d\n", i, event->channel_val[i]);
	}
}






