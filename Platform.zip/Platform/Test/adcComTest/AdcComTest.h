
#ifndef _ADC_COM_TEST_H_
#define _ADC_COM_TEST_H_

#include "os_intf.h"
#include "ECService.h"
#include "Macho.h"
#include "timer.h"

class AdcComTest : public ECService
{
public:
	explicit AdcComTest(SVCID id, int priority,
        bool detach, size_t stack,os_thread_data_t arg = NULL);
	~AdcComTest(){};

private:
	int initialize();
	int threadInitialize();
	void cbAdcComRes(EV_RD_ADC_COMM_RES_TYPE *event);

};
#endif //_ADC_COM_TEST_H_


















