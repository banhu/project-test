
#include <unistd.h>
//#include "TestFramework.h"
#include "TestService.h"



extern "C" int os_thread_test();

int timer_test_done = 0;
	
int main(int argc, char *argv[])
{
//    TEST_INIT(1);
//	os_thread_test();

    //new TestService(SVC_ID_TEST1, 0, 1, 10000, 0);
    
   // new TestService2(SVC_ID_TEST2, 0, 1, 10000, 0);

	//TestService3 *testservice = 
	//new TestService3(SVC_ID_TEST8, 0, 1, 10000, 0);

	new TestService4(SVC_ID_TEST7, 0, 1, 10000, 0);

//	new TestService5(SVC_ID_TEST7, 0, 1, 10000, 0);

//	new TestService8(SVC_ID_TEST7, 0, 1, 10000, 0);

	
//	new TestService7(SVC_ID_TEST7, 0, 1, 10000, 0);

    ECService::startAll();

	//testservice->test();

	

    ECL::monitor_run();
}




