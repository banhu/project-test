/**@file
 * Copyright (C) 2013, Sinovision Tech Ltd.
 * All rights reserved.
 *
 * @brief   This file defines the abstraction of the os calls
 *
 * @author  
 * @date 2013-3-1
 *
 */

#ifndef _OSINTF_H_
#define _OSINTF_H_


#include <pthread.h>
#include <string.h>
#include <stdint.h>

#ifdef __cplusplus
 extern "C" {
#endif


#ifndef FREE
#define FREE(x) if(x) { free(x); x=NULL; }
#endif


typedef  pthread_t os_thread_t;

typedef void *os_thread_data_t;
typedef os_thread_data_t (*os_thread_entry)(os_thread_data_t);


/*
*  thread specific data type
 */
typedef pthread_key_t os_thread_key_t;
/*
* create a thread specivic key
 */
#define os_thread_key_create(key, dest) pthread_key_create(key, dest)
/*
* get a thread's thread specific data
 */
#define os_thread_getspecific(key) pthread_getspecific(key)
/*
* set a thread's thread specific data
 */
#define os_thread_setspecific(key, value) pthread_setspecific(key, value)
/*
* get a thread's identifier.
 */
#define os_thread_self() pthread_self()
/*
* cancel a thread.
 */
#define os_thread_cancel(id) pthread_cancel(id)
/*
* compare two thread identifiers.
 */
#define os_thread_equal(id1, id2) pthread_equal(id1, id2)
/*
* exit from a thread.
 */
#define os_thread_exit(arg) pthread_exit(arg)

/*
* join  a thread.
 */
#define os_thread_join(id,retval) pthread_join(id, retval)

/*
* create a thread.
 */

typedef pthread_once_t os_thread_once_t;

 /** An initializer for a once control structure.
  */
#define os_thread_once_init PTHREAD_ONCE_INIT
 /** Call a function once for multiple threads.
  * @param guard The once guard structure.
  * @param func The function to be called once.
  */
#define os_thread_once(guard, func) pthread_once(guard, func)
 
#ifdef WIN32
 /** Return a pointer to the pthread data structure.
  * @param pthr The pthread structure
  */
#define os_thread_get(pthr)		pthr.p
 
 /** Init a pthread variable by seting it to 0
  * @param pthr The pthread variable to init
  */
#define os_thread_initvar(pthr)	pthr.p = 0
#else /* WIN32 */
#define os_thread_get(pthr)		pthr
#define os_thread_initvar(pthr)	pthr = 0
#endif /* WIN32 */

 int os_thread_create(int noCreate,
                     os_thread_t* id,
                     int priority,
                     size_t stack,
                     os_thread_entry entry,
                     os_thread_data_t arg,
                     int detach);

#define os_thread_self() pthread_self()


/**************************************
* semaphore definitions
**************************************/
#include <semaphore.h>
#include <time.h>

typedef sem_t os_sem_t;

#define os_sem_init(sem, value) sem_init(&(sem), 0, value)

#define os_sem_post(sem) sem_post(&(sem))

#define os_sem_wait(sem) sem_wait(&(sem))


#define os_sem_timedwait(sem, timeout) sem_timedwait(&(sem), timeout)

#define os_sem_destroy(sem) sem_destroy(&(sem))

#define os_sem_count(sem, count) sem_getvalue(&(sem),&(count))


/**************************************
* mutex definitions
**************************************/

/** the mutex type.
 */
typedef pthread_mutex_t os_mutex_t;

#define os_mutex_init(pmutex) pthread_mutex_init(&(pmutex), NULL)



/*
* initialize a recursive mutex
* recursive mutex allows mutex to be locked more than once without getting to a deadlock
*/

#define PTHREAD_MUTEX_RECURSIVE PTHREAD_MUTEX_RECURSIVE_NP

int os_mutex_init_recursive(os_mutex_t *mutex);

#define os_recursive_mutex_init(mutex) os_mutex_init_recursive(&(mutex))

#define os_mutex_lock(mutex) pthread_mutex_lock(&(mutex))

#define os_mutex_unlock(mutex) pthread_mutex_unlock(&(mutex))

#define os_mutex_destroy(mutex) pthread_mutex_destroy(&(mutex))

#define os_mutex_trylock(mutex) pthread_mutex_trylock(&(mutex))

#ifdef __cplusplus
}
#endif

#endif /* OSINTF_H_ */
