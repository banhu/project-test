/**@file
 * Copyright (C) 2013, Sinovision Tech Ltd.
 * All rights reserved.
 *
 * @brief   This file implement the abstraction of the os calls
 *
 * @author  
 * @date 2013-3-1
 *
 */

#include <assert.h>

#include "os_intf.h"




/** Initialize a recursive mutex
 * @param mutex The mutex to initialize.
 */
int os_mutex_init_recursive(os_mutex_t *mutex)
{
    pthread_mutexattr_t attr;
    int status;

    status = pthread_mutexattr_init(&attr);
    assert(status == 0 && "pthread_mutexattr_init failed");

    status = pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_RECURSIVE);
    assert(status == 0 && "pthread_mutexattr_settype failed");

    status = pthread_mutex_init(mutex, &attr);
    assert(status == 0 && "pthread_mutex_init failed");


    return 0;
}


int os_thread_create(int noCreate,
                     os_thread_t* id,
                     int priority,
                     size_t stack,
                     os_thread_entry entry,
                     os_thread_data_t arg,
                     int detach)
{
    int status;
    pthread_attr_t attr;
    memset(&attr, 0, sizeof(attr));
    status = pthread_attr_init(&attr);
    assert(status == 0 && "pthread_attr_init failed");

#if !defined(__linux__)
    // Cannot set the stack size under Linux (there is no need to).
    status = pthread_attr_setstacksize(&attr, stack);
    assert(status == 0 && "pthread_attr_setstacksize failed");
#endif

    status = pthread_attr_setschedpolicy(&attr, SCHED_RR);
    assert(status == 0 && "pthread_attr_setschedpolicy failed");

    int value = detach ? PTHREAD_CREATE_DETACHED : PTHREAD_CREATE_JOINABLE;
    status = pthread_attr_setdetachstate(&attr, value);
    assert(status == 0 && "pthread_attr_setdetachstate failed");
    if (noCreate)
    {
        // This thread is already active, get its id.
        *id = os_thread_self(); //huyf delete 2014-10-22
    }
    else
    {
        // Create the thread.
        status = pthread_create(id, &attr, entry, arg);
        assert(status == 0 && "pthread_create failed");
    }

    int pval = sched_get_priority_max(SCHED_RR);
    if (priority > pval)
    {
        priority = pval;
    } else {
        pval = sched_get_priority_min(SCHED_RR);
        if (priority < pval) {
            priority = pval;
        }
    }

    /* Set the thread priority.
     * Under Linux, this call will fail unless the program is suid root.
     * Therefore we will not check the error status.
     */
    struct sched_param param;
    param.sched_priority = priority;
    int policy = SCHED_RR;

    pthread_setschedparam(*id, policy, &param);

    if (noCreate)
    {
        // Call this thread's entry function.
        entry(arg);
    }
    return 0;
}

