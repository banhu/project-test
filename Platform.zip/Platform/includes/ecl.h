/**@file 
 * Copyright (C) 2013, Sinovision Tech Ltd.
 * All rights reserved.
 *
 * @brief   This file defines the public C interface of event communication library
 *
 * @author  
 * @date 2013-4-1
 *
 */
#ifndef _ECL_H_
#define _ECL_H_

#include <stdio.h>
#include <stdint.h>
#include <stdarg.h>

#include "os_intf.h"
#include "ev_base.h"
#include "ecl_events.h"
#include "monitor.h"


enum TIMER_OPTION
{
    TIMER_OPT_INTERVAL = 1,
    TIMER_OPT_ONCE = 2,

	/*add code  2017-5-3*/
	TIMER_OPT_INTERVAL_NO_LOG = 3,
	TIMER_OPT_ONCE_NO_LOG = 4,
};

enum TIMER_STATUS
{
	TIMER_STATUS_NONEXITENT = 0,
    TIMER_STATUS_ACTIVE = 1,
    TIMER_STATUS_EXPIRED = 2,
};

#ifdef __cplusplus
 extern "C" {
 namespace ECL{
#endif



void* create_service(SVCID id, int priority, int detach, size_t stack,
                         int (*initialize)(os_thread_data_t),
                         int (*threadinitialize)(os_thread_data_t),
                         void (*dispatch)(EVENT_HEADER_TYPE*, void *),
                         os_thread_data_t data);

void pre_thread();

int stop_service(SVCID id);


int kill_service(SVCID id);

int start_service(SVCID id, int noCreate);

void start_services(void);

void stop_services(void);

int get_processID(int appId);


/** send an event to a destinition service as another service
 * for monitor debug command only
 * @param to target service id
 * @param event pointer of the event data block
 * @param size size of the data block
 * @param not_log
 */
int send_event_from(SVCID from, SVCID to, EVENT_HEADER_TYPE *event, size_t size, int not_log);

/**Just for UnitTest to run tcp_send*/
int send_event_from_tcp(SVCID from, SVCID to, EVENT_HEADER_TYPE *event, size_t size, int not_log);

/***/
int send_event(SVCID to, EVENT_HEADER_TYPE *event, size_t size, int not_log);

/** send an event to a destinition device
 * this the interface of event comm lib, the prototype is defined in ecl.h
 * @param dev_name to target device name
 * @param event pointer of the event data block
 * @param size size of the data block
 * @param is_log
 */
int send_event_todev(char *dev_name, EVENT_HEADER_TYPE *event, size_t size, int not_log);

/**
  *find fd by dev id .
  *@param dev_id
  *@return the fd we find,-1 we don't find it;
 */
int find_fd_by_id(int dev_id);

/**
  *register device to service's devs
  *@param dev_name
  *@param dev_id
  *@return -1 is failed,0 is successful
 */
int register_device(char *dev_name, int dev_id);

/**
  *remove device from service's devs
  *@param dev_name
  *@return -1 is failed,0 is successful
 */
int remove_device(char *dev_name);

/**
  *remove device from service's devs
  *@param dev_id
  *@return -1 is failed,0 is successful
 */
int remove_device_byid(int dev_id);


/**set the name of current process
*/
char* set_process_name(char *name);

/**get the sv_id  by sv_name
 * if the return is SVC_ID_UNKNOWN please check the name if is exist
*/
SVCID get_service_id_by_name(char *name);

/**start the debug monitor
*/
extern void monitor_run();

/**start the telnet debug
*/
extern void telnet_run(PROCESSID pid);

/**initialize the memory pool
*/
extern void buffer_init();

/**get a memory buffer from mem pool
*/
extern char * buffer_get(size_t n);

/**return the buffer to the pool
*/
extern void buffer_release(char *data);

/**add a command and process handler to the debug monitor
*/
extern int insert_command(char *cmd_name, CMD_FUN_T cmd_fun, char *help);
/**remove a command and process handler from the debug monitor
*/
extern int delete_command(char *cmd_name);

/** waiting until next event coming or timeout
*/
void* receive_message(int*time_elapsed, int timeout_ms);

/** waiting until next event coming or timeout
*/
void* wait_message(unsigned int code,int*time_elapsed, int timeout_ms);

/** get ns since 1970-1-1 as 64 bit integer data
 */
extern uint64_t get_epoch_time_nano();

/**
*@bref start a timer
*@code timer respond event code when timer expired
*@tmo_ms timer expiration time
*@option timer option
*
*@return zero is successful,other is failed
*/
int ec_timer_start(uint32_t code, uint32_t tmo_ms, uint32_t option);

/**
*@bref stop a timer
*@ev_code  event code which timer respond to service
*
*@return zero is successful,other is failed
*/
int ex_timer_stop(uint32_t ev_code);

/**
*@bref get a timer's status
*@code timer respond event code when timer expired
*
*@return TIMER_STATUS
*/
int ec_timer_status(uint32_t code);

/** init the timer
 * this should be called after all service created and started
 */
void timer_init(void);

/**
* destroy all timer
*/
void timer_destroy(void);

/**record log message
@level  log level
@fmt	log content
*/
void log_msg(unsigned int level, const char *fmt, ...);


/**record log message
@level  log level
@fmt	log content
*/
void log_raw(unsigned int level, const char *fmt, va_list arg);


/**exit logger*/
void logger_exit(void);
/**display event header*/
void disp_ev_header(const EVENT_HEADER_TYPE *event);

/** create new connection info use target svc id,and auto connect.
 * @param to target service id
 * @param en_probe is enable probe package
 */
void connection_to_svc(SVCID to, int en_probe);

/**This Function just for UnitTest add by huyf
 * create new connection info use target svc id, don't check if it is in process,
 *@param to target service id
 *@param en_probe is enable probe package
 */
void connection_svc_from_to(SVCID from, SVCID to, int en_probe);

/**
*process device ioctl
*@param dev_id  device id
*@param cmd ioctl command
*@arg command's parameter
*
*@return zero is successful
*/
int proc_dev_ioctl(int dev_id, int cmd, unsigned long arg);

/** get ns since 1970-1-1 as 64 bit integer data
 * huyf delete 2014-10-15
 */
//uint64_t get_epoch_time_nano();



extern SVCID self_id();


int main_thread_suspend();

/**
*@bref execute a shell
*@binFile  shell command or shell file
*
*@return zero is successful,other is failed
*/
int execShell(char *shellCmd);

/**
*@bref execute a bin
*@binFile  Binary executable file
*
*@return zero is successful,other is failed
*/
int execBin(char *binFile);

/**
*@bref execute a bin
*@binFile  Binary executable file
*@arg  arg(0),arg[1]...
*
*@return zero is successful,other is failed
*/
int execBinEx(const char *binFile, const char *arg, ...);

/**
*@bref kill bin 
*@binFile  Binary executable file
*
*@return zero is successful,other is failed
*/
int killBin(char *binFile);

/**
*@bref insmod a module
*@moduleFile  modle file
*
*@return zero is successful,other is failed
*/
int insModule(char *moduleFile);

/**
*@bref rmmod a module
*@moduleFile  module file
*
*@return zero is successful,other is failed
*/
int rmModule(char *moduleFile);

/**
*@bref is bin executed 
*@binFile  Binary executable file
*
*@return zero is bin executed,other is not
*/
int isBinRun(char *binFile);

/**
*@bref is module installed 
*@moduleFile  modle file
*
*@return zero is module installed,other is not
*/
int isModuleIns(char *moduleFile);


void handerStopSig(int svc_id);

//send ver xml to scctl.
int send_ver_to_ctl(SVCID to);

//xml parser function
void* xmlEncryptFile(char* file);

//set fpga ver
void set_fpga_ver(EV_SS_FPGA_REPORT_VER_TYPE *ev);

//char* set_process_name(char *name);

#ifdef __cplusplus
}
}
#endif

#endif //_ECL_H_


