/**@file 
 * Copyright (C) 2013, Sinovision Tech Ltd.
 * All rights reserved.
 *
 * @brief   This file defines the public C interface of event communication library
 *
 * @author  
 * @date 2013-4-1
 *
 */
#ifndef _EVENT_META_H_
#define _EVENT_META_H_

#include "stdint.h"

#ifdef __cplusplus
 extern "C" {
#endif



enum
{
    VAR_TYPE_INT8 = 1,
    VAR_TYPE_UINT8,
    VAR_TYPE_INT16,
    VAR_TYPE_UINT16,    
    VAR_TYPE_INT32,
    VAR_TYPE_UINT32,    
    VAR_TYPE_INT64,
    VAR_TYPE_UINT64,    
    VAR_TYPE_FLOAT,
    VAR_TYPE_DOUBLE,
    VAR_TYPE_STRING,
    VAR_TYPE_END,
};

typedef struct 
{
    int offset; // offset bytes from the base of the struct
    int size;  // num of element for array
    int type;  // type index to find out the struct table
    int depth; // depth for iteration
    const char *name;
}STRUCT_META_TYPE;


typedef struct 
{
	int32_t code;
	int32_t size;
    const char *name;
	const char *type;
    const STRUCT_META_TYPE *meta;
}EVENT_META_TYPE;



extern const EVENT_META_TYPE event_meta_info[];
extern uint32_t meta_info_size;




#ifdef __cplusplus
}
#endif

#endif //_ECL_H_


