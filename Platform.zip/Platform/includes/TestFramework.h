/** @file
 * this file defines the test framwork of platform
 */

#ifndef _TestFramework_h_
#define _TestFramework_h_

#include <stdio.h>
#include <stdlib.h>

__attribute__ ((unused)) static int unittest_count;                          ///< The test counter.
__attribute__ ((unused)) static int unittest_failures;                       ///< The failure counter.
__attribute__ ((unused)) static int unittest_verbose;                        ///< The test verbosity control.
__attribute__ ((unused)) static const char *unittest_category = "";          ///< The current test category.


/** Initialize the test harness.
 */
#define TEST_INIT(verbose)                                              \
    do {                                                                \
        unittest_verbose = verbose;                                     \
        fprintf(stdout,"\n\n********************************************************* \n");                     \
		fprintf(stdout,"unit test %s started \n",unittest_category );	\
		fprintf(stdout,"started from %s:%d \n",__FILE__, __LINE__);	        \
        fprintf(stdout,"********************************************************* \n");     \
    } while (0)

/** Set the test category.
 */
#define TEST_CATEGORY(name)                                             \
    do {                                                                \
        unittest_category = #name;                                      \
    } while (0)

/** Perform a test.
 */
#define TEST(cond, ...)                                                 \
    do {                                                                \
        ++unittest_count;                                               \
        if (!(cond)) {                                                  \
            fprintf(stdout, "FAIL: %s: %s:%d ",unittest_category,      \
                                strrchr (__FILE__, '/') == 0 ? __FILE__: strrchr (__FILE__, '/') + 1, __LINE__ );    \
            fprintf(stdout, __VA_ARGS__);                               \
            fprintf(stdout, "\n");                                      \
            ++unittest_failures;                                        \
        } else if (unittest_verbose) {                                  \
            fprintf(stdout, "PASS: %s: %s:%d ",unittest_category,      \
                                strrchr (__FILE__, '/') == 0 ? __FILE__: strrchr (__FILE__, '/') + 1, __LINE__ );    \
            fprintf(stdout, __VA_ARGS__);                               \
            fprintf(stdout, "\n");                                      \
        }                                                               \
    } while (0)

/** Complete testing.
 */
#define TEST_DONE()                                                     \
    do {                                                                \
        fprintf(stdout,"\n\n********************************************************* \n");                     \
		fprintf(stdout,"unit test %s completed \n",unittest_category );	\
		fprintf(stdout,"completed at %s:%d \n",__FILE__, __LINE__);	        \
        fprintf(stdout, "    total tests: %d \n", unittest_count);          \
        fprintf(stdout, "    test(s) failed: %d\n", unittest_failures);   \
        fprintf(stdout,"********************************************************* \n");                     \
        if (unittest_failures > 0) {                                    \
			fprintf(stderr,"unit test %s completed \n",unittest_category ); \
			fprintf(stderr,"completed at %s:%d \n",__FILE__, __LINE__); 		\
			fprintf(stderr, "	 total tests: %d \n", unittest_count);			\
			fprintf(stderr, "	 test(s) failed: %d\n", unittest_failures);	\
            /*exit(EXIT_FAILURE);      */                                   \
        } else {                                                        \
            /*exit(EXIT_SUCCESS);  */                                       \
        }                                                               \
    } while (0)

#endif  // _TestFramework_h_
