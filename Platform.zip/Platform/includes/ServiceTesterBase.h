/** @file
 * this file defines the tester base class
 */

#ifndef __SERVICE_TESTER_BASE__
#define __SERVICE_TESTER_BASE__

#include "ECService.h"

class ServiceTesterBase:public ECService
{
public:
	explicit ServiceTesterBase(SVCID id, int priority,bool detach, size_t stack)
	:ECService(id, priority, detach, stack)
    {
        
    } ;  

	~ServiceTesterBase(){};

    bool testDone(){return _testDone;}

protected:
	int initialize(){return 0;};
	int threadInitialize()
    {
        _testDone=false;
        testInit();
    	runTest();
       	_testDone=true;
    	return 0;
    }
	virtual void runTest() = 0;
    virtual void testInit() = 0;

    bool _testDone;
		
};

#endif  // __SERVICE_TESTER_BASE__