/**@file:   PlatformTimerTest.cpp 
 * Copyright (C) 2015, Sinovision Tech Ltd.
 *
 * @brief:
 *
 * @author: huyf
 * @date:   2015-05-29 12:05:38
 * @email:  yongfei_hu@163.com
 * @website:http://www.fuxiwan.com
 *
 */


#include <unistd.h>
#include "gtest/gtest.h"
#include "PlatformTimerTest.h"

extern "C"{
extern int parse_run_command(const char *cmd_line, int len);
}

PlatformTimerTest::PlatformTimerTest(SVCID id,int priority,bool detach,size_t stack,TestControl *ss)
:ServiceTesterBase(id, priority, detach, stack)
{
	sut = ss;
	sutId= ss->getID();

}

void PlatformTimerTest::runTest()
{

	const char *timer = "timer show all";
	parse_run_command(timer,14);

	EVENT_HEADER_TYPE *ev = NULL;
	int64_t diff, sum, time_start, time_end;
 	uint32_t ev_code, ev_code1, interval_time, count;
	int ret, ret1, idx;
	uint32_t timer_expired_count = 0;
	/************interval timer test************************/
	sum = 0;
	idx = count = 100;
	interval_time = 100;
	ev_code = 1000;

	while (idx--) {
		time_start = ECL::get_epoch_time_nano();
		timerStart(ev_code, interval_time, TIMER_OPT_ONCE);

		ret = waitEvent(ev_code, &ev, 150);
		time_end = ECL::get_epoch_time_nano();
		sum += time_end - time_start;

	}
	diff = sum / count;
	EXPECT_TRUE((ret >= 0));
	printf("diff = %lld\n", diff);
	EXPECT_TRUE((diff < 110 * 1000 * 1000));

	ret = timerStop(ev_code);
	ECL::timer_destroy();
	/************timer delete test************************/
	interval_time = 200;
	ev_code = 2000;
	timerStart(ev_code, interval_time, TIMER_OPT_ONCE);
	usleep(100 * 1000);

	ret = timerStop(ev_code);
	ret1 = waitEvent(ev_code, &ev, 150);
	EXPECT_TRUE((ret >= 0));
	EXPECT_TRUE((ret1 < 0));


	/************many timer test************************/
	interval_time = 200;
	ev_code = 1000;
	timerStart(ev_code, interval_time, TIMER_OPT_ONCE);

	interval_time = 500;
	ev_code1 = 2000;
	ECL::ec_timer_start(ev_code1, interval_time, TIMER_OPT_ONCE);
	ret = waitEvent(ev_code, &ev, 250);
	ret1 = waitEvent(ev_code1, &ev, 550);
	EXPECT_TRUE((ret >= 0));
	EXPECT_TRUE((ret1 >= 0));
	timerStop(ev_code);
	timerStop(ev_code1);
	parse_run_command(timer,14);

	/************interval timer test************************/
	interval_time = 100;
	ev_code = 3000;
	idx = count = 10;
	//sum = (interval_time * count + count * 2) * 1000;
	timerStart(ev_code, interval_time, TIMER_OPT_INTERVAL);
	while (idx--) {
		ret = waitEvent(ev_code, &ev, interval_time + 10);
		if (ret >= 0) {
			timer_expired_count++;
		}
	}
	printf("timer_expired_count = %u\n", timer_expired_count);
	EXPECT_TRUE((timer_expired_count == count));

	timerStop(ev_code);

	/************timer fault-tolerant test************************
	ev_code = 3000;
	ret = timerStart(ev_code, 0, TIMER_OPT_INTERVAL);
	TEST((ret != 0), "timer fault-tolerant test. interval time ");
	ret = timerStart(ev_code, 100, 1000);
	TEST((ret != 0), "timer fault-tolerant test. option");
	ret = timerStop(1000);
	TEST((ret != 0), "timer fault-tolerant test. delet not used timer_id");
	*/
	/***********test timer delete in service's on_exit**************/
	//ret = timerStart(ev_code, 100, TIMER_OPT_ONCE);
	//ret = timerStart(ev_code, 200, TIMER_OPT_ONCE);
	//ret = timerStart(ev_code, 300, TIMER_OPT_ONCE);
	/**
	 * here is a bug that some times when the pthread_cancel there not run pthread_key on_exit,
	 * so it isn't kill the timer which is running, when the timer is timeout, it will send a message,
	 * but now, the service is killed, so the send_event will not find the es_info, then the unittest break
	 */

	parse_run_command(timer,14);
	//usleep(400000);
}

TEST(PlatformTimerTest, Timer)
{
 	usleep(50000);

 	TestControl *testCtrl = new TestControl(SVC_ID_TEST1, 0, 0, 10000, SVC_ID_TEST2,SVC_ID_TEST2);

 	PlatformTimerTest *tester = new PlatformTimerTest(SVC_ID_TEST2, 0, 0, 10000, testCtrl);
	const char *md_ipport1 = "md_ipport 300 127.0.0.1 61004";
	parse_run_command(md_ipport1,29);
	const char *md_ipport2 = "md_ipport 301 127.0.0.1 61005";
	parse_run_command(md_ipport2,29);
    ECService::startAll();

    while(!tester->testDone());
    ECL::stop_services();

    ECL::kill_service(SVC_ID_TEST1);
    ECL::kill_service(SVC_ID_TEST2);
 	usleep(3000);
    delete testCtrl;
  	usleep(3000);
    delete tester;
 	usleep(300000);
}

