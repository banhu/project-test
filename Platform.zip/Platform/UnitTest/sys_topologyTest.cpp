/**@file: sys_topologyTest.cpp
 * Copyright (C) 2014, Sinovision Tech Ltd.
 * All rights reserved.
 * 
 * @brief
 *
 * @author  huyf
 * @date    2014-08-26 15:08:42
 * Information for UnitTest
 * This test  include parserXml's test and sys_topology's test
 * the sys_topology is based on the parserXml.c
 * the parserXml has only one main entry to read the xml and build the topology tree,
 * another  function entry(process_port_by_id) is only used for telnet server,
 * the unit test for parserXml is find the information in the topology tree is TRUE or FALSE
 * so merge the two function in a unit test.
 */
#include"gtest/gtest.h"
extern "C"{
#include "buffer.h"
#include "sys_topology.h"
#include "rbtree.h"
#include "ecl.h"
extern RB_TREE_T node_tree;
extern RB_TREE_T process_tree;
extern RB_TREE_T sv_tree;
extern RB_TREE_T dev_tree;

extern char* process_name_by_id(PROCESSID pid);
extern char* node_name_by_id(NODEID nid);
extern char* get_ip(NODEID nid);
extern DEFAULT_SERVICE_INFO_TYPE *get_def_service(char *name);
extern PLATFORM_DEVICE_TYPE *get_def_device(char *dev_file_name);
extern PROC_INFO_TYPE *get_def_procInfo(char *name);
extern NODE_INFO_TYPE *get_def_nodeInfo(char *name);
extern int process_port_by_id(PROCESSID pid);
}

TEST(Sys_topologyTest, Sys_topologyInit )
{
	buffer_init();
	NODE_INFO_TYPE *node;
	PROC_INFO_TYPE *node1;
	DEFAULT_SERVICE_INFO_TYPE *node2;
	//PLATFORM_DEVICE_TYPE *node3;
	RB_NODE_T * result = NULL;
	//char name[] = {"oc"};
	//int ret;

	system("/usr/bin/python ../../../../../tool/build/encrypt.py /usr/sv/config/sysmap.xml ./sysmap.xml");
	system("mv ./sysmap.xml /usr/sv/config/sysmap.xml");

	init_sys_topo();

	//system("/usr/bin/python ../../../../../tool/build/encrypt.py /usr/sv/config/sysmap.xml ./sysmap.xml");
	//system("mv ./sysmap.xml /usr/sv/config/sysmap.xml");

	//result = node_name_by_id(NODE_ID_OC);
	result = rbtree_first(&node_tree);
	node = (NODE_INFO_TYPE *)result->item;
	//printf("node_tree:%s\n",node->name);
	EXPECT_EQ(strcmp(node->name,"oc"), 0);

	result = rbtree_first(&process_tree);
	node1 = (PROC_INFO_TYPE *)result->item;
	//printf("node_tree:%s\n",node1->name);
	EXPECT_EQ(strcmp(node1->name,"scanmgr"), 0);

	result = rbtree_first(&sv_tree);
	node2 = (DEFAULT_SERVICE_INFO_TYPE *)result->item;
	//printf("node_tree:%s\n",node2->name);
	EXPECT_EQ(strcmp(node2->name,"scanmgr"), 0);

	//result = rbtree_first(&dev_tree);
	//node3 = (PLATFORM_DEVICE_TYPE *)result->item;
	//printf("node_tree:%s\n",node3->dev_file_name);
	//EXPECT_EQ(strcmp(node3->dev_file_name,"/dev/fpga_test"), 0); // This point is wrong?

	disp_all_services(0,0);
	EXPECT_TRUE(true);
	system("/usr/bin/python ../../../../../tool/build/encrypt.py /usr/sv/config/sysmap.xml ./sysmap.xml");
	system("mv ./sysmap.xml /usr/sv/config/sysmap.xml");
}

TEST(Sys_topologyTest, lookup_service)
{
	SERVICE_TYPE *svc = NULL;
	svc = lookup_service(SVC_ID_SC);

	if (NULL == svc)
		EXPECT_TRUE(false);
	else
	{
		EXPECT_EQ(svc->id, SVC_ID_SC);
		EXPECT_STREQ(svc->name,"sc");
		EXPECT_EQ(svc->pid, PROC_ID_SC);
		EXPECT_STREQ(svc->pname,"sc");
		EXPECT_EQ(svc->nid, NODE_ID_SCU);
		EXPECT_STREQ(svc->nname,"scu");
   }

}

TEST(Sys_topologyTest, validate_service)
{
	char *name;
	name = validate_service(SVC_ID_GANTRY_DISP1);

	if (NULL == name)
		EXPECT_TRUE(false);
	else
		EXPECT_STREQ(name,"g_disp1");
}

TEST(Sys_topologyTest, get_service_name)
{
	char *name;
	name = get_service_name(SVC_ID_DAS);

	if (NULL == name)
		EXPECT_TRUE(false);
	else
		EXPECT_STREQ(name,"das");
}

TEST(Sys_topologyTest, process_name_by_id)
{
	char *name;
	name = process_name_by_id(PROC_ID_CTBOX);

	if (NULL == name)
		EXPECT_TRUE(false);
	else
		EXPECT_STREQ(name,"ctbox");
}

TEST(Sys_topologyTest, node_name_by_id)
{
	char *name;
	name = node_name_by_id(NODE_ID_RCU);

	if (NULL == name)
		EXPECT_TRUE(false);
	else
		EXPECT_STREQ(name,"rcu");
}

TEST(Sys_topologyTest, get_ip)
{
	char *name;
	name = get_ip(NODE_ID_DISP2);

	if (NULL == name)
		EXPECT_TRUE(false);
	else
		EXPECT_STREQ(name,"172.20.20.5");
}


TEST(Sys_topologyTest, get_def_service)
{
	DEFAULT_SERVICE_INFO_TYPE *node;
	char name[] = {"sc"};
	node = get_def_service(name);

	if (NULL == node)
		EXPECT_TRUE(false);
	else
	{
		EXPECT_EQ(node->id,SVC_ID_SC);
		EXPECT_EQ(node->port,60050);
	}
}
/*
TEST(Sys_topologyTest, get_def_device)
{
	PLATFORM_DEVICE_TYPE *node;
	char name[] = {"/dev/fpga_test"};
	node = get_def_device(name);

	if (NULL == node)
		EXPECT_TRUE(false);
	else
	{
		EXPECT_EQ(node->svc_id,SVC_ID_TEST8);
		EXPECT_EQ(node->dev_id,SVC_ID_DEV_FPGATEST);
	}
}
*/
TEST(Sys_topologyTest, get_def_procInfo)
{
	PROC_INFO_TYPE *node;
	char name[] = {"audio"};
	node = get_def_procInfo(name);

	if (NULL == node)
		EXPECT_TRUE(false);
	else
	{
		EXPECT_EQ(node->id,PROC_ID_AUDIO);
	}
}

TEST(Sys_topologyTest, get_def_nodeInfo)
{
	NODE_INFO_TYPE *node;
	char name[] = {"ctbox"};
	node = get_def_nodeInfo(name);

	if (NULL == node)
		EXPECT_TRUE(false);
	else
	{
		EXPECT_EQ(node->id,NODE_ID_CTBOX);
	}
}
TEST(Sys_topologyTest, get_service_id_by_name)
{
	char name[] = {"scanmgr"};
	EXPECT_EQ(SVC_ID_UNKNOWN, ECL::get_service_id_by_name(NULL));
	EXPECT_EQ(SVC_ID_OC_SCANMGR, ECL::get_service_id_by_name(name));
		//buffer_destroy();
}

TEST(ParserXmlTest, process_port_by_id)
{
	EXPECT_EQ(60002,process_port_by_id(PROC_ID_AX));
	EXPECT_EQ(60001,process_port_by_id(PROC_ID_SC));
	EXPECT_EQ(60008,process_port_by_id(PROC_ID_DAS));
	buffer_destroy();
}




