/**@file: testserver.cpp
 * Copyright (C) 2014, Sinovision Tech Ltd.
 * All rights reserved.
 *
 * @brief   
 *
 * @author  huyf
 * @date    2014-09-26 16:09:40
 *
 */
#include "testserver.h"


TestServer::TestServer(SVCID id,int priority,bool detach,size_t stack,os_thread_data_t arg)
:ECService(id, priority, detach, stack, arg)
{
	sid = id;
	//count = 0;
	srecvlog= 0;
	rrecvlog= 0;
	krecvlog= 0;
	drecvlog= 0;
	verrecvlog = 0;
	fpgarecvlog = 0;

}

int  TestServer::initialize()
{
	registerEvent(EV_SS_FAULT_RECOVERED, (EventHandler)&TestServer::evtHandler);
	registerEvent(EV_SS_ACTION_SETUP, (EventHandler)&TestServer::evtHandler);
	registerEvent(EV_RD_FPGA_KEY, (EventHandler)&TestServer::evtHandler);
	registerEvent(EV_SS_INIT_DONE, (EventHandler)&TestServer::evtHandler);
	registerEvent(EV_RD_FPGA_REG_RES, (EventHandler)&TestServer::evtHandler);
	registerEvent(EV_XML_VERSION, (EventHandler)&TestServer::evtHandler);
	//timerStart(EV_TEST_TIMER, 1000, TIMER_OPT_ONCE);
	//timerStart(EV_EVENT_TEST, 2000, TIMER_OPT_INTERVAL );
	return 0;
}


int TestServer::threadInitialize()
{
	registerDevice((char *)FPGATESTDEV, SVC_ID_DEV_FPGATEST);
	return 0;
}

void TestServer::evtHandler(EVENT_HEADER_TYPE *event)
{
	printf("sid:%d   event->rid: %d   event->code:%d\n", sid,event->rid, event->code);
	/*if(event->rid == sid){

		if(count<5)
		{
			ECL::send_event_from(event->rid,event->sid,event,event->length,0);
			count++;
		}
	}*/
	switch(event->code)
	{
		case EV_SS_ACTION_SETUP:
			srecvlog += 1;
			break;
		case EV_SS_FAULT_RECOVERED:
			rrecvlog += 1;
			break;
		case EV_RD_FPGA_KEY:
			krecvlog += 1;
			break;
		case EV_SS_INIT_DONE:
			drecvlog += 1;
			break;
		case EV_RD_FPGA_REG_RES:
			fpgarecvlog +=1;
			break;
		case EV_XML_VERSION:
			verrecvlog += 1;
		default:
			break;
	}
}
int TestServer::getlogval(int logname)
{
	switch(logname)
	{
		case 0:
			return srecvlog;
			break;
		case 1:
			return rrecvlog;
			break;
		case 2:
			return krecvlog;
			break;
		case 3:
			return drecvlog;
			break;
		case 4:
			return fpgarecvlog;
			break;
		case 5:
			return verrecvlog;
			break;
		default:
			return -1;
			break;
	}
}

int TestServer::setlogval(int logname, int val){
	switch(logname)
	{
		case 0:
		{
			 srecvlog = val;
			 return srecvlog;
			break;
		}
		case 1:
		{
			rrecvlog = val;
			return rrecvlog;
			break;
		}
		case 2:
		{
			krecvlog = val;
			return krecvlog;
			break;
		}
		case 3:
		{	drecvlog = val;
			return drecvlog;
			break;
		}
		case 4:
		{
			fpgarecvlog = val;
			return fpgarecvlog;
			break;
		}
		case 5:
		{
			verrecvlog = val;
			return verrecvlog;
			break;
		}
		default:
		{
			return -1;
			break;
		}
	}
}

int TestServer::recvlog(){
	srecvlog= 0;
	rrecvlog= 0;
	krecvlog= 0;
	drecvlog= 0;
	fpgarecvlog = 0;
	return 0;
}
