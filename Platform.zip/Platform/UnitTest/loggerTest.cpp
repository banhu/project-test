/**@file: loggerTest.cpp
 * Copyright (C) 2014, Sinovision Tech Ltd.
 * All rights reserved.
 *
 * @brief   
 *
 * @author  huyf
 * @date    2014-09-24 15:09:11
 * the test for log_msg will in the event unit test,because it need to get_es_info in pthread
 */

#include "gtest/gtest.h"
#include <string.h>
extern "C"{
#include "logger.h"
#include "EvGantryUIF.h"
#include "sys_topology.h"
extern int dump_to_terminal(int argc, char * const argv[]);
}

TEST(LoggerTest, log_event)
{
	buffer_init();
	logger_init();
	init_evet_meta_tree();

	EVENT_HEADER_TYPE * buf = (EVENT_HEADER_TYPE *)buffer_get(sizeof(EVENT_HEADER_TYPE));
	memset(buf, 0, sizeof(EVENT_HEADER_TYPE));
	buf->length = sizeof(EVENT_HEADER_TYPE);
	buf->code = EV_GUIF_SCAN_DONE;
	buf->sid =SVC_ID_CTBOX_BTN;
	buf->rid =SVC_ID_CTBOX_DISP;
	buf->sent = get_epoch_time_nano();
	buf->complete = 0;
	buf->received = 0;
	//buf->not_log = not_log;
	log_event((void *)buf);
	//dump_to_terminal(0,0);
	//log_msg();
	EXPECT_EQ(0, dump_to_terminal(0,0));
	logger_exit();
	buffer_destroy();
}
