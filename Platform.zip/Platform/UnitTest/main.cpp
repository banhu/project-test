
/**@file
 * Copyright (C) 2013, Sinovision Tech Ltd.
 * All rights reserved.
 *
 * @brief   This file defines a testmain
 *
 * @author  wjw
 * @date 2013-8-15
 *
 */
#include "gtest/gtest.h"
//extern "C"{
//#include "buffer.h"
//}

int main(int argc, char *argv[])
{   

    testing::InitGoogleTest(&argc, argv);
	//buffer_init();
    return RUN_ALL_TESTS();
}





