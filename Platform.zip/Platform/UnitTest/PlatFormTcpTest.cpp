/**@file: PlatFormTcpTest.cpp
 * Copyright (C) 2014, Sinovision Tech Ltd.
 * All rights reserved.
 *
 * @brief   
 *
 * @author  huyf
 * @date    2014-09-25 10:09:51
 * This test new to testServer then send 5 event to each other and count it ,equal the tow count.
 * in this
 */
#include"gtest/gtest.h"

extern "C"{
#include "buffer.h"
#include "testserver.h"
#include "monitor.h"
#include "EvGantryUIF.h"
extern int parse_run_command(const char *cmd_line, int len);
}
//extern TestServer *Test1;
//extern TestServer *Test2;
/*
	0	"srecvlog",   //EV_SS_ACTION_SETUP
	1	"rrecvlog",   //EV_SS_FAULT_RECOVERED
	2	"krecvlog",   //EV_RD_FPGA_KEY
	3	"drecvlog",   //EV_SS_INIT_DONE
	4   "fpgarecvlog" //EV_RD_FPGA_REG_RES
*/

TestServer *Test1;
TestServer *Test2;

TEST(PlatFormTcpTest, send_event_from)
{
	int i;
	EVENT_HEADER_TYPE event;
	//TestServer *Test2;
	Test1 =new TestServer(SVC_ID_TEST7, 0, 1, 10000, NULL);
	Test2 =new TestServer(SVC_ID_TEST8, 0, 1, 10000, 0);


	ECService::startAll();
	ECL::telnet_run(PROC_ID_TOOLS);
	ECL::telnet_run(PROC_ID_CTBOX);
	/*****************************
	 * log [en/dis] [svc_id | conn] (0 is platform)
	 * log [dump] [opt] [fromsvc] [tosvc] (opt is 0 console, 1 file, 2 svc)
	 * log [level] [level] (0 en or dis event log, level(1 - 5))
	 */
	const char *cmdlog1 = "log en 0";
	parse_run_command(cmdlog1,8);
	const char *cmdlog2 = "log en conn";
	parse_run_command(cmdlog2,11);
	const char *cmdlog3 = "log level 5";
	parse_run_command(cmdlog3,11);
	const char *cmdlog4 = "log dump 0";
	const char *cmdlog5 = "log dump 1";
	const char *cmdlog6 = "log dump 2 306 307";

	//ECL::send_ver_to_ctl(SVC_ID_TEST7);
	const char *cmd_line0 = "md_ipport 306 127.0.0.1 61006";
	const char *cmd_line3 = "md_ipport 307 127.0.0.1 61007";
	parse_run_command(cmd_line0,29);
	parse_run_command(cmd_line3,29);
	const char *cmd_line = "openlog conn";
	parse_run_command(cmd_line,12);
	const char *cmd_line1 = "openlog interval";
	parse_run_command(cmd_line1,16);


	//ECL::start_service(SVC_ID_TEST8, 0);
	event.code = EV_SS_ACTION_SETUP;
	ECL::send_event_from(SVC_ID_TEST7,SVC_ID_TEST8, &event,sizeof(EVENT_HEADER_TYPE),0);
	parse_run_command(cmdlog4,10);
	event.code = EV_SS_FAULT_RECOVERED;
	ECL::send_event_from(SVC_ID_TEST7,SVC_ID_TEST8, &event,sizeof(EVENT_HEADER_TYPE),0);
	parse_run_command(cmdlog5,10);
	event.code = EV_RD_FPGA_KEY;
	ECL::send_event_from(SVC_ID_TEST7,SVC_ID_TEST8, &event,sizeof(EVENT_HEADER_TYPE),0);
	parse_run_command(cmdlog6, 18);
	event.code = EV_SS_INIT_DONE;
	ECL::send_event_from(SVC_ID_TEST7,SVC_ID_TEST8, &event,sizeof(EVENT_HEADER_TYPE),0);
	event.code = EV_RD_FPGA_REG_RES;
	ECL::send_event_from(SVC_ID_TEST7,SVC_ID_TEST8, &event,sizeof(EVENT_HEADER_TYPE),0);
	usleep(500000);
	i= Test2->getlogval(0);
	EXPECT_EQ(1, i);
	i= Test2->getlogval(1);
	EXPECT_EQ(1, i);
	i= Test2->getlogval(2);
	EXPECT_EQ(1, i);
	i= Test2->getlogval(3);
	EXPECT_EQ(1, i);
	i= Test2->getlogval(4);
	EXPECT_EQ(1, i);
	for (i = 0; i<5; i++)
	{
		Test2->setlogval(i,2);
		EXPECT_EQ(2, Test2->getlogval(i));
	}
	Test2->recvlog();

	for (i = 0; i<5; i++)
	{
		//Test2->setlogval(i,2);
		EXPECT_EQ(0, Test2->getlogval(i));
	}
	//EXPECT_EQ(0, ECL::stop_service(SVC_ID_TEST8));
}
TEST(PlatFormTcpTest, send_event_from_tcp)
{
	const char *ld0 = "ld0";
	const char *cmdlog1 = "log en 0";
	parse_run_command(cmdlog1,8);
	const char *cmdlog2 = "log en conn";
	parse_run_command(cmdlog2,11);
	int sendlog;
	EVENT_HEADER_TYPE event;
	const char *cmd_line1 = "conn";
	ECL::connection_svc_from_to(SVC_ID_TEST7,SVC_ID_TEST8, 0);
	parse_run_command(cmd_line1,4);
	parse_run_command(ld0, 3);

	event.code = EV_SS_DEV_REPORT_VER;
	sendlog = ECL::send_event_from_tcp(SVC_ID_TEST7,SVC_ID_TEST8, &event,sizeof(EVENT_HEADER_TYPE),0);
	EXPECT_FALSE(sendlog);

	//ECL::connection_svc_from_to(SVC_ID_TEST7,SVC_ID_TEST8, 1);
	//sleep(4);
	parse_run_command(ld0, 3);
	parse_run_command(cmd_line1,4);
	const char *et = "et 306 307 1 100";
	parse_run_command(et,16);
	const char *cmd_line = "queue";
	parse_run_command(cmd_line,5);
	event.code = EV_SS_ACTION_SETUP;
	ECL::send_event_from_tcp(SVC_ID_TEST7,SVC_ID_TEST8, &event,sizeof(EVENT_HEADER_TYPE),0);
	event.code = EV_SS_FAULT_RECOVERED;
	ECL::send_event_from_tcp(SVC_ID_TEST7,SVC_ID_TEST8, &event,sizeof(EVENT_HEADER_TYPE),0);
	event.code = EV_RD_FPGA_KEY;
	ECL::send_event_from_tcp(SVC_ID_TEST7,SVC_ID_TEST8, &event,sizeof(EVENT_HEADER_TYPE),0);
	event.code = EV_SS_INIT_DONE;
	ECL::send_event_from_tcp(SVC_ID_TEST7,SVC_ID_TEST8, &event,sizeof(EVENT_HEADER_TYPE),0);
	event.code = EV_RD_FPGA_REG_RES;
	ECL::send_event_from_tcp(SVC_ID_TEST7,SVC_ID_TEST8, &event,sizeof(EVENT_HEADER_TYPE),0);
	parse_run_command(ld0, 3);
	usleep(5000000);
	parse_run_command(ld0, 3);
	int i = 0;
	i= Test2->getlogval(0);
	EXPECT_EQ(1, i);
	i= Test2->getlogval(1);
	EXPECT_EQ(1, i);
	i= Test2->getlogval(2);
	EXPECT_EQ(1, i);
	i= Test2->getlogval(3);
	EXPECT_EQ(1, i);
	i= Test2->getlogval(4);
	EXPECT_EQ(1, i);
	Test2->recvlog();
	const char *send_h = "send -h 306 307 1100";
	parse_run_command(send_h,20);
	parse_run_command(cmd_line1,4);
	ECL::stop_service(SVC_ID_TEST8);
	sleep(1);
	ECL::kill_service(SVC_ID_TEST8);
	sleep(1);
	ECL::start_service(SVC_ID_TEST8, 0);
	sleep(3);
	ECL::logger_exit();
	delete Test1;
	sleep(1);
	delete Test2;
	sleep(1);
}
#if 0

/**Test_Run_Command*/
TEST(monitor, parse_run_command_help)
{
	const char *cmd_line = "help";
	parse_run_command(cmd_line,4);
	EXPECT_TRUE(true);
}

TEST(monitor, parse_run_command_ver)
{
	const char *cmd_line = "ver";
	parse_run_command(cmd_line,3);
	EXPECT_TRUE(true);
}

TEST(monitor, parse_run_command_lgs)
{
	const char *cmd_line = "lgs";
	parse_run_command(cmd_line,3);
	EXPECT_TRUE(true);
}

TEST(monitor, parse_run_command_ld0)
{
	const char *cmd_line = "ld0";
	parse_run_command(cmd_line,3);
	EXPECT_TRUE(true);
}

TEST(monitor, parse_run_command_conn)
{
	const char *cmd_line = "conn";
	parse_run_command(cmd_line,4);
	EXPECT_TRUE(true);
}

TEST(monitor, parse_run_command_timer)
{
	const char *cmd_line = "timer show all";
	parse_run_command(cmd_line,14);
	EXPECT_TRUE(true);
}

TEST(monitor, parse_run_command_et)
{
	//const char *cmd_line = "et 306 307 1 100";
	//parse_run_command(cmd_line,16);
	EXPECT_TRUE(true);
}

TEST(monitor, parse_run_command_send)
{

	EXPECT_TRUE(true);
}

TEST(monitor, parse_run_command_openlog)
{
	const char *cmd_line = "openlog conn";
	parse_run_command(cmd_line,12);
	const char *cmd_line1 = "openlog interval";
	parse_run_command(cmd_line1,16);
	EXPECT_TRUE(true);
}


TEST(monitor, parse_run_command_printflog)
{
	const char *cmd_line = "printflog";
	parse_run_command(cmd_line,9);
	usleep(50000);
	EXPECT_TRUE(true);
}
TEST(monitor, parse_run_command_queue)
{
	const char *cmd_line = "queue";
	parse_run_command(cmd_line,5);
	usleep(50000);
	EXPECT_TRUE(true);
}

TEST(monitor, parse_run_command_dbuf)
{
	const char *cmd_line = "dbuf";
	parse_run_command(cmd_line,4);
	buffer_destroy();
	usleep(50000);
	EXPECT_TRUE(true);
}
#endif
