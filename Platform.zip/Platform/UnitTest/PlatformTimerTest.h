/**@file:   PlatformTimerTest.h 
 * Copyright (C) 2015, Sinovision Tech Ltd.
 *
 * @brief:
 *
 * @author: huyf
 * @date:   2015-06-01 10:06:52
 * @email:  yongfei_hu@163.com
 * @website:http://www.fuxiwan.com
 *
 */

#ifndef _PLATFORMTIMER_TEST_H_
#define _PLATFORMTIMER_TEST_H_

#include"ECService.h"
#include "ServiceTesterBase.h"
#include "testControl.h"

class PlatformTimerTest:public ServiceTesterBase
{
	public:
		explicit PlatformTimerTest(SVCID id, int priority,
			bool detach, size_t stack, TestControl *ss = NULL);
		~PlatformTimerTest(){};

	private:

        void runTest();
        void testInit(){}

        TestControl * sut;
        SVCID sutId;

};

#endif
