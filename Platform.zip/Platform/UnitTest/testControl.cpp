/**@file:   testControl.cpp 
 * Copyright (C) 2015, Sinovision Tech Ltd.
 *
 * @brief:
 *
 * @author: huyf
 * @date:   2015-05-28 18:05:56
 * @email:  yongfei_hu@163.com
 * @website:http://www.fuxiwan.com
 *
 */

#include "testControl.h"

extern "C"{
extern int parse_run_command(const char *cmd_line, int len);
}

TestControl::TestControl(SVCID id,int priority,bool detach,size_t stack, SVCID scId,  SVCID devId)
:ECService(id, priority, detach, stack, NULL)
{
	sid = id;
	this->scId=scId;
	this->driverId=devId;
}

int  TestControl::initialize()
{

	registerEvent(EV_SS_FAULT_RECOVERED, (EventHandler)&TestControl::evtHandler);
	registerEvent(EV_SS_ACTION_SETUP, (EventHandler)&TestControl::evtHandler);
	registerEvent(EV_RD_FPGA_KEY, (EventHandler)&TestControl::evtHandler);
	registerEvent(EV_SS_INIT_DONE, (EventHandler)&TestControl::evtHandler);
	registerEvent(EV_RD_FPGA_REG_RES, (EventHandler)&TestControl::evtHandler);
	registerEvent(EV_XML_VERSION, (EventHandler)&TestControl::evtHandler);
	//timerStart(EV_TEST_TIMER, 1000, TIMER_OPT_ONCE);
	//timerStart(EV_EVENT_TEST, 2000, TIMER_OPT_INTERVAL );
	return 0;
}
#include <stdlib.h>
#include <stdio.h>
static int send_ld_to_svc(int argc, char * const argv[])
{
	EV_LOG_DUMP_TYPE ev;
    ev.header.sid = (SVCID)atoi(argv[0]);
    ev.header.rid = (SVCID)atoi(argv[1]);
    ev.target = (SVCID)atoi(argv[2]);
    ECService::sendEventFrom(ev.header.sid , ev.header.rid, EV_LOG_DUMP, &ev,sizeof(ev) );
    return 0;
}

void TestControl::run_command(const char *cmd_line, int len)
{
	parse_run_command(cmd_line, len);
}
#if 0
int TestControl::WaitEvent(unsigned int code, EVENT_HEADER_TYPE **ev, int timeoutMs)
{
	return ECService::waitEvent(code, ev, timeoutMs);
}
#endif

int TestControl::threadInitialize()
{
	registerDevice((char *)FPGATESTDEV, SVC_ID_DEV_FPGATEST);
	ECL::insert_command((char*)"lds", send_ld_to_svc, (char*)"send log dump event to service ");
	//connToSvc(SVC_ID_TEST1, 1);
	return 0;
}

void TestControl::evtHandler(EVENT_HEADER_TYPE *event)
{
	printf("sid:%d   event->rid: %d   event->code:%d\n", sid,event->rid, event->code);
	ECService::sendEvent(scId,event->code, 1);
}
