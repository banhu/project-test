/**@file:   PlatformSendTest.h
 * Copyright (C) 2015, Sinovision Tech Ltd.
 *
 * @brief:
 *
 * @author: huyf
 * @date:   2015-06-01 10:06:10
 * @email:  yongfei_hu@163.com
 * @website:http://www.fuxiwan.com
 *
 */

#ifndef _PLATFORMSEND_TEST_H_
#define _PLATFORMSEND_TEST_H_

#include"ECService.h"
#include "ServiceTesterBase.h"
#include "testControl.h"

class PlatformSendTest:public ServiceTesterBase
{
	public:
		explicit PlatformSendTest(SVCID id, int priority,
			bool detach, size_t stack, TestControl *ss = NULL);
		~PlatformSendTest(){};

	private:

        void runTest();
        void testInit(){}

        TestControl * sut;
        SVCID sutId;
        SVCID sid;

};

#endif
