/**@file:   PlatformSendTest.cpp
 * Copyright (C) 2015, Sinovision Tech Ltd.
 *
 * @brief:
 *
 * @author: huyf
 * @date:   2015-05-29 12:05:05
 * @email:  yongfei_hu@163.com
 * @website:http://www.fuxiwan.com
 *
 */


#include <unistd.h>
#include "gtest/gtest.h"
#include "PlatformSendTest.h"

extern "C"{
extern int parse_run_command(const char *cmd_line, int len);
}

PlatformSendTest::PlatformSendTest(SVCID id,int priority,bool detach,size_t stack,TestControl *ss)
:ServiceTesterBase(id, priority, detach, stack)
{
	sid = id;
	sut = ss;
	sutId= ss->getID();

}

void PlatformSendTest::runTest()
{
	EVENT_HEADER_TYPE *ev = NULL;
	int ret = -1;
	const char *ld0 = "ld0";
	const char *lds = "lds 301 300 301";
	EXPECT_EQ(sid, ECL::self_id());
	//EXPECT_TRUE(sut->WaitEvent(EV_LOG_DUMP, &ev, 600)>=0);
	const char *cmdlog1 = "log en 0";
	parse_run_command(cmdlog1,8);
	const char *cmdlog2 = "log en conn";
	parse_run_command(cmdlog2,11);
	const char *cmdlog3 = "log level 1";
	parse_run_command(cmdlog3,11);
	const char *cmdlog4 = "log dump 0";
	const char *cmdlog5 = "log dump 1";
	const char *cmdlog6 = "log dump 2 300 301";

	const char *name = "TOOLS";

	ret =strcmp(name, ECService::setProcessName((char *)name));
	EXPECT_EQ(ret, 0);


	ECService::logMsg(LOG_EVENT, "log_msg: %s(Line: %d)\n",__FUNCTION__, __LINE__);
	ECService::logMsg(LOG_LEVEL_ERR, "log_msg: %s(Line: %d)\n",__FUNCTION__, __LINE__);
	ECL::log_msg(LOG_LEVEL_WARNING, "log_msg: %s(Line: %d)\n",__FUNCTION__, __LINE__);
	ECL::log_msg(LOG_LEVEL_NOTICE, "log_msg: %s(Line: %d)\n",__FUNCTION__, __LINE__);
	ECL::log_msg(LOG_LEVEL_INFO, "log_msg: %s(Line: %d)\n",__FUNCTION__, __LINE__);
	ECL::log_msg(LOG_LEVEL_DEBUG, "log_msg: %s(Line: %d)\n",__FUNCTION__, __LINE__);

	sut->run_command(ld0,3);

	EVENT_HEADER_TYPE *ev1 = NULL;
	ev1 = (EVENT_HEADER_TYPE *)ECService::getBuffer(sizeof(EVENT_HEADER_TYPE));
	ev1->not_log = 1;
	ECService::sendSelfEvent(EV_SS_FAULT_RECOVERED);
	EXPECT_TRUE(waitEvent(EV_SS_FAULT_RECOVERED, &ev, 600)>=0);
	if (NULL != ev) {
		ECService::releaseBuffer((char*)(ev)); 
	}

	if (NULL != ev1) {
		ECService::releaseBuffer((char*)ev1);
	}
	ECService::sendEvent(sutId,EV_SS_FAULT_RECOVERED, 0);
	EXPECT_TRUE(waitEvent(EV_SS_FAULT_RECOVERED, &ev, 600)>=0);
	if (NULL != ev) {
		ECService::releaseBuffer((char*)(ev)); 
	}

	parse_run_command(cmdlog4,10);
	ECService::sendEvent(sutId,EV_SS_ACTION_SETUP, 0);
	EXPECT_TRUE(waitEvent(EV_SS_ACTION_SETUP, &ev, 600)>=0);
	ECL::disp_ev_header(ev);
	if (NULL!=ev) {
		ECService::releaseBuffer((char*)(ev));
	}
	parse_run_command(cmdlog5,10);
	parse_run_command(lds,15);
	ret = ECL::delete_command((char*)"lds");
	EXPECT_TRUE(ret >= 0);
	sut->run_command(ld0, 3);
	ECService::sendEvent(sutId,EV_RD_FPGA_KEY, 0);
	EXPECT_TRUE(waitEvent(EV_RD_FPGA_KEY, &ev, 600)>=0);
	ECService::releaseBuffer((char*)(ev));
	parse_run_command(cmdlog6, 18);
	const char *conn = "conn";
	parse_run_command(conn,4);



	EV_SS_FPGA_REPORT_VER_TYPE evtVer;
	const char * fpgaName = "TestFpga";

	/* set event header */
	evtVer.header.code			= EV_SS_FPGA_REPORT_VER;
	evtVer.header.length		= sizeof(EV_SS_FPGA_REPORT_VER_TYPE);
	evtVer.header.sid			= this->getID();
	evtVer.header.rid			= SVC_ID_UNKNOWN;
	evtVer.header.checksum 		= evtVer.header.length + evtVer.header.code + \
									evtVer.header.sid + evtVer.header.rid;
	evtVer.header.not_log		= 0;
	evtVer.header.sent			= ECL::get_epoch_time_nano();
	evtVer.header.received		= 0;
	evtVer.header.complete		= 0;
	/* set fpga name */
	strcpy(evtVer.fpgaName, fpgaName);

	ECService::setFpgaVer(&evtVer);

    ret = ECService::sendVerToCtl(sutId);
    EXPECT_TRUE(ret >= 0);

	parse_run_command(ld0,3);
	printf("**************************************\n");
	printf("               connToSvc\n");
	printf("**************************************\n");
	ECService::connToSvc(SVC_ID_TEST1, 1);
	sleep(4);
	parse_run_command(ld0,3);
	parse_run_command(conn,4);

	ECService::sendEvent(sutId,EV_SS_INIT_DONE, 0);
	EXPECT_TRUE(waitEvent(EV_SS_INIT_DONE, &ev, 600)>=0);
	ECService::sendEvent(sutId,EV_RD_FPGA_REG_RES, 0);
	EXPECT_TRUE(waitEvent(EV_RD_FPGA_REG_RES, &ev, 600)>=0);
	parse_run_command(ld0,3);
	parse_run_command(conn,4);

}

TEST(PlatformSendTest, sendEvent)
{
 	usleep(50000);

 	TestControl *testCtrl = new TestControl(SVC_ID_TEST1, 0, 0, 10000, SVC_ID_TEST2,SVC_ID_TEST2);

 	PlatformSendTest *tester = new PlatformSendTest(SVC_ID_TEST2, 0, 0, 10000, testCtrl);
	//const char *lgs = "lgs";
	//parse_run_command(lgs,3);
	//const char *md_ipport1 = "md_ipport 300 127.0.0.1 61000";
	//parse_run_command(md_ipport1,29);
	//const char *md_ipport2 = "md_ipport 301 127.0.0.1 61001";
	//parse_run_command(md_ipport2,29);
    ECService::startAll();

    while(!tester->testDone());
    ECL::stop_services();

    ECL::kill_service(SVC_ID_TEST1);
    ECL::kill_service(SVC_ID_TEST2);
    //ECL::logger_exit();
 	usleep(30000);
    delete testCtrl;
  	usleep(30000);
    delete tester;
 	usleep(300000);
}
