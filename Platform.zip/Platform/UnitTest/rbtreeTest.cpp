/**@file: rbtreeTest.cpp
 * Copyright (C) 2014, Sinovision Tech Ltd.
 * All rights reserved.
 *
 * @brief   
 *
 * @author  huyf
 * @date    2014-09-23 18:09:33
 *
 */
#include"gtest/gtest.h"
#include <string.h>
extern "C"{
#include "rbtree.h"
#include "buffer.h" 
}
RB_TREE_T myTree;

typedef struct
{
	int id;
	int num;
}MY_NODE_TYPE;

typedef enum
{
	NODE_ID_UNKNOWN =0,
	NODE_ID_1,
	NODE_ID_2,
	NODE_ID_3,
	NODE_ID_4,
	NODE_ID_5,
	NODE_ID_END
}NODEID;

static MY_NODE_TYPE node_default[]=
{
	{NODE_ID_1,1000},
	{NODE_ID_2,2000},
	{NODE_ID_3,3000},
	{NODE_ID_4,4000},
	{NODE_ID_5,5000}
};

TEST(RbtreeTest, rbtree_init)
{
	buffer_init();
	rbtree_init(&myTree,KEY_INT);
	EXPECT_EQ(KEY_INT, 0);
}

TEST(RbtreeTest, rbtree_insert)
{
	int i;
	int size = sizeof(node_default)/sizeof(MY_NODE_TYPE);
	MY_NODE_TYPE *node;
	for(i=0;i<size;i++)
	{
		rbtree_insert(&myTree,(void*)node_default[i].id,(void*)&node_default[i]);
	}
	RB_NODE_T *result = NULL;

	for(i = 0; i<size; i++)
	{
		result = rbtree_find(&myTree,(void *)node_default[i].id);
		if (result)
			node = (MY_NODE_TYPE*)result->item;

		EXPECT_EQ(node->num, node_default[i].num);
	}

}

TEST(RbtreeTest, rbtree_remove)
{
	RB_NODE_T *result = NULL;
	result = rbtree_find(&myTree,(void *)node_default[1].id);

	if(NULL == result ){
		printf("[ RUN      ] Node is not in the rbtree!\n");
		EXPECT_TRUE(false);
	}else{
		rbtree_remove(&myTree, result);
		result = rbtree_find(&myTree,(void *)node_default[1].id);
		if(NULL == result){
			EXPECT_TRUE(true);
		}else{
			EXPECT_TRUE(false);
		}
	}
}

TEST(RbtreeTest, rbtree_first)
{
	RB_NODE_T *result = NULL;
	MY_NODE_TYPE *node;

	result = rbtree_first(&myTree);
	if(NULL == result){
		printf("[ RUN      ] There is no Head found\n");
		EXPECT_TRUE(false);
	}else{
		node = (MY_NODE_TYPE*)result->item;
		EXPECT_EQ(node->num, node_default[0].num);
	}
}

TEST(RbtreeTest, rbtree_next)
{
	RB_NODE_T *result = NULL;
	MY_NODE_TYPE *node;

	result = rbtree_first(&myTree);
	result = rbtree_next(&myTree, result);
	if(NULL == result){
		printf("[ RUN      ] There is no next found\n");
		EXPECT_TRUE(false);
	}else{
		node = (MY_NODE_TYPE*)result->item;
		EXPECT_EQ(node->num, node_default[2].num);
	}
	buffer_destroy();
}
/** ev_compare is not in use
TEST(RbtreeTest, ev_compare)
{
	RB_NODE_T *result = NULL;
	MY_NODE_TYPE *node;
	int ret;

	result = rbtree_find(&myTree,(void *)node_default[3].id);

	if(NULL == result){	
		printf("[ RUN      ] There is no node found\n");
		EXPECT_TRUE(false);
	}else{
		node = (MY_NODE_TYPE*)result->item;
		ret = ev_compare(node, node_default[3]);
		EXPECT_EQ(ret, 0);
	}
}
*/
