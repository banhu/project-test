/**@file: bufferTest.cpp
 * Copyright (C) 2014, Sinovision Tech Ltd.
 * All rights reserved.
 *
 * @brief   
 *
 * @author  huyf
 * @date    2014-09-23 10:08:42
 *
 */
#include"gtest/gtest.h"
extern "C"{
#include "buffer.h" 
}


TEST(BufferTest, buffer_operate)
{
	buffer_init();
	char * tmp[256];
	unsigned int i;
	size_t size;
	size_t cell_size[8]={10, 48, 64, 128, 256, 512, 1024, 2032};
	char str[8][10] = {"000001","100001","200001","300001","400001","500001","600001","700001"};

	for(i = 0; i < 8; i++)
	{
		tmp[i] = buffer_get(cell_size[i]);
		size = buffer_size(tmp[i]);
		//disp_buffer_info(0,0);
		memcpy(tmp[i],str[i],7);
		EXPECT_EQ(size,cell_size[i]);
		printf("[ RUN  get ] buffer_get tmp[%d]:%s OK,  size is %d\n",i,tmp[i], size);
	}

	for(i = 0; i < 8; i++)
	{
		tmp[i] = buffer_expand(tmp[i],2*cell_size[i]);
		size = buffer_size(tmp[i]);
		EXPECT_EQ(size,2*cell_size[i]);
		printf("[ RUN expand ] buffer_expand tmp[%d]:%s OK,  size is %d\n",i,tmp[i], size);
	}



	//disp_buffer_info(0,0);

	for(i = 0; i < 8; i++)
	{
		buffer_release(tmp[i]);
	//	printf("Buffer_release  tmp[%d]:%s is OK.\n",i,tmp[i]);
	}
    buffer_test(0,0);
    char *buf[4096];
    for(i = 1; i <4096; i++)
    {
        buf[i] = NULL;
        buf[i] = buffer_get(i);
        EXPECT_EQ(buffer_size(buf[i]), i);
    }
	printf("[ RUN  get ] buffer_get i:%d, buffer_size :%d \n",i, buffer_size(buf[i]));
    for(i = 1; i <4096; i++)
    {
        buf[i] = buffer_expand(buf[i], i*2);
        EXPECT_EQ(buffer_size(buf[i]), i*2);
    }
	printf("[ RUN  get ] buffer_expand i:%d, buffer_size :%d \n",i*2, buffer_size(buf[i]));
    for(i = 1; i <4096; i++)
    {
        buf[i] = buffer_expand(buf[i], i*2 + 11);
        EXPECT_EQ(buffer_size(buf[i]), i*2 + 11);
    }
	printf("[ RUN  get ] buffer_expand i:%d, buffer_size :%d \n",i*2 +11, buffer_size(buf[i]));
    for(i = 1; i <4096; i++)
    {
        buffer_release(buf[i]);
    }

    buffer_destroy();
}

