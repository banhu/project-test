/**@file: testserver.h
 * Copyright (C) 2014, Sinovision Tech Ltd.
 * All rights reserved.
 *
 * @brief   
 *
 * @author  huyf
 * @date    2014-09-26 16:09:57
 *
 */

#ifndef _TEST_SERVER_H_
#define _TEST_SERVER_H_

#include "os_intf.h"
#include "ECService.h"
#include "timer.h"
class TestServer : public ECService
{
public:

	explicit TestServer(SVCID id, int priority,
        bool detach, size_t stack,os_thread_data_t arg = NULL);
	int getlogval(int logname);
	int setlogval(int logname, int val);
	int recvlog();
	~TestServer(){};

private:
	SVCID sid;
	int initialize();
	int threadInitialize();
	void evtHandler(EVENT_HEADER_TYPE *event);
	int srecvlog;
	int rrecvlog;
	int krecvlog;
	int drecvlog;
	int fpgarecvlog;
	int verrecvlog;
};

#endif
