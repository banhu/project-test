/**@file: queueTest.cpp
 * Copyright (C) 2014, Sinovision Tech Ltd.
 * All rights reserved.
 *
 * @brief   
 *
 * @author  huyf
 * @date    2014-08-26 15:08:42
 *
 */
#include"gtest/gtest.h"
extern "C"{
#include "queue.h"
#include "buffer.h" 
}


TEST(QueueTest, queue_new )
{
	QUEUE *q;
	q = queue_new();
	if(queue_size(q) ==0 )
		EXPECT_TRUE(true);
	else
		EXPECT_TRUE(false);


	queue_free(&q);

}

TEST(QueueTest, queue_add )
{
	int i=0;
    int *data=(int *)(malloc(sizeof(int)));
    int *data2=(int *)(malloc(sizeof(int)));
	QUEUE *q = queue_new();


		queue_add(q, (void *) data);
		EXPECT_EQ(queue_size(q), 1);
		queue_add(q, (void *) data2);
		EXPECT_EQ(queue_size(q), 2);
		queue_add(q, (void *) data2);
		EXPECT_EQ(queue_size(q), 3);
		queue_add_head(q, (void *) data);
		EXPECT_EQ(queue_size(q), 4);
		for(i = 0;i<68; i++)
		{
			queue_add(q, (void *) data2);
			EXPECT_EQ(queue_size(q), 5+i);
		}

		queue_free(&q);

}

TEST(QueueTest, queue_add_head )
{
	QUEUE *q = queue_new();
	int *data=(int *)(malloc(sizeof(int)));
	int i=0;
	for(i=0;i<60;i++)
	{
		queue_add_head(q, (void *) data);

	}
	EXPECT_EQ(queue_size(q), 60);

	for(i=0;i<10;i++)
	{
		queue_add_head(q, (void *) data);

	}
	EXPECT_EQ(queue_size(q), 70);
	queue_free(&q);
}
TEST(QueueTest, queue_size )
{
	QUEUE *q = queue_new();
    int *data=(int *)(malloc(sizeof(int)));
    int *data2=(int *)(malloc(sizeof(int)));

	queue_add(q, (void *) data);

	queue_add(q, (void *) data2);

	queue_add(q, (void *) data2);
	queue_add_head(q, (void *) data);

	int size = queue_size(q);
	EXPECT_EQ(queue_size(q), size);
	queue_free(&q);

}
TEST(QueueTest, queue_get )
{
	int fsize,bsize;
	QUEUE *q = queue_new();
    int *data=(int *)(malloc(sizeof(int)));
    int *data2=(int *)(malloc(sizeof(int)));

	queue_add(q, (void *) data);

	queue_add(q, (void *) data2);

	queue_add(q, (void *) data2);
	queue_add_head(q, (void *) data);

	fsize = queue_size(q);
	queue_get(q);
	bsize = queue_size(q);
	EXPECT_EQ(fsize, bsize+1);

	fsize = queue_size(q);
	queue_get(q);
	bsize = queue_size(q);
	EXPECT_EQ(fsize, bsize+1);
	queue_free(&q);

}

