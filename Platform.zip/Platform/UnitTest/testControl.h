/**@file:   testControl.h 
 * Copyright (C) 2015, Sinovision Tech Ltd.
 *
 * @brief:
 *
 * @author: huyf
 * @date:   2015-05-28 18:05:45
 * @email:  yongfei_hu@163.com
 * @website:http://www.fuxiwan.com
 *
 */


#ifndef _TEST_CONTROL_H_
#define _TEST_CONTROL_H_

#include "os_intf.h"
#include "ECService.h"
#include "timer.h"
class TestControl : public ECService
{
public:
	explicit TestControl(SVCID id, int priority, bool detach, size_t stack, SVCID scId,  SVCID devId);
	~TestControl(){};
#if 0
	int WaitEvent(unsigned int code, EVENT_HEADER_TYPE **ev, int timeoutMs);
#endif
	void run_command(const char *cmd_line, int len);

private:
	SVCID sid;
	SVCID scId;
	SVCID driverId;

	int initialize();
	int threadInitialize();
	void evtHandler(EVENT_HEADER_TYPE *event);
};

#endif
