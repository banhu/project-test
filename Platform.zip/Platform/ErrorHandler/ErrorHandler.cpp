/**@file 
 * Copyright (C) 2013, Sinovision Tech Ltd.
 * All rights reserved.
 *
 * @brief  this file implements the C++ interface of event comm service
 *
 * @author  
 * @date 2013-11-13
 *
 */

#include "ErrorHandler.h"
#include <string.h>


ErrorHandler::ErrorHandler()
{
}

void ErrorHandler::logString(const char *desc)
{
	char *ret = NULL;
	char *tmp = (char *)desc;


	ret = strchr(tmp,'%');
	if(ret == NULL)
	{
		ECService::logMsg(LOG_LEVEL_ERR,tmp);
	}
	else
	{
		char content[1024];
		memset(content,0,sizeof(content));
		memcpy(content,tmp,ret-tmp);
		//content[ret-desc] = '\0';
		//printf("ErrDesc:%s\n",content);
		//printf("done\n");
		ECService::logMsg(LOG_LEVEL_ERR,content);
	}

}

// version 1 interfaces, should be removed when all subsystem updated
void ErrorHandler::report(SVCID to, ERROR_INFO_TYPE err)
{
    EV_ERROR_REPORTING_TYPE ev;
    ev.err = err;
    ev.numOfParam = 0;
    ev.decodeType = DECODE_NONE;
    ECService::sendEvent(to,EV_ERROR_REPORTING,&ev,sizeof(ev));
    ECService::logMsg(LOG_LEVEL_ERR,"report error, module%d, component:%d, errorNum %d \n", err.module, err.component, err.errNum);
}

void ErrorHandler::report(SVCID to, ERROR_INFO_TYPE err, int32_t numofParam, int32_t param[10], LOG_DECODE_TYPE decodeType)
{
    EV_ERROR_REPORTING_TYPE ev;
    ev.err = err;
    ev.numOfParam = numofParam;
    ev.decodeType = decodeType;
    for(int i=0;i<numofParam;i++){
        ev.param[i] = param[i];}
    ECService::sendEvent(to,EV_ERROR_REPORTING,&ev,sizeof(ev));
    ECService::logMsg(LOG_LEVEL_ERR,"report error, module%d, component:%d, errorNum %d \n", err.module, err.component, err.errNum);
}

void ErrorHandler::report(SVCID to, ERROR_INFO_TYPE err, int32_t* param, LOG_DECODE_TYPE decodeType)
{
    EV_ERROR_REPORTING_TYPE ev;
    ev.err = err;
    ev.numOfParam = 1;
    ev.decodeType = decodeType;
    ev.param[0] = *param;
    ECService::sendEvent(to,EV_ERROR_REPORTING,&ev,sizeof(ev));
    ECService::logMsg(LOG_LEVEL_ERR,"report error, module%d, component:%d, errorNum %d \n", err.module, err.component, err.errNum);

}
void ErrorHandler::report(SVCID to, ERROR_INFO_TYPE err, int32_t* param1, int32_t* param2, LOG_DECODE_TYPE decodeType)
{
    EV_ERROR_REPORTING_TYPE ev;
    ev.err = err;
    ev.numOfParam = 2;
    ev.decodeType = decodeType;
    ev.param[0] = *param1;
    ev.param[1] = *param2;
    ECService::sendEvent(to,EV_ERROR_REPORTING,&ev,sizeof(ev));
    ECService::logMsg(LOG_LEVEL_ERR,"report error, module%d, component:%d, errorNum %d \n", err.module, err.component, err.errNum);
}

void ErrorHandler::report(SVCID from, SVCID to, ERROR_INFO_TYPE err)
{
    EV_ERROR_REPORTING_TYPE ev;
    ev.err = err;
    ev.numOfParam = 0;
    ev.decodeType = DECODE_NONE;
    ECService::sendEventFrom(from, to,EV_ERROR_REPORTING,&ev,sizeof(ev));
    ECService::logMsg(LOG_LEVEL_ERR,"report error, module%d, component:%d, errorNum %d \n", err.module, err.component, err.errNum);
}



void ErrorHandler::report(SVCID from, SVCID to, ERROR_INFO_TYPE err, int32_t numofParam, int32_t param[10], LOG_DECODE_TYPE decodeType)
{
    EV_ERROR_REPORTING_TYPE ev;
    ev.err = err;
    ev.numOfParam = numofParam;
    ev.decodeType = decodeType;
    for(int i=0;i<numofParam;i++){
        ev.param[i] = param[i];}
    ECService::sendEventFrom(from, to,EV_ERROR_REPORTING,&ev,sizeof(ev));
    ECService::logMsg(LOG_LEVEL_ERR,"report error, module%d, component:%d, errorNum %d \n", err.module, err.component, err.errNum);
}

void ErrorHandler::report(SVCID from, SVCID to, ERROR_INFO_TYPE err, int32_t* param, LOG_DECODE_TYPE decodeType)
{
    EV_ERROR_REPORTING_TYPE ev;
    ev.err = err;
    ev.numOfParam = 1;
    ev.decodeType = decodeType;
    ev.param[0] = *param;
    ECService::sendEventFrom(from, to,EV_ERROR_REPORTING,&ev,sizeof(ev));
    ECService::logMsg(LOG_LEVEL_ERR,"report error, module%d, component:%d, errorNum %d \n", err.module, err.component, err.errNum);

}
void ErrorHandler::report(SVCID from, SVCID to, ERROR_INFO_TYPE err, int32_t* param1, int32_t* param2, LOG_DECODE_TYPE decodeType)
{
    EV_ERROR_REPORTING_TYPE ev;
    ev.err = err;
    ev.numOfParam = 2;
    ev.decodeType = decodeType;
    ev.param[0] = *param1;
    ev.param[1] = *param2;
    ECService::sendEventFrom(from, to,EV_ERROR_REPORTING,&ev,sizeof(ev));
    ECService::logMsg(LOG_LEVEL_ERR,"report error, module%d, component:%d, errorNum %d \n", err.module, err.component, err.errNum);
}

// end version 1
void ErrorHandler::report(SVCID to, ERROR_MESSAGE_TYPE err)
{
    EV_ERROR_REPORTING_TYPE ev;
    ev.err = err.info;
    ev.numOfParam = 0;
    ev.decodeType = DECODE_NONE;
    ECService::sendEvent(to,EV_ERROR_REPORTING,&ev,sizeof(ev));
    ECService::logMsg(LOG_LEVEL_ERR,"report error, module%d, component:%d, errorNum %d \n", err.info.module, err.info.component, err.info.errNum);
    //ECService::logMsg(LOG_LEVEL_ERR,err.desc);
    logString(err.desc);
}

void ErrorHandler::report(SVCID to, ERROR_MESSAGE_TYPE err, int32_t numofParam, int32_t param[10], LOG_DECODE_TYPE decodeType)
{
    EV_ERROR_REPORTING_TYPE ev;
    ev.err = err.info;
    ev.numOfParam = numofParam;
    ev.decodeType = decodeType;
    for(int i=0;i<numofParam;i++){
        ev.param[i] = param[i];}
    ECService::sendEvent(to,EV_ERROR_REPORTING,&ev,sizeof(ev));
    ECService::logMsg(LOG_LEVEL_ERR,"report error, module%d, component:%d, errorNum %d \n", err.info.module, err.info.component, err.info.errNum);
   // ECService::logMsg(LOG_LEVEL_ERR, err.desc);
    logString(err.desc);
    ECService::logMsg(LOG_LEVEL_ERR, "Error param: %d %d %d %d %d %d %d %d %d %d ", param[0],param[1],param[2],param[3],param[4],param[5],param[6],param[7],param[8],param[9]);
}

void ErrorHandler::report(SVCID to, ERROR_MESSAGE_TYPE err, int32_t* param, LOG_DECODE_TYPE decodeType)
{
    EV_ERROR_REPORTING_TYPE ev;
    ev.err = err.info;
    ev.numOfParam = 1;
    ev.decodeType = decodeType;
    ev.param[0] = *param;
    ECService::sendEvent(to,EV_ERROR_REPORTING,&ev,sizeof(ev));
    ECService::logMsg(LOG_LEVEL_ERR,"report error, module%d, component:%d, errorNum %d \n", err.info.module, err.info.component, err.info.errNum);

   // ECService::logMsg(LOG_LEVEL_ERR,  err.desc);
    logString(err.desc);
    ECService::logMsg(LOG_LEVEL_ERR, "Error param: %d ", *param);

}
void ErrorHandler::report(SVCID to, ERROR_MESSAGE_TYPE err, int32_t* param1, int32_t* param2, LOG_DECODE_TYPE decodeType)
{
    EV_ERROR_REPORTING_TYPE ev;
    ev.err = err.info;
    ev.numOfParam = 2;
    ev.decodeType = decodeType;
    ev.param[0] = *param1;
    ev.param[1] = *param2;
    ECService::sendEvent(to,EV_ERROR_REPORTING,&ev,sizeof(ev));
    ECService::logMsg(LOG_LEVEL_ERR,"report error, module%d, component:%d, errorNum %d \n", err.info.module, err.info.component, err.info.errNum);
    //ECService::logMsg(LOG_LEVEL_ERR,  err.desc);
    logString(err.desc);
    ECService::logMsg(LOG_LEVEL_ERR, "Error param: %d  %d", *param1,*param2);
}

void ErrorHandler::report(SVCID from, SVCID to, ERROR_MESSAGE_TYPE err)
{
    EV_ERROR_REPORTING_TYPE ev;
    ev.err = err.info;
    ev.numOfParam = 0;
    ev.decodeType = DECODE_NONE;
    ECService::sendEventFrom(from, to,EV_ERROR_REPORTING,&ev,sizeof(ev));
    ECService::logMsg(LOG_LEVEL_ERR,"report error, module%d, component:%d, errorNum %d \n", err.info.module, err.info.component, err.info.errNum);
    //ECService::logMsg(LOG_LEVEL_ERR,err.desc);
    logString(err.desc);
}



void ErrorHandler::report(SVCID from, SVCID to, ERROR_MESSAGE_TYPE err, int32_t numofParam, int32_t param[10], LOG_DECODE_TYPE decodeType)
{
    EV_ERROR_REPORTING_TYPE ev;
    ev.err = err.info;
    ev.numOfParam = numofParam;
    ev.decodeType = decodeType;
    for(int i=0;i<numofParam;i++){
        ev.param[i] = param[i];}
    ECService::sendEventFrom(from, to,EV_ERROR_REPORTING,&ev,sizeof(ev));
    ECService::logMsg(LOG_LEVEL_ERR,"report error, module%d, component:%d, errorNum %d \n", err.info.module, err.info.component, err.info.errNum);
   // ECService::logMsg(LOG_LEVEL_ERR, err.desc);
    logString(err.desc);
    ECService::logMsg(LOG_LEVEL_ERR, "Error param: %d %d %d %d %d %d %d %d %d %d ", param[0],param[1],param[2],param[3],param[4],param[5],param[6],param[7],param[8],param[9]);
}

void ErrorHandler::report(SVCID from, SVCID to, ERROR_MESSAGE_TYPE err, int32_t* param, LOG_DECODE_TYPE decodeType)
{
    EV_ERROR_REPORTING_TYPE ev;
    ev.err = err.info;
    ev.numOfParam = 1;
    ev.decodeType = decodeType;
    ev.param[0] = *param;
    ECService::sendEventFrom(from, to,EV_ERROR_REPORTING,&ev,sizeof(ev));
    ECService::logMsg(LOG_LEVEL_ERR,"report error, module%d, component:%d, errorNum %d \n", err.info.module, err.info.component, err.info.errNum);
    //ECService::logMsg(LOG_LEVEL_ERR, err.desc);
    logString(err.desc);
    ECService::logMsg(LOG_LEVEL_ERR, "Error param: %d ", *param);

}
void ErrorHandler::report(SVCID from, SVCID to, ERROR_MESSAGE_TYPE err, int32_t* param1, int32_t* param2, LOG_DECODE_TYPE decodeType)
{
    EV_ERROR_REPORTING_TYPE ev;
    ev.err = err.info;
    ev.numOfParam = 2;
    ev.decodeType = decodeType;
    ev.param[0] = *param1;
    ev.param[1] = *param2;
    ECService::sendEventFrom(from, to,EV_ERROR_REPORTING,&ev,sizeof(ev));
    ECService::logMsg(LOG_LEVEL_ERR,"report error, module%d, component:%d, errorNum %d \n", err.info.module, err.info.component, err.info.errNum);
    //ECService::logMsg(LOG_LEVEL_ERR,  err.desc);
    logString(err.desc);
    ECService::logMsg(LOG_LEVEL_ERR, "Error param: %d  %d", *param1,*param2);
}


