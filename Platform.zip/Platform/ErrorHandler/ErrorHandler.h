/**@file 
 * Copyright (C) 2013, Sinovision Tech Ltd.
 * All rights reserved.
 *
 * @brief  this file defines the C++ interface of event comm service
 *
 * @author  
 * @date 2013-11-13
 *
 */
#ifndef _ERROR_HANDLER_H_
#define _ERROR_HANDLER_H_

#include "CmErrorStruct.h"
#include "ECService.h"

class ErrorHandler
{
public:
    ErrorHandler();
    virtual ~ErrorHandler(){}
    
    static void report(SVCID to, ERROR_INFO_TYPE err);
    static void report(SVCID to, ERROR_INFO_TYPE err, int32_t numofParam, int32_t param[10], LOG_DECODE_TYPE decodeType=DECODE_NONE);
    static void report(SVCID to, ERROR_INFO_TYPE err, int32_t* param, LOG_DECODE_TYPE decodeType=DECODE_NONE);
    static void report(SVCID to, ERROR_INFO_TYPE err, int32_t* param1, int32_t* param2, LOG_DECODE_TYPE decodeType=DECODE_NONE);

    static void report(SVCID from, SVCID to, ERROR_INFO_TYPE err);
    static void report(SVCID from, SVCID to, ERROR_INFO_TYPE err, int32_t numofParam, int32_t param[10], LOG_DECODE_TYPE decodeType=DECODE_NONE);
    static void report(SVCID from, SVCID to, ERROR_INFO_TYPE err, int32_t* param, LOG_DECODE_TYPE decodeType=DECODE_NONE);
    static void report(SVCID from, SVCID to, ERROR_INFO_TYPE err, int32_t* param1, int32_t* param2, LOG_DECODE_TYPE decodeType=DECODE_NONE);


    static void report(SVCID to, ERROR_MESSAGE_TYPE err);
    static void report(SVCID to, ERROR_MESSAGE_TYPE err, int32_t numofParam, int32_t param[10], LOG_DECODE_TYPE decodeType=DECODE_NONE);
    static void report(SVCID to, ERROR_MESSAGE_TYPE err, int32_t* param, LOG_DECODE_TYPE decodeType=DECODE_NONE);
    static void report(SVCID to, ERROR_MESSAGE_TYPE err, int32_t* param1, int32_t* param2, LOG_DECODE_TYPE decodeType=DECODE_NONE);

    static void report(SVCID from, SVCID to, ERROR_MESSAGE_TYPE err);
    static void report(SVCID from, SVCID to, ERROR_MESSAGE_TYPE err, int32_t numofParam, int32_t param[10], LOG_DECODE_TYPE decodeType=DECODE_NONE);
    static void report(SVCID from, SVCID to, ERROR_MESSAGE_TYPE err, int32_t* param, LOG_DECODE_TYPE decodeType=DECODE_NONE);
    static void report(SVCID from, SVCID to, ERROR_MESSAGE_TYPE err, int32_t* param1, int32_t* param2, LOG_DECODE_TYPE decodeType=DECODE_NONE);

private:
    static void logString(const char *desc);


};

#endif

