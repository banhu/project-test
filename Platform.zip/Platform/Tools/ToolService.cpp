

#include "ToolService.h"
#include "TestFramework.h"
#include <unistd.h>
#include "malloc.h"

static void fpgaCmdUsage(void)
{
		printf("usage:\n");
		printf("	fpga [set | get ] [address] [value]\n");
}

static int	fpga_command(int argc, char * const argv[])
{
	EV_WR_FPGA_REG_TYPE wrFpgaRegEvt;
	EV_RD_FPGA_REG_TYPE rdFpgaRegEvt;
		
	if (argc < 2 || argc > 3) {
		fpgaCmdUsage();
		return -1;
	}

	if (0 == strcmp(argv[0], "set")) {
		if (argc != 3) {
			fpgaCmdUsage();
			return -1;
		}
		wrFpgaRegEvt.reg_offset = strtol(argv[1], NULL, 16);//atoi(argv[1]);
		wrFpgaRegEvt.val = strtol(argv[2], NULL, 16);//atoi(argv[2]);
		
		ECService::sendEventToDev((char *)FPGATESTDEV, EV_WR_FPGA_REG, 
			(void *)&wrFpgaRegEvt, sizeof(EV_WR_FPGA_REG_TYPE));
		printf("set 0x%x = 0x%x\n", wrFpgaRegEvt.reg_offset, wrFpgaRegEvt.val);
		return 0;
	}
	if (0 == strcmp(argv[0], "get")) {
		if (argc != 2) {
			fpgaCmdUsage();
			return -1;
		}
		rdFpgaRegEvt.reg_offset = strtol(argv[1], NULL, 16);//atoi(argv[1]);

		ECService::sendEventToDev((char *)FPGATESTDEV, EV_RD_FPGA_REG,
			(void *)&rdFpgaRegEvt, sizeof(EV_RD_FPGA_REG_TYPE));
		return 0;
	}
	

	return 0;
}

static void sendLogCmdUsage(void)
{
		printf("usage:\n");
		printf("	lds [serviceId] //service is which service's log.\n");
}

/***/
static int  sendLogDump(int argc, char * const argv[])
{
	EV_LOG_DUMP_TYPE ev;
	SVCID to;

	if (argc != 1) {
		sendLogCmdUsage();
		return -1;
	}
	
    to = (SVCID)atoi(argv[0]);
    ev.target = SVC_ID_OC_STATUS_MGR;

   // ECService::sendEventFrom(SVC_ID_TOOLS, to, EV_LOG_DUMP, &ev, sizeof(ev));
    ECService::sendEventFrom(SVC_ID_TOOLS, to, EV_LOG_DUMP, &ev, sizeof(ev));
	
    return 0;
}


ToolService::ToolService(SVCID id,int priority,bool detach,size_t stack,os_thread_data_t arg)
:ECService(id, priority, detach, stack, arg)
{
	
}

int  ToolService::initialize()
{
	registerEvent(EV_RD_FPGA_REG_RES, (EventHandler)&ToolService::cbRdFpgaRegRes);
	registerEvent(EV_FW_LOGGER, (EventHandler)&ToolService::cbLogger);
	
	return 0;
}


int ToolService::threadInitialize()
{

	registerDevice((char *)FPGATESTDEV, SVC_ID_DEV_FPGATEST);
	ECL::insert_command((char*)"fpga", fpga_command, (char*)"fpga register command ");
	ECL::insert_command((char*)"lds", sendLogDump, (char*)"send log dump event to service");
	
	return 0;
}

void ToolService::cbRdFpgaRegRes(EV_RD_FPGA_REG_RES_TYPE *rdFpgaRegResEvt)
{

	if (NULL == rdFpgaRegResEvt) {
		return;
	}
	printf("register 0x%x = 0x%x\n", rdFpgaRegResEvt->reg_offset, rdFpgaRegResEvt->val);
	
	
}


void ToolService::cbLogger(EVENT_HEADER_TYPE *event)
{
	//printf("\n code %d len %d \n", event->code, event->length);
	printf("%s", (char *)event + sizeof(EVENT_HEADER_TYPE));
	return;	
}








