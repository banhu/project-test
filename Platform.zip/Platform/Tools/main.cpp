
#include <unistd.h>
//#include "TestFramework.h"
#include "ToolService.h"





int timer_test_done = 0;
	
int main(int argc, char *argv[])
{


	new ToolService(SVC_ID_TOOLS, 0, 1, 10000, 0);


    ECService::startAll();



    ECL::monitor_run();
}




