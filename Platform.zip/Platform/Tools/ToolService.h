
#ifndef _TOOL_SERVICE_H_
#define _TOOL_SERVICE_H_

#include "os_intf.h"
#include "ECService.h"
#include "Macho.h"
#include "timer.h"


class ToolService : public ECService
{
public:
	explicit ToolService(SVCID id, int priority,
        bool detach, size_t stack,os_thread_data_t arg = NULL);
	~ToolService(){};

private:
	int initialize();
	int threadInitialize();
	void cbRdFpgaRegRes(EV_RD_FPGA_REG_RES_TYPE *rdFpgaRegResEvt);
	void cbLogger(EVENT_HEADER_TYPE *event);

};


#endif //_TOOL_SERVICE_H_


















